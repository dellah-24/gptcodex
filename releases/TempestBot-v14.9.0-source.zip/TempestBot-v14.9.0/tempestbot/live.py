"""TempestBot MetaTrader5 execution worker. One worker per terminal/account.

This module intentionally does not load MT5 until called. No network service can
send orders: only the local CLI worker invokes this code. Test with a fake SDK.
"""
import json
from hashlib import blake2s
import math
import re
import sqlite3
import threading
from contextlib import closing, contextmanager
from datetime import datetime, timezone
from pathlib import Path

from .core import RiskConfig, canonical_symbol, ensure_server, risk_gate

MAGIC = 260115
UNRESOLVED = ('UNKNOWN_PENDING', 'UNKNOWN', 'RECONCILE', 'PARTIAL', 'SUBMITTED')
LOCK = threading.RLock()
COMPANIES = ('justmarkets', 'just global markets')

class ExecutionBlocked(RuntimeError):
    pass


def base_symbol(symbol):
    if not isinstance(symbol, str) or not re.fullmatch(r'(XAUUSD|BTCUSD)(?:m|\.m|\.[A-Za-z0-9]{1,3})?', symbol, re.I):
        raise ExecutionBlocked('Only broker-mapped XAUUSD/BTCUSD instruments are allowed')
    return canonical_symbol(symbol)


class ExecutionJournal:
    def __init__(self, file):
        self.file = Path(file)
        self.file.parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(str(self.file))
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.execute('CREATE TABLE IF NOT EXISTS days(account INTEGER, date TEXT, opening_equity REAL, PRIMARY KEY(account,date))')
        self.db.execute('CREATE TABLE IF NOT EXISTS orders(key TEXT PRIMARY KEY, account INTEGER, symbol TEXT, status TEXT, data TEXT, timestamp TEXT DEFAULT CURRENT_TIMESTAMP)')
        self.db.execute('CREATE TABLE IF NOT EXISTS modifications(key TEXT PRIMARY KEY, account INTEGER, ticket INTEGER, symbol TEXT, status TEXT, data TEXT, timestamp TEXT DEFAULT CURRENT_TIMESTAMP)')
        self.db.execute('CREATE TABLE IF NOT EXISTS daily_halts(account INTEGER, date TEXT, equity REAL, loss_limit REAL, PRIMARY KEY(account,date))')
        self.db.executescript("""
            CREATE TABLE IF NOT EXISTS order_events(
                id INTEGER PRIMARY KEY, order_key TEXT NOT NULL, account INTEGER NOT NULL,
                symbol TEXT NOT NULL, status TEXT NOT NULL, data TEXT NOT NULL,
                timestamp TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE INDEX IF NOT EXISTS order_events_account ON order_events(account,id);
            CREATE INDEX IF NOT EXISTS order_events_order ON order_events(order_key);
            CREATE TRIGGER IF NOT EXISTS order_reserved AFTER INSERT ON orders
            BEGIN
              INSERT INTO order_events(order_key,account,symbol,status,data)
                VALUES(NEW.key,NEW.account,NEW.symbol,'RESERVED',NEW.data);
            END;
            CREATE TRIGGER IF NOT EXISTS order_status_changed AFTER UPDATE OF status ON orders
              WHEN OLD.status != NEW.status
            BEGIN
              INSERT INTO order_events(order_key,account,symbol,status,data)
                VALUES(NEW.key,NEW.account,NEW.symbol,NEW.status,NEW.data);
            END;
        """)
        self.db.commit()
        try: self.file.chmod(0o600)
        except OSError: pass

    def day_start(self, account, equity):
        today = datetime.now(timezone.utc).date().isoformat()
        with self.db:
            self.db.execute('INSERT OR IGNORE INTO days VALUES(?,?,?)', (account, today, equity))
        row = self.db.execute('SELECT opening_equity FROM days WHERE account=? AND date=?', (account,today)).fetchone()
        return float(row[0])

    def sample_daily_equity(self, account, equity, loss_limit):
        # One UTC date per sample keeps midnight rollover consistent.
        today = datetime.now(timezone.utc).date().isoformat()
        with self.db:
            self.db.execute('INSERT OR IGNORE INTO days VALUES(?,?,?)', (account, today, equity))
            start, = self.db.execute(
                'SELECT opening_equity FROM days WHERE account=? AND date=?', (account, today)
            ).fetchone()
            if equity <= start * (1 - loss_limit / 100):
                self.db.execute('INSERT OR IGNORE INTO daily_halts VALUES(?,?,?,?)',
                                (account, today, equity, loss_limit))
            halted = self.db.execute('SELECT 1 FROM daily_halts WHERE account=? AND date=?',
                                     (account, today)).fetchone()
        return start, bool(halted)

    def require_unpaused(self):
        if self.file.with_name('PAUSE_TRADING').exists():
            raise ExecutionBlocked('Trading paused by operator')

    def require_reconciled(self, account):
        for table in ('orders', 'modifications'):
            row = self.db.execute(
                f'SELECT key FROM {table} WHERE account=? AND status IN (?,?,?,?,?) LIMIT 1',
                (account, *UNRESOLVED),
            ).fetchone()
            if row:
                raise ExecutionBlocked(f'Account execution halted for reconciliation: {table} {row[0]}')

    def reserve(self, key, account, symbol, details, *, prior_keys=()):
        try:
            with self.db:
                self.db.execute('BEGIN IMMEDIATE')
                self.require_reconciled(account)
                if any(self.db.execute('SELECT 1 FROM orders WHERE key=?', (prior,)).fetchone()
                       for prior in prior_keys):
                    raise ExecutionBlocked('This candle was already attempted')
                self.db.execute('INSERT INTO orders(key,account,symbol,status,data) VALUES(?,?,?,?,?)',
                                (key,account,symbol,'UNKNOWN_PENDING',json.dumps(details)))
        except sqlite3.IntegrityError as exc:
            raise ExecutionBlocked('This signal has already been attempted; reconcile it with MT5 history before retrying') from exc

    def finish(self, key, status, details):
        with self.db:
            self.db.execute(
                "UPDATE orders SET status=?, data=json_object('request',json(data),'result',json(?)) WHERE key=?",
                (status, json.dumps(details), key),
            )

    def reserve_modification(self,key,account,ticket,symbol,details):
        try:
            with self.db:
                self.db.execute('BEGIN IMMEDIATE')
                self.require_reconciled(account)
                self.db.execute('INSERT INTO modifications(key,account,ticket,symbol,status,data) VALUES(?,?,?,?,?,?)',
                                (key,int(account),int(ticket),symbol,'UNKNOWN_PENDING',json.dumps(details)))
        except sqlite3.IntegrityError as exc:
            raise ExecutionBlocked('SL/TP modification already attempted for this candle; reconcile broker state') from exc

    def finish_modification(self,key,status,details):
        with self.db:
            self.db.execute(
                "UPDATE modifications SET status=?, data=json_object('request',json(data),'result',json(?)) WHERE key=?",
                (status, json.dumps(details), key),
            )

    def history(self, limit=100):
        return [dict(zip(('key','symbol','status','data','timestamp'),row)) for row in
                self.db.execute('SELECT key,symbol,status,data,timestamp FROM orders ORDER BY timestamp DESC LIMIT ?', (limit,))]


@contextmanager
def account_lease(journal, account):
    lock_file = journal.file.with_name(f'execution-{account}.lock.sqlite3')
    with closing(sqlite3.connect(lock_file, timeout=0)) as lease:
        try:
            lease.execute('BEGIN EXCLUSIVE')
        except sqlite3.OperationalError as exc:
            raise ExecutionBlocked('Could not acquire the local account execution lock') from exc
        yield


def verify_identity(mt5, login, server, *, expected_mode=None, require_trading=False):
    account = mt5.account_info()
    terminal = mt5.terminal_info()
    if account is None or terminal is None:
        raise ExecutionBlocked('MT5 account/terminal information unavailable')
    if int(account.login) != int(login) or str(account.server).casefold() != server.casefold():
        raise ExecutionBlocked('MT5 account or server changed — trading blocked')
    if not any(part in str(account.company).casefold() for part in COMPANIES):
        raise ExecutionBlocked('Broker identity could not be verified as JustMarkets')
    if not bool(getattr(terminal,'connected',False)):
        raise ExecutionBlocked('MT5 terminal disconnected')
    if expected_mode is not None and getattr(account, 'trade_mode', None) != expected_mode:
        raise ExecutionBlocked('Verified MT5 account type does not match requested execution mode')
    if require_trading and (
        not getattr(account, 'trade_allowed', False)
        or not getattr(account, 'trade_expert', False)
        or not getattr(terminal, 'trade_allowed', True)
        or getattr(terminal, 'tradeapi_disabled', False)
    ):
        raise ExecutionBlocked('Account or terminal algorithmic trading is disabled')
    return account


def require_current_candle(candle_time, seconds=600):
    age = datetime.now(timezone.utc).timestamp() - (candle_time + seconds)
    if candle_time % seconds or not 0 <= age < seconds:
        raise ExecutionBlocked('Decision candle is stale, incomplete, or misaligned')


def select_symbol(mt5, desired):
    base_symbol(desired)
    options = mt5.symbols_get()
    if options is None:
        raise ExecutionBlocked('Cannot query broker symbols')
    matches = [s.name for s in options if s.name.casefold() == desired.casefold()]
    if len(matches) != 1:
        raise ExecutionBlocked(f'Symbol {desired!r} not available at this broker; configure exact MT5 Market Watch symbol')
    if not mt5.symbol_select(matches[0],True):
        raise ExecutionBlocked('Failed to select instrument in MT5')
    return matches[0]


def _num(value):
    v=float(value)
    if not math.isfinite(v): raise ExecutionBlocked('Nonfinite price/risk input')
    return v


def _lots(mt5, symbol, side, price, sl, equity, risk_pct, info):
    """Use broker-provided order_calc_profit to limit risk at actual stop."""
    from decimal import Decimal, ROUND_FLOOR
    action = mt5.ORDER_TYPE_BUY if side == 'buy' else mt5.ORDER_TYPE_SELL
    min_vol = _num(info.volume_min)
    max_vol = _num(info.volume_max)
    step = _num(info.volume_step)
    if min_vol <= 0 or max_vol < min_vol or step <= 0: raise ExecutionBlocked('Invalid broker lot specification')
    loss = mt5.order_calc_profit(action, symbol, min_vol, price, sl)
    if loss is None or _num(loss) >= 0:
        raise ExecutionBlocked('Unable to calculate potential loss using MT5 order_calc_profit')
    budget = equity * risk_pct / 100
    if -loss > budget:
        raise ExecutionBlocked('Broker minimum lot would exceed allowed cash risk')
    raw = min_vol * budget / -float(loss)
    dmin, dstep = Decimal(str(min_vol)), Decimal(str(step))
    capped = min(Decimal(str(raw)),Decimal(str(max_vol)))
    size = dmin + ((capped-dmin)/dstep).to_integral_value(rounding=ROUND_FLOOR)*dstep
    lots = float(size)
    actual = mt5.order_calc_profit(action, symbol, lots, price, sl)
    if actual is None or _num(actual) >= 0 or -actual > budget + 1e-6:
        raise ExecutionBlocked('Lot size failed broker cash-risk verification')
    return lots


def stop_exposure(mt5, positions, pending):
    """Combined additional loss to current stops, in the account currency."""
    buy = mt5.ORDER_TYPE_BUY
    sell = mt5.ORDER_TYPE_SELL
    total = 0.0
    for position in positions:
        tick = mt5.symbol_info_tick(position.symbol)
        if tick is None or position.type not in (buy, sell):
            raise ExecutionBlocked('Cannot price current account exposure')
        current = _num(tick.bid if position.type == buy else tick.ask)
        tick_age = datetime.now(timezone.utc).timestamp() - _num(tick.time)
        if not -5 <= tick_age <= 120:
            raise ExecutionBlocked('Stale quote for an existing position')
        total += _protected_loss(mt5, position.symbol, position.type, position.volume, current, position.sl)
    for order in pending:
        if order.type in (getattr(mt5, 'ORDER_TYPE_BUY_LIMIT', 2), getattr(mt5, 'ORDER_TYPE_BUY_STOP', 4),
                          getattr(mt5, 'ORDER_TYPE_BUY_STOP_LIMIT', 6)):
            side = buy
        elif order.type in (getattr(mt5, 'ORDER_TYPE_SELL_LIMIT', 3), getattr(mt5, 'ORDER_TYPE_SELL_STOP', 5),
                             getattr(mt5, 'ORDER_TYPE_SELL_STOP_LIMIT', 7)):
            side = sell
        else:
            raise ExecutionBlocked('Cannot price an outstanding account order')
        price = _num(order.price_open)
        limit = _num(getattr(order, 'price_stoplimit', 0))
        if limit > 0:
            price = max(price, limit) if side == buy else min(price, limit)
        total += _protected_loss(mt5, order.symbol, side, order.volume_current, price, order.sl)
    return total


def _protected_loss(mt5, symbol, side, volume, price, stop):
    volume, price, stop = map(_num, (volume, price, stop))
    if min(volume, price, stop) <= 0 or (stop >= price if side == mt5.ORDER_TYPE_BUY else stop <= price):
        raise ExecutionBlocked('Missing, crossed, or invalid protective stop in account exposure')
    result = mt5.order_calc_profit(side, symbol, volume, price, stop)
    if result is None or _num(result) >= 0:
        raise ExecutionBlocked('Broker could not calculate stop exposure')
    return -float(result)


def _fill_mode(mt5, info):
    flags = int(getattr(info,'filling_mode',0))
    if flags & 2: return mt5.ORDER_FILLING_IOC
    if flags & 1: return mt5.ORDER_FILLING_FOK
    # Don't assume RETURN is supported on all execution modes.
    raise ExecutionBlocked('No supported IOC/FOK broker filling mode')


def execute_order(mt5, *, login, server, approved_servers, symbol, side, sl, tp,
                  candle_time, journal, risk=None, live_enabled=False, subscribed=True, max_tick_age=120, expected_mode=None, enforce_candle_freshness=False, candle_seconds=600, max_spread_points=None, entry_quote_guard=None, improvement_profile=None, improvement_mode=None):
    """Submit one guarded market order. An uncertain submission remains reserved.

    subscribed must come from an independently verified billing system; this CLI
    passes True for a private self-hosted trading installation (no paid gating).
    """
    with LOCK:
        risk = (risk or RiskConfig()).validate()
        ensure_server(server,approved_servers)
        symbol = select_symbol(mt5,symbol)
        if side not in ('buy','sell'): raise ExecutionBlocked('Invalid direction')
        if not live_enabled: raise ExecutionBlocked('Execution disabled; use dry-run first')
        account = verify_identity(mt5, login, server, expected_mode=expected_mode, require_trading=True)
        journal.require_reconciled(login)
        info = mt5.symbol_info(symbol)
        tick = mt5.symbol_info_tick(symbol)
        if info is None or tick is None: raise ExecutionBlocked('Broker price or contract details missing')
        if getattr(info,'trade_mode',None) != getattr(mt5,'SYMBOL_TRADE_MODE_FULL',4):
            raise ExecutionBlocked('Instrument trading is not fully enabled')
        now = datetime.now(timezone.utc).timestamp()
        if now - _num(tick.time) > max_tick_age or _num(tick.time) > now+5:
            raise ExecutionBlocked('Stale or future-dated broker tick')
        bid, ask = _num(tick.bid), _num(tick.ask)
        if bid <= 0 or ask <= bid: raise ExecutionBlocked('Invalid bid/ask')
        price = ask if side=='buy' else bid
        sl, tp = _num(sl), _num(tp)
        digits = int(info.digits)
        price, sl, tp = (round(value, digits) for value in (price, sl, tp))
        if min(price, sl, tp) <= 0 or not (sl < price < tp if side=='buy' else tp < price < sl):
            raise ExecutionBlocked('Stop loss/take profit are on the wrong side of entry')
        point = _num(info.point)
        if max_spread_points is not None and (point <= 0 or (ask - bid) / point > max_spread_points + 1e-8):
            raise ExecutionBlocked('Spread exceeds broker-point limit')
        if entry_quote_guard:
            reason = entry_quote_guard(price, sl, tp, point)
            if reason:
                raise ExecutionBlocked(reason)
        min_stop = max(0,int(getattr(info,'trade_stops_level',0))) * point
        trigger = bid if side == 'buy' else ask
        valid_stops = sl < trigger < tp if side == 'buy' else tp < trigger < sl
        if point <= 0 or not valid_stops or min(abs(trigger-sl),abs(trigger-tp)) <= min_stop + point:
            raise ExecutionBlocked('Stops are too close to broker minimum distance')
        positions = mt5.positions_get()
        if positions is None: raise ExecutionBlocked('Cannot verify open positions')
        # Reject a second position in the same instrument, regardless of magic.
        if any(p.symbol.casefold() == symbol.casefold() for p in positions):
            raise ExecutionBlocked('Position already exists for this instrument')
        pending = mt5.orders_get()
        if pending is None or any(order.symbol.casefold() == symbol.casefold() for order in pending):
            raise ExecutionBlocked('Cannot rule out pending orders for this instrument')
        equity = _num(account.equity)
        if equity <= 0:
            raise ExecutionBlocked('Account equity must be positive')
        start, halted = journal.sample_daily_equity(login, equity, risk.daily_loss_percent)
        if halted:
            raise ExecutionBlocked('Daily loss halt is latched until the next UTC day')
        permitted, reason = risk_gate(config=risk,day_start_equity=start,current_equity=_num(account.equity),
                         positions=len(positions),spread=ask-bid,stop_distance=abs(price-sl),
                         reward_distance=abs(tp-price),subscribed=subscribed,enabled=True)
        if not permitted: raise ExecutionBlocked(reason)
        available = risk.max_exposure_percent - (100 * stop_exposure(mt5, positions, pending) / equity)
        if available <= 0:
            raise ExecutionBlocked('Combined account stop-risk cap reached')
        order_type = mt5.ORDER_TYPE_BUY if side == 'buy' else mt5.ORDER_TYPE_SELL
        worst_entry = price + 15 * point if side == 'buy' else price - 15 * point
        if worst_entry <= 0:
            raise ExecutionBlocked('Invalid deviation-adjusted entry price')
        lots = _lots(mt5, symbol, side, worst_entry, sl, equity, min(risk.risk_percent, available), info)
        prefix = f'{int(login)}:{symbol}:{candle_time}'
        key = f'{int(login)}:{server.casefold()}:{symbol.casefold()}:{candle_time}'
        comment = 'TB-' + blake2s(key.encode(), digest_size=10).hexdigest()
        request = {'action':mt5.TRADE_ACTION_DEAL,'symbol':symbol,'volume':lots,
                   'type':order_type,
                   'price':price,'sl':sl,'tp':tp,
                   'deviation':15,'magic':MAGIC,'comment':comment,
                   'type_time':mt5.ORDER_TIME_GTC,'type_filling':_fill_mode(mt5,info)}
        check=mt5.order_check(request)
        if check is None or int(check.retcode) != 0:
            raise ExecutionBlocked('MT5 order_check failed: '+str(getattr(check,'retcode','unavailable')))
        journal_request = ({**request, 'improvement_profile': improvement_profile, 'improvement_mode': improvement_mode}
                           if improvement_profile else request)
        journal.reserve(key, int(login), symbol, journal_request,
                        prior_keys=(f'{prefix}:buy', f'{prefix}:sell'))
        # Identity is checked again immediately before the send.
        try:
            journal.require_unpaused()
            if enforce_candle_freshness:
                require_current_candle(candle_time, candle_seconds)
            verify_identity(mt5, login, server, expected_mode=expected_mode, require_trading=True)
        except ExecutionBlocked:
            journal.finish(key, 'BLOCKED', request)
            raise
        return _submit_reserved(mt5, journal, key, request, side)


def _submit_reserved(mt5, journal, key, request, side):
    """Record the outcome of a reserved market order without blind retries."""
    lots, symbol = request['volume'], request['symbol']
    try:
        result=mt5.order_send(request)
    except Exception as exc:
        journal.finish(key,'UNKNOWN',{'error':type(exc).__name__,'action':'RECONCILE WITH MT5; DO NOT AUTO RETRY'})
        raise ExecutionBlocked('Order submission uncertain; inspect MT5 history before retry') from exc
    if result is None:
        journal.finish(key,'UNKNOWN',{'error':'Empty response; reconcile manually'})
        raise ExecutionBlocked('Empty order_send response — reconcile with broker')
    receipt={'retcode':int(result.retcode),'order':int(getattr(result,'order',0)),
             'deal':int(getattr(result,'deal',0)),'requested_volume':lots,'volume':float(getattr(result,'volume',lots)),
             'symbol':symbol,'side':side}
    # Confirm nonterminal submissions against broker history before releasing the hold.
    code = receipt['retcode']
    if code == mt5.TRADE_RETCODE_DONE and receipt['deal'] and math.isclose(receipt['volume'], lots, rel_tol=0, abs_tol=1e-8):
        status = 'FILLED'
    elif code == getattr(mt5, 'TRADE_RETCODE_DONE_PARTIAL', 10010):
        status = 'PARTIAL'
    elif code == getattr(mt5, 'TRADE_RETCODE_PLACED', 10008):
        status = 'SUBMITTED'
    elif code in (10004, 10006, 10013, 10014, 10015, 10016, 10017, 10018, 10019, 10021):
        status = 'REJECTED'
    else:
        status = 'RECONCILE'
    if status == 'FILLED' and request.get('position'):
        remaining = mt5.positions_get(symbol=symbol)
        if remaining is None or remaining:
            status = 'RECONCILE'
    journal.finish(key,status,receipt)
    if status!='FILLED':
        raise ExecutionBlocked(f'MT5 returned retcode {result.retcode}; verify positions/deals manually')
    return receipt
