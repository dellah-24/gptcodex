"""Closed-candle reversal policy and ticket-specific position exits."""
from hashlib import blake2s
from datetime import datetime, timezone

from .live import (
    ExecutionBlocked, LOCK, MAGIC, _fill_mode, _num, _submit_reserved,
    require_current_candle, verify_identity,
)


def reversal_streak(previous, *, candle, side, confidence, threshold, candle_seconds=600):
    """Count qualified adjacent decisions once per candle."""
    prior_candle, prior_side, count = previous or (None, None, 0)
    if prior_candle is not None and candle <= prior_candle:
        return previous
    if side not in ('buy', 'sell') or not threshold <= confidence <= 1:
        return candle, None, 0
    adjacent = prior_side == side and prior_candle == candle - candle_seconds
    return candle, side, count + 1 if adjacent else 1


def exit_key(login, server, symbol, candle):
    return f'{login}:{server.casefold()}:{symbol.casefold()}:{candle}:exit'


def close_on_reversal(mt5, *, login, server, symbol, direction, candle, journal,
                      expected_mode, dry_run=False, candle_seconds=600):
    """Close the sole opposite bot position by ticket. Return whether an exit was due."""
    with LOCK:
        verify_identity(mt5, login, server, expected_mode=expected_mode, require_trading=not dry_run)
        require_current_candle(candle, candle_seconds)
        positions = mt5.positions_get(symbol=symbol)
        if positions is None:
            raise ExecutionBlocked('Cannot verify positions before reversal')
        current_type = mt5.POSITION_TYPE_BUY if direction == 'buy' else mt5.POSITION_TYPE_SELL
        opposite = [p for p in positions if p.magic == MAGIC and p.type != current_type]
        if not opposite:
            return False
        if len(positions) != 1 or len(opposite) != 1:
            raise ExecutionBlocked('Reversal needs a single bot position on the symbol')
        position = opposite[0]
        if position.type not in (mt5.POSITION_TYPE_BUY, mt5.POSITION_TYPE_SELL):
            raise ExecutionBlocked('Unsupported MT5 position type')
        pending = mt5.orders_get(symbol=symbol)
        if pending is None or pending:
            raise ExecutionBlocked('Outstanding symbol orders prevent a reversal')
        identifier = getattr(position, 'identifier', position.ticket)
        deals = mt5.history_deals_get(position=identifier)
        trade_types = (mt5.DEAL_TYPE_BUY, mt5.DEAL_TYPE_SELL)
        fills = [d for d in (deals or ()) if d.type in trade_types]
        if not fills or any(d.magic != MAGIC for d in fills):
            raise ExecutionBlocked('Position history does not establish exclusive bot ownership')
        if dry_run:
            return True
        journal.require_unpaused()
        journal.require_reconciled(login)
        tick, info = mt5.symbol_info_tick(symbol), mt5.symbol_info(symbol)
        if tick is None or info is None:
            raise ExecutionBlocked('Missing reversal quote or contract')
        age = datetime.now(timezone.utc).timestamp() - _num(tick.time)
        if not -5 <= age <= (10 if candle_seconds == 60 else 120) or not 0 < _num(tick.bid) < _num(tick.ask):
            raise ExecutionBlocked('Invalid or stale reversal quote')
        buy = direction == 'buy'
        volume = _num(position.volume)
        if volume <= 0:
            raise ExecutionBlocked('Invalid position volume')
        key = exit_key(login, server, symbol, candle)
        request = {
            'action': mt5.TRADE_ACTION_DEAL, 'position': position.ticket, 'symbol': symbol,
            'volume': volume, 'type': mt5.ORDER_TYPE_BUY if buy else mt5.ORDER_TYPE_SELL,
            'price': round(tick.ask if buy else tick.bid, info.digits), 'deviation': 15,
            'magic': MAGIC, 'comment': 'TB-' + blake2s(key.encode(), digest_size=10).hexdigest(),
            'type_time': mt5.ORDER_TIME_GTC, 'type_filling': _fill_mode(mt5, info),
        }
        check = mt5.order_check(request)
        if check is None or check.retcode != 0:
            raise ExecutionBlocked('Broker preflight rejected position exit')
        verify_identity(mt5, login, server, expected_mode=expected_mode, require_trading=True)
        require_current_candle(candle, candle_seconds)
        journal.require_unpaused()
        fresh = mt5.positions_get(symbol=symbol)
        if (not fresh or len(fresh) != 1 or
                (fresh[0].ticket, fresh[0].type, fresh[0].volume, fresh[0].magic)
                != (position.ticket, position.type, volume, MAGIC)):
            raise ExecutionBlocked('Position changed before exit submission')
        journal.reserve(key, login, symbol, {**request, 'position_identifier': identifier})
        _submit_reserved(mt5, journal, key, request, direction)
        return True
