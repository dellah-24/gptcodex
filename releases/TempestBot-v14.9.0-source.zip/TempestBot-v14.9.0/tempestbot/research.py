"""Independent, forward-only model research. Outputs JSON metrics, never executable model pickles.

Data is external CSV of CLOSED bars; predictions are out-of-sample only.
No automatic model deployment or trading is performed.
"""
import csv
import json
import math
from pathlib import Path

FIELDS=('open','high','low','close','tick_volume')

def load_closed_bars(path):
    """CSV must contain strictly increasing ISO timestamps and OHLCV columns."""
    rows=[]
    with open(path, newline='', encoding='utf-8-sig') as fp:
        reader=csv.DictReader(fp)
        if not {'time',*FIELDS}.issubset(reader.fieldnames or []):
            raise ValueError('CSV requires time, open, high, low, close, tick_volume')
        previous=None
        for row in reader:
            stamp=row['time']
            if not stamp or (previous is not None and stamp<=previous):
                raise ValueError('Time must be strictly increasing ISO timestamps')
            previous=stamp
            vals={k:float(row[k]) for k in FIELDS}
            if not all(math.isfinite(v) for v in vals.values()): raise ValueError('Nonfinite bar')
            if vals['low']>min(vals['open'],vals['close']) or vals['high']<max(vals['open'],vals['close']):
                raise ValueError('Invalid bar OHLC')
            if vals['close']<=0 or vals['high']<=0 or vals['low']<=0 or vals['tick_volume']<0:
                raise ValueError('Invalid bar prices/volume')
            rows.append(vals)
    return rows

def build_dataset(bars, horizon=3, warmup=30, threshold=0.0005):
    import numpy as np
    if horizon<1 or warmup<20 or threshold<0: raise ValueError('Invalid research parameters')
    if len(bars)<warmup+2*horizon+150: raise ValueError('At least 200 historical closed bars are required')
    features=[];labels=[];indices=[]
    for i in range(warmup,len(bars)-horizon):
        recent=bars[i-20:i+1]
        close=bars[i]['close']
        returns=[(recent[j]['close']/recent[j-1]['close']-1) for j in range(1,len(recent))]
        tr=[max(b['high']-b['low'],abs(b['high']-recent[k-1]['close']),abs(b['low']-recent[k-1]['close']))
            for k,b in enumerate(recent) if k>0]
        x=[sum(returns[-3:]),sum(returns[-10:]),sum(returns)/len(returns),
           sum(tr[-14:])/14/close,
           (close-max(b['high'] for b in recent[:-1]))/close,
           (close-min(b['low'] for b in recent[:-1]))/close,
           (bars[i]['high']-bars[i]['low'])/close,
           (bars[i]['close']-bars[i]['open'])/close,
           math.log1p(bars[i]['tick_volume'])]
        # Binary forward-return classification; neutral and bearish outcomes are class 0.
        future=bars[i+horizon]['close']/close-1
        y=1 if future>threshold else 0
        features.append(x);labels.append(y);indices.append(i)
    return np.asarray(features),np.asarray(labels),indices

def evaluate_walk_forward(bars, horizon=3, threshold=0.0005, train_min=120, test_size=50):
    """Expanding-window classification with purge gap and no leakage of future labels.

    Measures directional classifier performance, NOT profitability. The trained models
    are intentionally not serialized or promoted.
    """
    import numpy as np
    from sklearn.ensemble import HistGradientBoostingClassifier
    from sklearn.metrics import accuracy_score, balanced_accuracy_score
    X,y,indices=build_dataset(bars,horizon=horizon,threshold=threshold)
    if train_min<80 or test_size<20: raise ValueError('Train/test windows too small')
    results=[];pred=[];truth=[]
    cut=train_min+horizon
    while cut+test_size<=len(y):
        train_stop=cut-horizon
        trX,try_=X[:train_stop],y[:train_stop]
        if len(np.unique(try_))<2:
            raise ValueError('Training fold has only one class')
        model=HistGradientBoostingClassifier(max_iter=80,max_leaf_nodes=15,l2_regularization=1,random_state=23)
        model.fit(trX,try_)
        p=model.predict(X[cut:cut+test_size]);t=y[cut:cut+test_size]
        pred.extend(map(int,p));truth.extend(map(int,t))
        results.append({'first_bar_index':indices[cut], 'last_bar_index':indices[cut+test_size-1],
                        'training_examples':train_stop,'test_examples':len(t),
                        'accuracy':round(float(accuracy_score(t,p)),4)})
        cut+=test_size
    if not truth: raise ValueError('Not enough observations for a complete forward test fold')
    accuracy=float(accuracy_score(truth,pred))
    baseline=max(sum(truth)/len(truth),1-sum(truth)/len(truth))
    return {'mode':'RESEARCH ONLY: NO LIVE MODEL PROMOTION', 'horizon_bars':horizon,
            'folds':results,'out_of_sample_count':len(truth),'out_of_sample_accuracy':round(accuracy,4),
            'out_of_sample_balanced_accuracy':round(float(balanced_accuracy_score(truth,pred)),4),
            'majority_class_baseline_accuracy':round(baseline,4),
            'beats_baseline':accuracy>baseline,
            'limitations':'No transaction costs, calibration, data-drift checks or profitability inference. Same price-series timestamps may contain session gaps. No live deployment.'}

def run_cli():
    import argparse
    parser=argparse.ArgumentParser(description='TempestBot chronological AI research (no live trading)')
    parser.add_argument('csv',type=Path,help='CSV with time/open/high/low/close/tick_volume; chronological closed bars')
    parser.add_argument('--out',type=Path,default=Path('research_results.json'))
    parser.add_argument('--horizon',type=int,default=3)
    args=parser.parse_args()
    result=evaluate_walk_forward(load_closed_bars(args.csv),horizon=args.horizon)
    args.out.write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))
if __name__=='__main__': run_cli()
