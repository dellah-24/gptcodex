"""TempestBot extension layer for Ezee-Kits FOREX-TRADING-BOT."""
