"""Pure-Python strategy, validation, backtesting, and safety primitives.

These are independent from MT5 so they can be tested on all supported OSes.
"""
from dataclasses import dataclass
from datetime import datetime, timezone
from math import isfinite
import re

ALLOWED_SYMBOLS = frozenset({'XAUUSD', 'BTCUSD'})
REFERRAL_URL = 'https://one.justmarkets.link/a/wl5yg0sslf'


def canonical_symbol(symbol: str) -> str:
    """Allow only gold/bitcoin and explicit common MT5 suffix patterns."""
    if not isinstance(symbol, str):
        raise ValueError('Invalid symbol')
    match = re.fullmatch(r'(XAUUSD|BTCUSD)(?:m|\.m|\.[A-Za-z0-9]{1,5})?', symbol, re.I)
    if not match:
        raise ValueError('TempestBot only permits XAUUSD and BTCUSD')
    return match.group(1).upper()


def ensure_server(server: str, approved: list[str]) -> str:
    if not isinstance(server, str) or server not in approved:
        raise ValueError('Server must be selected from the admin-approved JustMarkets list')
    if not re.search(r'justmarkets', server, re.I):
        raise ValueError('Only JustMarkets MT5 servers may be configured')
    return server


@dataclass(frozen=True)
class RiskConfig:
    risk_percent: float = 0.5
    daily_loss_percent: float = 2.0
    max_positions: int = 2
    max_spread_to_stop: float = 0.15
    min_rr: float = 1.5
    max_exposure_percent: float = 2.0

    def validate(self):
        if not (isfinite(self.risk_percent) and 0 < self.risk_percent <= 2):
            raise ValueError('Risk/trade must be >0 and <=2%')
        if not (isfinite(self.daily_loss_percent) and 0 < self.daily_loss_percent <= 5):
            raise ValueError('Daily loss limit must be >0 and <=5%')
        if not 1 <= self.max_positions <= 4:
            raise ValueError('Max positions must be between 1 and 4')
        if not (isfinite(self.max_spread_to_stop) and 0 <= self.max_spread_to_stop <= 0.3):
            raise ValueError('Spread ratio must be between 0 and 0.3')
        if not (isfinite(self.min_rr) and 1 <= self.min_rr <= 5):
            raise ValueError('Minimum reward/risk must be between 1 and 5')
        if not (isfinite(self.max_exposure_percent) and 0 < self.max_exposure_percent <= 5):
            raise ValueError('Combined stop risk must be >0 and <=5%')
        return self


def risk_gate(*, config: RiskConfig, day_start_equity: float, current_equity: float,
              positions: int, spread: float, stop_distance: float, reward_distance: float,
              subscribed: bool, enabled: bool) -> tuple[bool, str]:
    config.validate()
    values = [day_start_equity, current_equity, spread, stop_distance, reward_distance]
    if not all(isfinite(v) for v in values) or day_start_equity <= 0 or current_equity <= 0:
        return False, 'Invalid equity or price inputs'
    if not enabled:
        return False, 'Live trading disabled'
    if not subscribed:
        return False, 'Subscription inactive'
    if (day_start_equity - current_equity) / day_start_equity * 100 >= config.daily_loss_percent:
        return False, 'Daily loss circuit breaker triggered'
    if positions >= config.max_positions:
        return False, 'Position limit reached'
    if stop_distance <= 0 or spread < 0 or spread / stop_distance > config.max_spread_to_stop:
        return False, 'Spread too high relative to stop'
    if reward_distance / stop_distance < config.min_rr:
        return False, 'Reward-to-risk below minimum'
    return True, 'Allowed by preliminary risk gate'


def position_size(*, equity: float, risk_percent: float, stop_distance: float,
                  tick_size: float, tick_value: float, volume_min: float,
                  volume_max: float, volume_step: float) -> float:
    """Round DOWN; reject if even minimum lot would exceed risk cap."""
    from decimal import Decimal, ROUND_FLOOR
    inputs = (equity, risk_percent, stop_distance, tick_size, tick_value,
              volume_min, volume_max, volume_step)
    if not all(isfinite(v) and v > 0 for v in inputs):
        raise ValueError('Invalid position size inputs')
    risk_cash = equity * risk_percent / 100
    cash_per_lot = stop_distance / tick_size * tick_value
    raw = Decimal(str(risk_cash / cash_per_lot))
    lower = Decimal(str(volume_min))
    step = Decimal(str(volume_step))
    if raw < lower:
        raise ValueError('Broker minimum volume exceeds allowed cash risk')
    capped = min(raw, Decimal(str(volume_max)))
    lots = lower + ((capped - lower) / step).to_integral_value(rounding=ROUND_FLOOR) * step
    return float(lots)


def smc_ict_confirm(candles: list[dict], direction: str, lookback: int = 12) -> dict:
    """Conservative, *heuristic* SMC confirmation (not a validated strategy).

    Requires a closed-candle break of prior structure AND a 3-candle FVG.
    Does not use an unclosed current candle. OHLC values must be finite.
    """
    if direction not in ('buy', 'sell'):
        raise ValueError('Direction must be buy or sell')
    if len(candles) < lookback + 3:
        return {'confirmed': False, 'reason': 'Insufficient completed candles', 'bos': False, 'fvg': False}
    for candle in candles:
        if any(k not in candle or not isinstance(candle[k], (int,float)) or not isfinite(candle[k]) for k in ('open','high','low','close')):
            raise ValueError('Malformed OHLC data')
        if candle['high'] < max(candle['open'], candle['close']) or candle['low'] > min(candle['open'], candle['close']):
            raise ValueError('Malformed candle range')
    old = candles[-(lookback+1):-1]
    last = candles[-1]
    if direction == 'buy':
        bos = last['close'] > max(x['high'] for x in old)
        fvg = candles[-3]['high'] < last['low']
    else:
        bos = last['close'] < min(x['low'] for x in old)
        fvg = candles[-3]['low'] > last['high']
    return {'confirmed': bos and fvg, 'reason': 'BOS + FVG' if bos and fvg else 'Structure or FVG not confirmed', 'bos': bos, 'fvg': fvg}


def performance(trades: list[dict], starting_balance: float = 10000) -> dict:
    """Closed-trade summary. Input P/L must be net of spread, fees and swaps."""
    if starting_balance <= 0:
        raise ValueError('Starting balance must be positive')
    pnl = [float(t['net_pnl']) for t in trades]
    if not all(isfinite(p) for p in pnl):
        raise ValueError('Invalid P/L')
    equity = starting_balance
    peak = equity
    max_dd = 0.0
    for p in pnl:
        equity += p
        peak = max(peak, equity)
        if peak > 0:
            max_dd = max(max_dd, (peak - equity) / peak * 100)
    wins = sum(1 for p in pnl if p > 0)
    gain = sum(p for p in pnl if p > 0)
    loss = -sum(p for p in pnl if p < 0)
    return {'trades': len(pnl), 'win_rate': round(100 * wins / len(pnl), 2) if pnl else 0,
            'net_pnl': round(sum(pnl), 2), 'profit_factor': round(gain / loss, 3) if loss else None,
            'max_drawdown_pct': round(max_dd, 2), 'expectancy': round(sum(pnl) / len(pnl), 2) if pnl else 0,
            'ending_balance': round(equity, 2)}


def backtest_bars(bars: list[dict], signals: list[dict], starting_balance: float = 10000) -> dict:
    """Simplified single-position close-of-bar test with conservative same-bar SL priority.

    signals: {index: int, side: buy|sell, sl: float, tp: float, volume: float,
    cash_per_price_unit: float, fee: float}. Entry at NEXT bar's open.
    Returns no promises of execution fidelity (no partial fills, financing, etc.).
    """
    trades = []
    used_to = -1
    for s in sorted(signals, key=lambda t: t['index']):
        i = int(s['index'])
        if i <= used_to or i + 1 >= len(bars):
            continue
        side = s['side']
        if side not in ('buy','sell'):
            continue
        entry = float(bars[i+1]['open'])
        sl, tp = float(s['sl']), float(s['tp'])
        if not ((sl < entry < tp) if side == 'buy' else (tp < entry < sl)):
            continue
        for j in range(i+1, len(bars)):
            bar = bars[j]
            sl_hit = bar['low'] <= sl if side == 'buy' else bar['high'] >= sl
            tp_hit = bar['high'] >= tp if side == 'buy' else bar['low'] <= tp
            if sl_hit or tp_hit or j == len(bars)-1:
                exit_price = sl if sl_hit else (tp if tp_hit else float(bar['close']))
                gross = (exit_price-entry) * (1 if side=='buy' else -1) * float(s['volume']) * float(s['cash_per_price_unit'])
                trades.append({'entry_index': i+1, 'exit_index': j,
                               'net_pnl': round(gross-float(s.get('fee',0)), 2),
                               'same_bar_ambiguous': sl_hit and tp_hit})
                used_to = j
                break
    return {'summary': performance(trades, starting_balance), 'trades': trades,
            'caveat': 'Research-only bar backtest. Same-bar SL/TP is scored as SL; account for fees, spread and slippage.'}
