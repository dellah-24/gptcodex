"""Shared cost inputs and timestamp parsing for historical replay."""
from dataclasses import asdict, dataclass
from datetime import datetime
import math


@dataclass(frozen=True)
class Costs:
    point: float
    slippage_points: float
    commission_bps: float
    buy_swap_bps: float
    sell_swap_bps: float

    def validate(self):
        if (not all(math.isfinite(value) for value in asdict(self).values()) or
                self.point <= 0 or min(self.slippage_points, self.commission_bps) < 0):
            raise ValueError('Use finite costs, a positive point, and nonnegative slippage and commission')
        return self


def utc_stamp(value):
    if value.isdecimal():
        return int(value)
    stamp = datetime.fromisoformat(value.replace('Z', '+00:00'))
    if stamp.tzinfo is None:
        raise ValueError('Use an explicit timezone or epoch seconds')
    return stamp.timestamp()
