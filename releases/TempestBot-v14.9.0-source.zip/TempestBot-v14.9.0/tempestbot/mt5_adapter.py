"""Explicitly opt-in MT5 connectivity: no order_send is exposed in this release.

The official MetaTrader5 module is typically used on Windows; Linux/macOS
clients need a Windows bridge/worker for execution, not a fake local adapter.
"""
import os
import platform
import subprocess
from pathlib import Path
from .core import canonical_symbol, ensure_server


def launch_terminal(path=None):
    """Launch a user-selected trusted local MT5 executable; no shell commands."""
    if path:
        p = Path(path).expanduser().resolve()
        if not p.is_file() or p.suffix.lower() not in ('.exe', '.app'):
            raise ValueError('Choose an existing MT5 terminal executable or macOS app')
        if p.suffix.lower() == '.app' and platform.system() == 'Darwin':
            return subprocess.Popen(['open', '-a', str(p)]).pid
        if platform.system() != 'Windows' and p.suffix.lower() == '.exe':
            return subprocess.Popen(['wine', str(p)]).pid
        return subprocess.Popen([str(p)]).pid
    if platform.system() == 'Windows':
        guesses = [Path(os.environ.get('PROGRAMFILES', 'C:/Program Files')) / 'MetaTrader 5/terminal64.exe']
        for candidate in guesses:
            if candidate.is_file():
                return subprocess.Popen([str(candidate)]).pid
    raise RuntimeError('MT5 path not detected; provide the executable path in settings')


def validate_live_account(login, password, server, approved_servers, symbol):
    """Validate connection parameters before any MT5 SDK call."""
    canonical_symbol(symbol)
    ensure_server(server, approved_servers)
    if not str(login).isdigit() or not password:
        raise ValueError('MT5 account credentials required')
    return True


def probe_account(login, password, server, approved_servers, terminal_path=None):
    """One-off connectivity check. Password is never stored or printed."""
    validate_live_account(login, password, server, approved_servers, 'XAUUSD')
    if platform.system() != 'Windows':
        raise RuntimeError('MT5 Python connection requires a separately configured Windows execution worker')
    try:
        import MetaTrader5 as mt5
    except ImportError as exc:
        raise RuntimeError('Install the official MetaTrader5 Python package on the Windows worker') from exc
    kwargs = {'login': int(login), 'password': password, 'server': server}
    if terminal_path:
        kwargs['path'] = str(Path(terminal_path).expanduser().resolve())
    try:
        if not mt5.initialize(**kwargs):
            raise RuntimeError(f'MT5 connection failed (code {mt5.last_error()[0]})')
        info = mt5.account_info()
        if info is None or str(info.login) != str(login):
            raise RuntimeError('Connected MT5 account does not match requested account')
        if not any('justmarkets' in str(v).lower() for v in [getattr(info, 'server', ''), getattr(info, 'company', '')]):
            raise RuntimeError('Connected account is not verified as JustMarkets')
        return {'login': str(info.login), 'server': str(info.server), 'company': str(info.company),
                'balance': float(info.balance), 'equity': float(info.equity)}
    finally:
        mt5.shutdown()
