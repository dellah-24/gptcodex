"""Local demo configuration store. Do not store broker passwords."""
import json
from pathlib import Path
from threading import RLock
from .core import ensure_server, canonical_symbol, RiskConfig

class Store:
    def __init__(self, path):
        self.path = Path(path)
        self.lock = RLock()
        self.data = {'servers': [], 'accounts': [], 'risk': vars(RiskConfig()),
                     'subscription': {'status': 'inactive', 'credits': 0},
                     'notifications': [], 'live_enabled': False}
        if self.path.exists():
            stored = json.loads(self.path.read_text())
            self.data.update({k:v for k,v in stored.items() if k in self.data and k != 'live_enabled'})
        self.data['live_enabled'] = False  # NEVER resume live trading on restart

    def save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix('.tmp')
        tmp.write_text(json.dumps(self.data, indent=2))
        tmp.chmod(0o600)
        tmp.replace(self.path)
        self.path.chmod(0o600)

    def add_server(self, name):
        with self.lock:
            if not isinstance(name, str) or len(name) > 100 or not name.strip():
                raise ValueError('Invalid server name')
            ensure_server(name, [name])
            if name not in self.data['servers']:
                self.data['servers'].append(name)
            self.save()

    def remove_server(self, name):
        with self.lock:
            if any(a['server'] == name for a in self.data['accounts']):
                raise ValueError('Cannot remove server while accounts reference it')
            self.data['servers'].remove(name)
            self.save()

    def add_account(self, login, server):
        with self.lock:
            ensure_server(server, self.data['servers'])
            login = str(login)
            if not login.isdigit() or not 4 <= len(login) <= 15:
                raise ValueError('Invalid MT5 login number')
            if any(a['login'] == login and a['server'] == server for a in self.data['accounts']):
                raise ValueError('Account already connected')
            if len(self.data['accounts']) >= 2:
                raise ValueError('Maximum of two broker accounts')
            self.data['accounts'].append({'login':login, 'server':server, 'status':'configured (not authenticated)'})
            self.save()

    def set_risk(self, incoming):
        with self.lock:
            allowed = set(vars(RiskConfig()))
            if set(incoming) - allowed:
                raise ValueError('Unsupported risk setting')
            data = dict(self.data['risk'])
            data.update(incoming)
            cfg = RiskConfig(**data).validate()
            self.data['risk'] = vars(cfg)
            self.save()
