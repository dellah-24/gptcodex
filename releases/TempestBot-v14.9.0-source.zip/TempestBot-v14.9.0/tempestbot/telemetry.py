"""Private, bounded MT5 telemetry. Cloud delivery runs outside the trading loop."""
import json
import math
from queue import Empty, Full, Queue
from threading import Thread
import time

from .live import MAGIC
from .shared import SharedError


class Telemetry:
    def __init__(self, transport, label, logger):
        self.queue = Queue(maxsize=1)
        self.last = float('-inf')
        self.thread = Thread(target=self._publish, args=(transport, label, logger), daemon=True)
        self.thread.start()

    def _publish(self, transport, label, logger):
        while True:
            snapshot = self.queue.get()
            try:
                transport.rpc('publish_worker_telemetry', {'worker_label': label, 'worker_snapshot': snapshot})
            except (SharedError, ValueError) as error:
                logger.warning('Worker telemetry could not sync: %s', error)

    def sample(self, mt5, journal, login, server, mode, state, decisions):
        now = time.monotonic()
        if now - self.last < 8:
            return
        self.last = now
        account = mt5.account_info()
        positions = mt5.positions_get()
        verified = mt5.account_info()
        readable = (positions is not None and account is not None and account.login == login
                    and account.server.casefold() == server.casefold() and verified is not None
                    and verified.login == login and verified.server.casefold() == server.casefold())
        visible = []
        if readable:
            for position in positions:
                if position.magic != MAGIC:
                    continue
                prices = [position.price_open, position.sl, position.tp, position.profit, position.volume]
                if not all(math.isfinite(value) for value in prices):
                    continue
                visible.append(dict(ticket=str(position.ticket), symbol=position.symbol, side='buy' if position.type == 0 else 'sell',
                                    opened_at=position.time, entry=position.price_open, sl=position.sl, tp=position.tp,
                                    pnl=position.profit, volume=position.volume))
        events = []
        prefix = f'{login}:{server.casefold()}:%'
        for event_id, key, symbol, status, payload, created in journal.db.execute(
            """SELECT id,order_key,symbol,status,data,timestamp FROM order_events
                 WHERE account=? AND order_key LIKE ?
                UNION ALL
                SELECT -rowid,key,symbol,status,data,timestamp FROM orders
                 WHERE account=? AND key LIKE ?
                   AND NOT EXISTS(SELECT 1 FROM order_events WHERE order_key=orders.key)
                ORDER BY timestamp DESC, id DESC LIMIT 40""",
            (login, prefix, login, prefix),
        ):
            record = json.loads(payload)
            receipt = record.get('result', {})
            evidence = record.get('broker_evidence', {})
            events.append(dict(id=event_id, order_ref=key.split(':',2)[-1],
                               symbol=symbol, action='Exit' if key.endswith(':exit') else 'Entry', status=status,
                               at=created.replace(' ', 'T')+'Z', volume=evidence.get('volume', receipt.get('volume')),
                               retcode=receipt.get('retcode')))
        snapshot = dict(mode=mode, state=state, currency=getattr(account, 'currency', '') if readable else '',
                        positions=visible[:50] if readable else None, events=events, decisions=list(decisions.values()))
        try:
            self.queue.put_nowait(snapshot)
        except Full:
            try:
                self.queue.get_nowait()
            except Empty:
                pass
            self.queue.put_nowait(snapshot)
