"""Read-only MT5 reconciliation. Only unambiguous broker evidence releases a hold."""
import json
import math
from datetime import datetime, timedelta, timezone

from .live import MAGIC, UNRESOLVED, verify_identity


def _ours(item, symbol):
    return item.magic == MAGIC and item.symbol.casefold() == symbol.casefold()


def _settlement(mt5, order, deals, requested):
    """Compare all execution deals to the broker's final remaining volume."""
    filled = getattr(mt5, 'ORDER_STATE_FILLED', 4)
    other_final = {getattr(mt5, 'ORDER_STATE_CANCELED', 2),
                   getattr(mt5, 'ORDER_STATE_REJECTED', 5),
                   getattr(mt5, 'ORDER_STATE_EXPIRED', 6)}
    if (order.state != filled and order.state not in other_final) or not math.isclose(
        order.volume_initial, requested, abs_tol=1e-8
    ):
        return None
    expected = order.volume_initial if order.state == filled else order.volume_initial - order.volume_current
    volume = sum(d.volume for d in deals)
    if not 0 <= volume <= requested + 1e-8 or not math.isclose(volume, expected, abs_tol=1e-8):
        return None
    if order.state == filled and not math.isclose(volume, requested, abs_tol=1e-8):
        return None
    # A market order can be canceled/expired without any execution.
    status = 'FILLED' if math.isclose(volume, requested, abs_tol=1e-8) else 'PARTIAL_SETTLED' if volume else 'REJECTED'
    return status, {'order': order.ticket, 'volume': volume, 'broker_state': order.state,
                    'deals': [d.ticket for d in deals],
                    'positions': sorted({d.position_id for d in deals if d.position_id})}


def audit_account(mt5, journal, login, server):
    """Reconcile unresolved entries, then compare live exposure with journal evidence."""
    verify_identity(mt5, login, server)
    prefix = f'{login}:{server.casefold()}:'
    positions, active = mt5.positions_get(), mt5.orders_get()
    if positions is None or active is None:
        return ['Broker positions or active orders could not be read']
    rows = journal.db.execute(
        "SELECT key,symbol,data,timestamp FROM orders WHERE account=? AND status IN (?,?,?,?,?)",
        (login, *UNRESOLVED),
    ).fetchall()
    for key, symbol, payload, timestamp in rows:
        if not key.startswith(prefix):
            continue
        record = json.loads(payload)
        request, result = record.get('request', record), record.get('result', {})
        ticket, comment = result.get('order'), request.get('comment', '')
        requested = request.get('volume') or result.get('requested_volume')
        if not requested or not (ticket or comment.startswith('TB-')):
            continue
        if ticket:
            history = mt5.history_orders_get(ticket=ticket)
        else:
            start = datetime.fromisoformat(timestamp).replace(tzinfo=timezone.utc) - timedelta(minutes=1)
            history = mt5.history_orders_get(start, datetime.now(timezone.utc))
        if history is None:
            continue
        matches = [o for o in history if _ours(o, symbol) and
                   (o.ticket == ticket if ticket else o.comment == comment)]
        if len(matches) != 1:
            continue
        order = matches[0]
        if any(o.ticket == order.ticket for o in active):
            continue
        deals = mt5.history_deals_get(ticket=order.ticket)
        if deals is None or any(not _ours(d, symbol) or d.order != order.ticket or
                                d.type != request.get('type', d.type)
                                for d in deals):
            continue
        settlement = _settlement(mt5, order, deals, requested)
        if settlement:
            status, evidence = settlement
            if request.get('position') and (
                any(d.position_id != request.get('position_identifier', request['position']) or
                    d.entry != getattr(mt5, 'DEAL_ENTRY_OUT', 1) for d in deals)
                or (status == 'FILLED' and any(p.symbol.casefold() == symbol.casefold() for p in positions))
            ):
                continue
            verify_identity(mt5, login, server)
            with journal.db:
                journal.db.execute(
                    "UPDATE orders SET status=?, data=json_set(data,'$.broker_evidence',json(?)) WHERE key=?",
                    (status, json.dumps(evidence), key),
                )

    modifications = journal.db.execute(
        'SELECT key,ticket,symbol,data FROM modifications WHERE account=? AND status IN (?,?,?,?,?)',
        (login, *UNRESOLVED),
    ).fetchall()
    by_ticket = {position.ticket: position for position in positions}
    for key, ticket, symbol, payload in modifications:
        position = by_ticket.get(ticket)
        record = json.loads(payload)
        request = record.get('request', record)
        if position is None or not _ours(position, symbol) or request.get('server') != server.casefold():
            continue
        if not all(name in request and request[name] > 0 and
                   math.isclose(request[name], getattr(position, name), rel_tol=0, abs_tol=1e-8)
                   for name in ('sl', 'tp')):
            continue
        verify_identity(mt5, login, server)
        with journal.db:
            journal.db.execute(
                "UPDATE modifications SET status='CONFIRMED',data=json_set(data,'$.broker_evidence',json(?)) WHERE key=?",
                (json.dumps({'ticket': ticket, 'sl': position.sl, 'tp': position.tp}), key),
            )

    issues = []
    if any(o.magic == MAGIC for o in active):
        issues.append('An active TempestBot order still needs settlement')
    for position in positions:
        if position.magic != MAGIC:
            continue
        if not (math.isfinite(position.sl) and position.sl > 0 and
                math.isfinite(position.tp) and position.tp > 0):
            issues.append(f'Position {position.ticket} lacks broker-side protection')
        position_id = getattr(position, 'identifier', position.ticket)
        deals = mt5.history_deals_get(position=position_id)
        if deals is None:
            issues.append(f'Position {position.ticket} history is unavailable')
            continue
        known = False
        for deal in deals:
            if not _ours(deal, position.symbol) or deal.entry not in (
                getattr(mt5, 'DEAL_ENTRY_IN', 0), getattr(mt5, 'DEAL_ENTRY_INOUT', 2)
            ):
                continue
            if journal.db.execute(
                """SELECT 1 FROM orders WHERE account=? AND symbol=? COLLATE NOCASE
                   AND (json_extract(data,'$.result.deal')=? OR json_extract(data,'$.deal')=?
                        OR json_extract(data,'$.broker_evidence.order')=?
                        OR json_extract(data,'$.previous.result.deal')=?
                        OR json_extract(data,'$.operator_deal')=?) LIMIT 1""",
                (login, position.symbol, deal.ticket, deal.ticket, deal.order, deal.ticket, deal.ticket),
            ).fetchone():
                known = True
                break
        if not known:
            issues.append(f'Position {position.ticket} is missing a matching local journal entry')
    return issues
