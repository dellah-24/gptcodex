"""Low-priority, independent learning supervisor. NEVER imports or invokes MT5.

Market ingestion is performed by the separate guarded MT5 worker. This service
consumes the existing learning SQLite store and schedules challenger training only.
"""
import argparse
import json
import logging
import os
import signal
import subprocess
import sys
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path
from .adaptive import LearningStore

INTERVAL_SECONDS = 24 * 3600
POLL_SECONDS = 60
MIN_BARS = 600
MIN_NEW_BARS = 144
SYMBOLS = ('XAUUSD', 'BTCUSD')
LOG = logging.getLogger('tempestbot.background')


def atomic_json(path, payload):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile('w', encoding='utf-8', dir=path.parent, prefix='.state-', delete=False) as file:
        tmp = Path(file.name)
        json.dump(payload, file, indent=2)
        file.flush()
        os.fsync(file.fileno())
    os.replace(tmp, path)


def read_json(path, fallback=None):
    try:
        obj = json.loads(Path(path).read_text(encoding='utf-8'))
        return obj if isinstance(obj, dict) else (fallback or {})
    except (FileNotFoundError, ValueError, OSError):
        return fallback or {}


def due(last, latest, count, now, new_bar_count=None):
    """Only retrain with enough distinct CLOSED bars and >=24h since last attempt.

    A persistent last_attempt prevents rapid retrains after app restarts/failures.
    """
    if count < MIN_BARS or latest is None:
        return False, 'insufficient_closed_bars'
    if last and now - float(last.get('attempted_at', 0)) < INTERVAL_SECONDS:
        return False, 'waiting_24_hours'
    if last and (new_bar_count if new_bar_count is not None else max(0, (latest - int(last.get('latest_bar_time', 0))) // 600)) < MIN_NEW_BARS:
        return False, 'insufficient_new_bars'
    return True, 'eligible'


class ProcessLock:
    """File lock held for service lifetime; no PID-race or stale lock files."""
    def __init__(self, path):
        self.path = Path(path)
        self.fp = None

    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.fp = open(self.path, 'a+b')
        try:
            if os.name == 'nt':
                import msvcrt
                self.fp.seek(0)
                self.fp.write(b'0')
                self.fp.flush()
                self.fp.seek(0)
                msvcrt.locking(self.fp.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.fp.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except (OSError, IOError):
            self.fp.close()
            self.fp = None
            raise RuntimeError('Background service already running')
        return self

    def __exit__(self, *_):
        if self.fp:
            if os.name == 'nt':
                import msvcrt
                self.fp.seek(0)
                msvcrt.locking(self.fp.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.fp.fileno(), fcntl.LOCK_UN)
            self.fp.close()


def lower_priority():
    """Best effort; do not elevate permissions or change executor priority."""
    try:
        if os.name == 'nt':
            import ctypes
            # Windows BELOW_NORMAL_PRIORITY_CLASS
            ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x4000)
        else:
            os.nice(15)
    except (OSError, AttributeError):
        LOG.warning('Unable to lower process priority')


def training_env():
    env = os.environ.copy()
    for key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS',
                'NUMEXPR_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS'):
        env[key] = '1'
    env['PYTHONUNBUFFERED'] = '1'
    return env


def train_separately(symbol, root, timeout=3600):
    """Separate process; no subprocess inherits MT5 credentials or live opt-in."""
    env = training_env()
    for key in ('TEMPESTBOT_MT5_PASSWORD', 'TEMPESTBOT_LIVE_ENABLED'):
        env.pop(key, None)
    cmd = [sys.executable, '-m', 'tempestbot.background', '--train-once',
           '--symbol', symbol, '--data-dir', str(root)]
    try:
        result = subprocess.run(cmd, cwd=str(Path(__file__).resolve().parent.parent),
                                capture_output=True, text=True, timeout=timeout, env=env, check=False)
        if result.returncode != 0:
            return {'ok': False, 'message': (result.stderr or result.stdout)[-600:]}
        return {'ok': True, 'message': result.stdout[-600:]}
    except (subprocess.TimeoutExpired, OSError) as exc:
        return {'ok': False, 'message': str(exc)[-600:]}


def single_pass(root, now=None, trainer=train_separately):
    root = Path(root)
    now = time.time() if now is None else now
    statefile = root / 'background_state.json'
    state = read_json(statefile)
    result = {'pid': os.getpid(), 'last_checked': datetime.fromtimestamp(now, timezone.utc).isoformat(),
              'service': 'running', 'market_source': 'guarded_mt5_worker',
              'deployment': 'manual_only', 'interval_hours': 24, 'symbols': {}}
    store = LearningStore(root)
    try:
        for symbol in SYMBOLS:
            row = store.db.execute('SELECT COUNT(*),MAX(time) FROM bars WHERE symbol=?', (symbol,)).fetchone()
            count, latest = row
            previous = state.get(symbol)
            new_bars = (store.db.execute('SELECT COUNT(*) FROM bars WHERE symbol=? AND time>?',
                         (symbol, int(previous.get('latest_bar_time', 0)))).fetchone()[0] if previous else count)
            eligible, reason = due(previous, latest, count, now, new_bar_count=new_bars)
            entry = {'closed_bars': count, 'new_closed_bars': new_bars, 'latest_closed_bar_time': latest, 'reason': reason,
                     'last_attempt': previous, 'monitor': store.monitoring(symbol)}
            if eligible:
                # Persist attempt BEFORE training to avoid retry storms across crashes/restarts.
                state[symbol] = {'attempted_at': now, 'latest_bar_time': latest, 'status': 'started'}
                atomic_json(statefile, state)
                outcome = trainer(symbol, root)
                state[symbol]['status'] = 'candidate_created' if outcome['ok'] else 'failed'
                state[symbol]['result'] = outcome['message']
                atomic_json(statefile, state)
                store.log(symbol, 'background_retraining', {'ok': outcome['ok'], 'result': outcome['message']})
                entry['last_attempt'] = state[symbol]
                entry['reason'] = state[symbol]['status']
            result['symbols'][symbol] = entry
    finally:
        store.close()
    atomic_json(root / 'background_status.json', result)
    return result


def train_once(symbol, root):
    lower_priority()
    from .adaptive import train_candidate
    store = LearningStore(root)
    try:
        print(json.dumps(train_candidate(store, symbol)))
    finally:
        store.close()


def service(root, once=False):
    root = Path(root).expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(level=logging.INFO, filename=str(root / 'background.log'),
                        format='%(asctime)s %(levelname)s %(message)s')
    lower_priority()
    with ProcessLock(root / '.background.lock'):
        while True:
            try:
                single_pass(root)
            except Exception:
                LOG.exception('Learning cycle error; live execution remains separate')
                atomic_json(root / 'background_status.json', {
                    'service': 'error', 'pid': os.getpid(), 'last_checked': datetime.now(timezone.utc).isoformat(),
                    'message': 'Check background.log; no live trades were attempted'})
            if once:
                return
            time.sleep(POLL_SECONDS)


def start_detached(root):
    """Start independently of the dashboard; existing instance is harmless."""
    root = Path(root).expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True)
    log = open(root / 'background_launcher.log', 'ab', buffering=0)
    try:
        kw = {'stdin': subprocess.DEVNULL, 'stdout': log, 'stderr': subprocess.STDOUT,
              'cwd': str(Path(__file__).resolve().parent.parent), 'env': training_env()}
        if os.name == 'nt':
            kw['creationflags'] = subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.DETACHED_PROCESS
        else:
            kw['start_new_session'] = True
        proc = subprocess.Popen([sys.executable, '-m', 'tempestbot.background', '--service',
                                 '--data-dir', str(root)], **kw)
        return proc.pid
    finally:
        log.close()


def main(argv=None):
    p=argparse.ArgumentParser(description='TempestBot isolated low-resource background learning')
    p.add_argument('--data-dir', type=Path, default=Path.home() / '.tempestbot' / 'learning')
    modes=p.add_mutually_exclusive_group(required=True)
    modes.add_argument('--service', action='store_true')
    modes.add_argument('--once', action='store_true')
    modes.add_argument('--train-once', action='store_true')
    p.add_argument('--symbol', choices=SYMBOLS)
    args=p.parse_args(argv)
    if args.train_once:
        if not args.symbol:p.error('--train-once requires --symbol')
        train_once(args.symbol,args.data_dir)
    else:
        service(args.data_dir, once=args.once)


if __name__=='__main__':
    main()
