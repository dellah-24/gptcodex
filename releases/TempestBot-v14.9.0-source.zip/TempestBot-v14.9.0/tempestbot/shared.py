"""Supabase shared learning transport. No MT5 or order submission in this module.

Client uses per-user Supabase Auth JWT; server uses a secret service key only on a
trusted backend. Users upload completed OHLCV bars and read immutable global signals.
"""
import json
import math
import os
import re
import time
from datetime import datetime, timezone
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from urllib.error import HTTPError

SYMBOLS = ('XAUUSD','BTCUSD')

class SharedError(RuntimeError): pass


def normalize_symbol(symbol):
    if not isinstance(symbol,str) or not re.fullmatch(r'(XAUUSD|BTCUSD)(?:m|\.m|\.[a-zA-Z0-9]{1,3})?',symbol,re.I):
        raise ValueError('Only XAUUSD/BTCUSD allowed')
    return symbol.upper()[:6]


def closed_bar(symbol,row,now=None):
    base=normalize_symbol(symbol)
    t=int(row['time'])
    now=time.time() if now is None else now
    # Only time-aligned, completed M10 bars; prohibit far-past/future garbage.
    if t<=0 or t % 600 or t+600>now or t<now-366*86400:
        raise ValueError('Bar must be a completed M10 candle within one year')
    values=[float(row[k]) for k in ('open','high','low','close','tick_volume')]
    o,h,l,c,v=values
    if not all(math.isfinite(x) for x in values) or min(o,h,l,c)<=0 or v<0 or h<max(o,c,l) or l>min(o,c):
        raise ValueError('Invalid OHLCV')
    return {'symbol':base,'timeframe':'M10','bar_time':t,'open':o,'high':h,'low':l,'close':c,'tick_volume':v}


class SupabaseTransport:
    def __init__(self,url,key,token=None,requester=None):
        if not isinstance(url,str) or not url.startswith('https://'):
            raise ValueError('Supabase URL must be HTTPS')
        if not key: raise ValueError('Missing Supabase key')
        self.url=url.rstrip('/')+'/rest/v1/'
        self.key=key
        self.token=token or key
        self.requester=requester

    def request(self,table,method='GET',params=None,body=None,prefer=None):
        if table not in ('market_contributions','canonical_bars','shared_signals','shared_model_registry','trade_outcomes'):
            raise ValueError('Disallowed table')
        url=self.url+table+('?' + urlencode(params) if params else '')
        headers={'apikey':self.key,'Authorization':'Bearer '+self.token,'Accept':'application/json'}
        if body is not None: headers['Content-Type']='application/json'
        if prefer: headers['Prefer']=prefer
        req=Request(url, data=json.dumps(body).encode('utf8') if body is not None else None,
                    headers=headers,method=method)
        try:
            if self.requester:
                status,payload=self.requester(req)
            else:
                with urlopen(req,timeout=12) as res:
                    status,payload=res.status,res.read()
        except HTTPError as exc:
            raise SharedError(f'Supabase request rejected: HTTP {exc.code}') from exc
        except OSError as exc:
            raise SharedError('Supabase unavailable (no orders should depend on this request)') from exc
        if not 200<=status<300: raise SharedError(f'Supabase HTTP {status}')
        return json.loads(payload) if payload else []


    def rpc(self,function,payload):
        if function not in ('approve_shared_model', 'publish_worker_heartbeat', 'publish_worker_telemetry', 'sync_improvement_review', 'improvement_profile_is_approved'):
            raise ValueError('RPC not allowlisted')
        url=self.url.replace('/rest/v1/','/rest/v1/rpc/')+function
        headers={'apikey':self.key,'Authorization':'Bearer '+self.token,
                 'Accept':'application/json','Content-Type':'application/json'}
        req=Request(url,data=json.dumps(payload).encode('utf8'),headers=headers,method='POST')
        try:
            if self.requester:status,body=self.requester(req)
            else:
                with urlopen(req,timeout=3 if function.startswith('publish_worker_') else 12) as res:
                    status,body=res.status,res.read()
        except (OSError,HTTPError) as exc:raise SharedError('Supabase RPC failed') from exc
        if not 200<=status<300:raise SharedError(f'Supabase RPC HTTP {status}')
        return json.loads(body) if body else None


class UserHub:
    def __init__(self,transport): self.db=transport

    def contribute(self,symbol,rows,now=None):
        if not rows:return 0
        prepared=[closed_bar(symbol,r,now=now) for r in rows]
        # user_id comes exclusively from auth.uid() DB default and RLS.
        for i in range(0,len(prepared),100):
            self.db.request('market_contributions',method='POST',body=prepared[i:i+100],
                            params={'on_conflict':'user_id,symbol,bar_time'},prefer='resolution=ignore-duplicates,return=minimal')
        return len(prepared)

    def latest_signal(self,symbol,now=None):
        base=normalize_symbol(symbol)
        data=self.db.request('shared_signals',params={
            'select':'id,symbol,timeframe,candle_time,direction,model_version,strategy_version,confidence,expires_at,created_at',
            'symbol':'eq.'+base,'order':'candle_time.desc','limit':'1'})
        if not data:return None
        signal=data[0]
        if signal['symbol']!=base or signal['timeframe']!='M10' or signal['direction'] not in ('buy','sell','flat'):
            raise SharedError('Invalid shared signal')
        now_dt=datetime.now(timezone.utc) if now is None else datetime.fromtimestamp(now,timezone.utc)
        expiry=datetime.fromisoformat(signal['expires_at'].replace('Z','+00:00'))
        if expiry.tzinfo is None or expiry<=now_dt or int(signal['candle_time'])<=0:
            return None
        return signal


class CentralHub:
    """Must run on a trusted server. Never give its secret key to client installations."""
    def __init__(self,transport):self.db=transport

    def contributions(self,symbol,since,limit=1000):
        base=normalize_symbol(symbol)
        return self.db.request('market_contributions',params={
            'select':'user_id,symbol,bar_time,open,high,low,close,tick_volume',
            'symbol':'eq.'+base,'bar_time':'gt.'+str(int(since)),
            'order':'bar_time.asc','limit':str(min(limit,1000))})

    def publish_canonical(self,rows):
        if not rows:return
        self.db.request('canonical_bars',method='POST',body=rows,
                        params={'on_conflict':'symbol,bar_time'},prefer='resolution=ignore-duplicates,return=minimal')

    def publish_signal(self,symbol,candle_time,direction,confidence,model_version,strategy_version,expires_at):
        base=normalize_symbol(symbol)
        if direction not in ('buy','sell','flat') or not 0<=confidence<=1 or not math.isfinite(confidence):
            raise ValueError('Invalid signal')
        if not re.fullmatch(r'[A-Za-z0-9._-]{1,96}',model_version) or not re.fullmatch(r'[A-Za-z0-9._-]{1,96}',strategy_version):
            raise ValueError('Invalid version')
        candle_time=int(candle_time)
        dt=datetime.fromisoformat(expires_at.replace('Z','+00:00'))
        if dt.tzinfo is None or dt.timestamp()<=time.time() or dt.timestamp()>time.time()+900:
            raise ValueError('Signal expiry must be within next 15 minutes')
        self.db.request('shared_signals',method='POST',body={
            'symbol':base,'timeframe':'M10','candle_time':candle_time,'direction':direction,
            'confidence':float(confidence),'model_version':model_version,
            'strategy_version':strategy_version,'expires_at':dt.isoformat()},
            prefer='return=minimal')


def consensus_bars(contributions,relative_close_tolerance=0.002,min_users=2):
    """Conservatively admit bar only when >=2 DIFFERENT users agree on prices.

    Market observations are not trusted as model input merely because uploaded.
    For production, source data should be verified independently from broker feed.
    """
    from collections import defaultdict
    from statistics import median
    groups=defaultdict(dict)
    for r in contributions:
        try:
            if normalize_symbol(r['symbol'])!=r['symbol']:continue
            t=int(r['bar_time'])
            if t%600:continue
            user=str(r['user_id'])
            vals=[float(r[x]) for x in ('open','high','low','close','tick_volume')]
            o,h,l,c,v=vals
            if not all(math.isfinite(n) for n in vals) or min(o,h,l,c)<=0 or v<0 or h<max(o,c,l) or l>min(o,c):continue
            groups[(r['symbol'],t)][user]=vals
        except (ValueError,KeyError,TypeError):continue
    output=[]
    for (symbol,t),users in groups.items():
        if len(users)<min_users:continue
        vals=list(users.values())
        middles=[median(v[i] for v in vals) for i in range(5)]
        if any(abs(v[i]-middles[i])/middles[i]>relative_close_tolerance for v in vals for i in range(4)):
            continue
        o,h,l,c,v=middles
        output.append({'symbol':symbol,'bar_time':t,'open':o,'high':max(h,o,c),
                       'low':min(l,o,c),'close':c,'tick_volume':v,'contributors':len(users)})
    return sorted(output,key=lambda r:(r['symbol'],r['bar_time']))


def _user_outcome(self, signal_id, deal_id, symbol, net_r_multiple, closed_at):
    import uuid
    uuid.UUID(str(signal_id))
    base=normalize_symbol(symbol)
    r=float(net_r_multiple)
    if not math.isfinite(r) or not -100<=r<=100 or not 1<=len(str(deal_id))<=128:
        raise ValueError('Invalid trade outcome')
    dt=datetime.fromisoformat(closed_at.replace('Z','+00:00'))
    if dt.tzinfo is None:raise ValueError('Timezone-aware close time required')
    # Do not send broker account numbers, personal information or credentials.
    return self.db.request('trade_outcomes',method='POST',body={
        'signal_id':str(signal_id),'local_deal_id':str(deal_id),'symbol':base,
        'net_r_multiple':r,'closed_at':dt.isoformat()},
        params={'on_conflict':'user_id,local_deal_id'},prefer='resolution=ignore-duplicates,return=minimal')

UserHub.contribute_outcome = _user_outcome
