"""Replay bundled models on chronological, post-training MT5 bid M10 candles."""
import argparse
import csv
from dataclasses import asdict
from datetime import datetime, timezone
import json
import math
from pathlib import Path

from .replay_costs import Costs, utc_stamp
from .core import RiskConfig, performance, risk_gate, smc_ict_confirm
from .live import ExecutionBlocked, base_symbol
from .runner import bracket, candle_decision, candle_frame, model_features

SECONDS_PER_DAY = 86400
FIELDS = ('open', 'high', 'low', 'close', 'tick_volume', 'spread')


def read_bars(path):
    rows = []
    with path.open(newline='', encoding='utf-8-sig') as file:
        reader = csv.DictReader(file)
        if not {'time', *FIELDS}.issubset(reader.fieldnames or []):
            raise ValueError('CSV needs time, bid OHLC, tick_volume and spread (in broker points)')
        for source in reader:
            stamp = utc_stamp(source['time'])
            row = {name: float(source[name]) for name in FIELDS}
            if (not all(math.isfinite(value) for value in row.values()) or
                    min(row[k] for k in FIELDS[:4]) <= 0 or
                    min(row['spread'], row['tick_volume']) < 0 or
                    not row['low'] <= min(row['open'], row['close']) <= max(row['open'], row['close']) <= row['high']):
                raise ValueError(f'Malformed OHLC or spread at {source["time"]}')
            if stamp <= 0 or stamp % 600 or stamp + 600 > datetime.now(timezone.utc).timestamp():
                raise ValueError(f'Expected completed, aligned M10 bar at {source["time"]}')
            if rows and stamp <= rows[-1]['time']:
                raise ValueError('Bar timestamps must increase strictly')
            rows.append({'time': int(stamp), **row})
    return rows


def check_lookahead(frame, symbol, index):
    """Compare model inputs with and without subsequent candles, from the same warmup."""
    import numpy as np

    prefix = frame.iloc[index - 599:index + 1]
    target = prefix.iloc[-1]['Date']
    expected, _ = model_features(prefix, symbol)
    extended = frame.iloc[index - 599:index + 19]
    actual, _ = model_features(extended, symbol, target)
    columns = [name for name in expected if not np.allclose(expected[name], actual[name], rtol=1e-8, atol=1e-8)]
    if columns:
        raise ValueError(f'Lookahead check failed for {symbol} at {target}: {", ".join(columns)}')


def close_trade(bars, first, end, side, stop, target, costs):
    """Use executable bid/ask sides, adverse gaps, and stop-first same-bar ordering."""
    sign = 1 if side == 'buy' else -1
    for index in range(first, end):
        bar = bars[index]
        offset = bar['spread'] * costs.point if side == 'sell' else 0
        opening, low, high, closing = (bar[name] + offset for name in ('open', 'low', 'high', 'close'))
        stop_hit = low <= stop if sign == 1 else high >= stop
        target_hit = high >= target if sign == 1 else low <= target
        if stop_hit:
            return index, min(stop, opening) if sign == 1 else max(stop, opening), 'stop'
        if target_hit:
            return index, target, 'target'
        if index == end - 1:
            return index, closing, 'fold_close'
    raise ValueError('Cannot exit a historical trade without price data')


def replay_fold(rows, frame, symbol, start, end, costs, threshold, starting_balance, risk):
    trades = []
    balance = starting_balance
    day_balance = starting_balance
    day = None
    halted = False
    used_until = start - 1
    feature_blocks = 0
    for index in range(start, end - 1):
        entry_index = index + 1
        entry_bar = rows[entry_index]
        entry_day = entry_bar['time'] // SECONDS_PER_DAY
        if used_until >= index or entry_bar['time'] != rows[index]['time'] + 600:
            continue
        if entry_day != day:
            day, day_balance, halted = entry_day, balance, False
        if halted or balance <= 0:
            continue
        closed = rows[index - 39:index + 1]
        # Avoid running the feature pipeline when neither side can pass its required SMC rule.
        if not any(smc_ict_confirm(closed, side)['confirmed'] for side in ('buy', 'sell')):
            continue
        try:
            side, _, _, confirmation, atr = candle_decision(frame.iloc[index - 599:index + 1], symbol, threshold)
        except ExecutionBlocked:
            feature_blocks += 1
            continue
        if not side or not confirmation['confirmed']:
            continue

        sign = 1 if side == 'buy' else -1
        spread = entry_bar['spread'] * costs.point
        quote = entry_bar['open'] + (spread if side == 'buy' else 0)
        slip = costs.slippage_points * costs.point
        stop, target = bracket(side, quote, atr)
        allowed, _ = risk_gate(config=risk, day_start_equity=day_balance, current_equity=balance,
                              positions=0, spread=spread, stop_distance=abs(quote - stop),
                              reward_distance=abs(target - quote), subscribed=True, enabled=True)
        if not allowed:
            continue
        entry = quote + sign * slip
        units = balance * min(risk.risk_percent, risk.max_exposure_percent) / (100 * abs(entry - stop))
        used_until, exit_quote, reason = close_trade(rows, entry_index, end, side, stop, target, costs)
        exit_price = exit_quote - sign * slip
        commission = units * (entry + exit_price) * costs.commission_bps / 10000
        exit_day = rows[used_until]['time'] // SECONDS_PER_DAY
        swap_rate = costs.buy_swap_bps if side == 'buy' else costs.sell_swap_bps
        swap = units * entry * swap_rate * (exit_day - entry_day) / 10000
        pnl = sign * (exit_price - entry) * units - commission - swap
        trades.append({'side': side, 'entry_time': entry_bar['time'], 'exit_time': rows[used_until]['time'],
                       'exit_reason': reason, 'commission': commission, 'swap': swap, 'net_pnl': pnl})
        balance += pnl
        if exit_day != day:
            day, day_balance = exit_day, balance - pnl
        halted = balance <= day_balance * (1 - risk.daily_loss_percent / 100)
    return trades, feature_blocks


def validate(path, symbol, cutoff, costs, *, fold_bars=1008, threshold=.62,
             starting_balance=10000, risk=None):
    costs.validate()
    if not (fold_bars >= 20 and .5 <= threshold <= .95 and math.isfinite(starting_balance) and starting_balance > 0):
        raise ValueError('Require at least 20 bars per fold, threshold 0.50–0.95, and positive balance')
    rows = read_bars(path)
    frame = candle_frame(rows)
    first = next((i for i in range(599, len(rows)) if rows[i]['time'] >= cutoff), len(rows))
    if len(rows) - first < 20:
        raise ValueError('Need 600-bar warmup and at least 20 evaluation bars after the model development cutoff')
    risk = (risk or RiskConfig()).validate()
    all_trades, folds = [], []
    balance = starting_balance
    for start in range(first, len(rows), fold_bars):
        end = min(start + fold_bars, len(rows))
        if end - start < 20 or balance <= 0:
            break
        samples = sorted({start, (start + end) // 2, end - 2})
        for index in samples:
            check_lookahead(frame, symbol, index)
        trades, blocks = replay_fold(rows, frame, symbol, start, end, costs, threshold, balance, risk)
        summary = performance(trades, balance)
        balance += sum(trade['net_pnl'] for trade in trades)
        folds.append({'first_bar': rows[start]['time'], 'last_bar': rows[end - 1]['time'],
                      'lookahead_samples': len(samples), 'feature_blocks': blocks, **summary})
        all_trades.extend(trades)
    return {'symbol': base_symbol(symbol), 'development_cutoff': cutoff,
            'training_overlap_independently_verified': False,
            'costs': asdict(costs), 'risk': asdict(risk), 'threshold': threshold,
            'folds': folds, 'excluded_tail_bars': sum(row['time'] > folds[-1]['last_bar'] for row in rows),
            'combined': performance(all_trades, starting_balance), 'trades': all_trades,
            'assumptions': ['Frozen bundled model; fixed-parameter chronological folds.',
                            'User supplies the latest date used for training, calibration or selection.',
                            'Per-symbol replay with fractional units, bid candles and bar-level spread.',
                            'Swap is a signed cost per UTC midnight; use broker-specific cost estimates.',
                            'Fold-end exits, realized equity only; shared/adaptive signals, protective updates, margin and partial fills are excluded.']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('csv', type=Path)
    parser.add_argument('--symbol', choices=('XAUUSD', 'BTCUSD'), required=True)
    parser.add_argument('--development-cutoff', type=utc_stamp, required=True,
                        help='UTC start of untouched evaluation data. Use a date strictly after all model development.')
    parser.add_argument('--fold-bars', type=int, default=1008)
    parser.add_argument('--threshold', type=float, default=.62)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--starting-balance', type=float, default=10000)
    parser.add_argument('--risk', type=float, default=.5)
    parser.add_argument('--daily-loss', type=float, default=2)
    parser.add_argument('--max-exposure', type=float, default=2)
    for name in ('point', 'slippage-points', 'commission-bps', 'buy-swap-bps', 'sell-swap-bps'):
        parser.add_argument('--' + name, type=float, required=True)
    args = parser.parse_args()
    if args.csv.resolve() == args.out.resolve():
        parser.error('Use a separate path for the JSON report')
    costs = Costs(args.point, args.slippage_points, args.commission_bps, args.buy_swap_bps, args.sell_swap_bps)
    try:
        risk = RiskConfig(risk_percent=args.risk, daily_loss_percent=args.daily_loss,
                          max_exposure_percent=args.max_exposure)
        report = validate(args.csv, args.symbol, args.development_cutoff, costs,
                          fold_bars=args.fold_bars, threshold=args.threshold,
                          starting_balance=args.starting_balance, risk=risk)
        with args.out.open('x', encoding='utf-8') as file:
            json.dump(report, file, indent=2, allow_nan=False)
    except (ValueError, OSError, ExecutionBlocked) as error:
        parser.exit(2, f'{error}\n')
    print(json.dumps(report['combined'], indent=2))


if __name__ == '__main__':
    main()
