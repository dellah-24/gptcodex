"""Optional MT5 protection management. Never increases SL risk, never widens TP.

The model proposes an action from one *closed-candle* signal, not raw tick noise.
Local or centrally published signals are considered only after an authenticated worker
obtains a fresh decision. Each proposed change is independently verified by MT5.
"""
import json
import math
from dataclasses import dataclass
from datetime import datetime, timezone

from .live import ExecutionBlocked, LOCK, MAGIC, _num, base_symbol, verify_identity, ensure_server, require_current_candle


@dataclass(frozen=True)
class ManagementConfig:
    min_confidence: float = 0.70
    trail_atr: float = 1.5
    reversal_tp_atr: float = 1.0
    max_tick_age: int = 120

    def validate(self):
        if not (.5 <= self.min_confidence <= .99):
            raise ValueError('Bad management confidence')
        if not (.5 <= self.trail_atr <= 5 and .5 <= self.reversal_tp_atr <= 5):
            raise ValueError('Bad ATR multipliers')
        return self


def propose(position, *, direction, confidence, atr, bid, ask, point, digits,
            stops_level, freeze_level=0, config=None):
    """Pure, risk-reducing SL/TP proposal; return None if no safe change exists.

    Direction must come from an approved current closed-candle signal. For the
    same-side prediction, trail the SL only after a protective move is possible.
    For a validated reversal, tighten SL and bring TP closer (never farther).
    """
    cfg = (config or ManagementConfig()).validate()
    values=(confidence,atr,bid,ask,point)
    if any(not math.isfinite(float(v)) for v in values) or atr<=0 or point<=0 or bid<=0 or ask<=bid:
        return None
    if confidence < cfg.min_confidence or direction not in ('buy','sell'):
        return None
    side = 'buy' if int(position.type)==0 else 'sell' if int(position.type)==1 else None
    if side is None: return None
    old_sl,old_tp = float(position.sl),float(position.tp)
    # A position without a previously set protective stop is deliberately excluded.
    if not old_sl or not old_tp or not all(map(math.isfinite,(old_sl,old_tp))): return None
    if side=='buy' and not old_sl < bid < old_tp: return None
    if side=='sell' and not old_tp < ask < old_sl: return None
    # Safety buffer includes an extra point; freeze distance is included.
    min_dist = (max(0,int(stops_level),int(freeze_level))+2)*point
    close_price = bid if side=='buy' else ask
    reversal = direction != side
    if side=='buy':
        proposed_sl = max(old_sl, close_price - (0.8 if reversal else cfg.trail_atr)*atr)
        new_sl = round(proposed_sl,digits)
        new_tp = old_tp
        if reversal:
            new_tp = round(min(old_tp,close_price+cfg.reversal_tp_atr*atr),digits)
        # Don't modify unless more protective; cannot widen TP away from entry.
        if new_sl <= old_sl + point/2: new_sl=old_sl
        if new_tp >= old_tp - point/2: new_tp=old_tp
        if new_sl >= bid-min_dist or new_tp <= ask+min_dist: return None
        if new_sl < old_sl or new_tp > old_tp: return None
    else:
        proposed_sl = min(old_sl,close_price+(0.8 if reversal else cfg.trail_atr)*atr)
        new_sl = round(proposed_sl,digits)
        new_tp = old_tp
        if reversal:
            new_tp = round(max(old_tp,close_price-cfg.reversal_tp_atr*atr),digits)
        if new_sl >= old_sl-point/2: new_sl=old_sl
        if new_tp <= old_tp+point/2: new_tp=old_tp
        if new_sl <= ask+min_dist or new_tp >= bid-min_dist: return None
        if new_sl > old_sl or new_tp < old_tp: return None
    if new_sl==old_sl and new_tp==old_tp: return None
    return {'sl':new_sl,'tp':new_tp,'reason':'confirmed_reversal' if reversal else 'atr_trailing',
            'signal_direction':direction,'confidence':float(confidence)}


def manage_positions(mt5, *, login, server, approved_servers, symbol, direction,
                     confidence, atr, candle_time, journal, config=None, live_enabled=False, expected_mode=None, enforce_candle_freshness=False, candle_seconds=600):
    """Tighten own TempestBot positions. Unknown broker outcomes are never retried.

    Caller MUST enforce its demo/live opt-in. No change is sent in dry-run mode.
    """
    with LOCK:
        config=(config or ManagementConfig()).validate()
        ensure_server(server,approved_servers)
        base_symbol(symbol)
        if not live_enabled: raise ExecutionBlocked('Position management execution not enabled')
        verify_identity(mt5, login, server, expected_mode=expected_mode, require_trading=True)
        positions=mt5.positions_get(symbol=symbol)
        if positions is None: raise ExecutionBlocked('Cannot verify MT5 positions')
        info=mt5.symbol_info(symbol)
        tick=mt5.symbol_info_tick(symbol)
        if info is None or tick is None: raise ExecutionBlocked('No MT5 symbol information')
        now=datetime.now(timezone.utc).timestamp()
        if now-_num(tick.time)>config.max_tick_age or _num(tick.time)>now+5:
            raise ExecutionBlocked('Stale MT5 quote')
        if getattr(info,'trade_mode',None)!=getattr(mt5,'SYMBOL_TRADE_MODE_FULL',4):
            raise ExecutionBlocked('Trading unavailable for symbol')
        receipts=[]
        for p in positions:
            if int(getattr(p,'magic',-1))!=MAGIC or str(p.symbol)!=symbol:
                continue
            ticket=int(p.ticket)
            if ticket<=0: continue
            suggestion=propose(p,direction=direction,confidence=confidence,atr=atr,
                bid=_num(tick.bid),ask=_num(tick.ask),point=_num(info.point),
                digits=int(info.digits),stops_level=int(getattr(info,'trade_stops_level',0)),
                freeze_level=int(getattr(info,'trade_freeze_level',0)),config=config)
            if suggestion is None: continue
            # One attempt per ticket and closed candle. Reserve BEFORE sending.
            key=f'{login}:{ticket}:{int(candle_time)}'
            request={'action':mt5.TRADE_ACTION_SLTP,'position':ticket,'symbol':symbol,
                     'sl':suggestion['sl'],'tp':suggestion['tp'],'magic':MAGIC,
                     'comment':'TempestBot protection'}
            journal.reserve_modification(key, login, ticket, symbol,
                                         {**suggestion, 'server': server.casefold(),
                                          'previous_sl': p.sl, 'previous_tp': p.tp})
            try:
                journal.require_unpaused()
                if enforce_candle_freshness:
                    require_current_candle(candle_time, candle_seconds)
                verify_identity(mt5, login, server, expected_mode=expected_mode, require_trading=True)
            except ExecutionBlocked:
                journal.finish_modification(key, 'BLOCKED', request)
                raise
            try:
                response=mt5.order_send(request)
            except Exception as exc:
                journal.finish_modification(key,'UNKNOWN',{'error':type(exc).__name__})
                raise ExecutionBlocked('SL/TP modification outcome uncertain; reconcile with MT5') from exc
            if response is None:
                journal.finish_modification(key,'UNKNOWN',{'error':'No response'})
                raise ExecutionBlocked('SL/TP modification outcome unknown')
            result={'ticket':ticket,'retcode':int(response.retcode),**suggestion}
            if response.retcode != mt5.TRADE_RETCODE_DONE:
                journal.finish_modification(key,'RECONCILE',result)
                raise ExecutionBlocked('MT5 rejected SL/TP modification; inspect broker position')
            # Verify MT5 reports the desired stop/target. Do not issue a blind retry.
            fresh=mt5.positions_get(ticket=ticket)
            if not fresh or len(fresh)!=1:
                journal.finish_modification(key,'RECONCILE',result)
                raise ExecutionBlocked('Cannot verify modified position in MT5')
            actual=fresh[0]
            tol=float(info.point)*1.01
            if abs(float(actual.sl)-suggestion['sl'])>tol or abs(float(actual.tp)-suggestion['tp'])>tol:
                journal.finish_modification(key,'RECONCILE',result)
                raise ExecutionBlocked('Broker stops differ from submitted values')
            journal.finish_modification(key,'CONFIRMED',result)
            receipts.append(result)
        return receipts
