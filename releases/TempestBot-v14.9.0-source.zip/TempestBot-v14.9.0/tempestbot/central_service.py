"""Trusted single-instance central coordinator. No broker account credentials.

Run every minute with your service supervisor, or loop as a dedicated backend.
The central shared signal is one immutable decision per symbol/closed candle.
"""
import os
import time
from datetime import datetime,timezone,timedelta
from pathlib import Path
from .adaptive import LearningStore
from .shared import SupabaseTransport,CentralHub,consensus_bars
from .central_learning import sync_canonical,calculate_shared_signal


def cycle_once(root, now=None):
    now=time.time() if now is None else now
    hub=CentralHub(SupabaseTransport(os.environ['SUPABASE_URL'],os.environ['SUPABASE_SECRET_KEY']))
    store=LearningStore(root)
    result={}
    try:
        for symbol in ('XAUUSD','BTCUSD'):
            latest=store.db.execute('SELECT COALESCE(MAX(time),0) FROM bars WHERE symbol=?',(symbol,)).fetchone()[0]
            # Recheck last bar for cross-client agreement. Limit/cursor means
            # large backfills must run in explicit batches (see README).
            incoming=hub.contributions(symbol,max(0,latest-600))
            consensus=consensus_bars(incoming)
            hub.publish_canonical(consensus)
            n=sync_canonical(hub,store,symbol,latest)
            bar=store.db.execute('SELECT MAX(time) FROM bars WHERE symbol=?',(symbol,)).fetchone()[0]
            if bar is None:
                result[symbol]={'validated_added':n,'status':'NO_VALIDATED_DATA'};continue
            # Only recent last fully closed M10 bar is publishable; no old signal.
            if not bar+600<=now<bar+1200:
                result[symbol]={'validated_added':n,'status':'STALE_BAR'};continue
            registry=hub.db.request('shared_model_registry',params={
                'select':'symbol,version,artifact_sha256,status','symbol':'eq.'+symbol,
                'status':'eq.APPROVED','limit':'1'})
            decision=calculate_shared_signal(store,symbol,registry)
            if decision is None:
                result[symbol]={'validated_added':n,'status':'INSUFFICIENT_BARS'};continue
            expires=datetime.fromtimestamp(bar+1200,timezone.utc).isoformat()
            try:
                hub.publish_signal(symbol,bar,decision['direction'],decision['confidence'],
                                   decision['model_version'],decision['strategy_version'],expires)
                outcome='PUBLISHED'
            except Exception as exc:
                # Unique constraint means an identical candle may already be
                # published. Other backend errors remain errors, not ignored.
                from .shared import SharedError
                if not isinstance(exc,SharedError):raise
                outcome='PUBLISH_REJECTED_CHECK_BACKEND'
            result[symbol]={'validated_added':n,'status':outcome,'signal':decision}
    finally:store.close()
    return result
