"""Central-only periodic coordinator. Distinct from user MT5 and dashboard processes.

One instance per deployment, under an OS supervisor. It aggregates approved price
observations, publishes common signals and starts isolated low-CPU challenger jobs.
Candidates are NEVER activated without explicit manual approval.
"""
import argparse
import logging
import os
import subprocess
import sys
import time
from pathlib import Path
from .background import ProcessLock,atomic_json,read_json,due,training_env,lower_priority
from .adaptive import LearningStore
from .central_service import cycle_once

LOG=logging.getLogger('tempestbot.central_daemon')


def schedule(root,state,now,workers):
    store=LearningStore(root)
    try:
        for symbol in ('XAUUSD','BTCUSD'):
            existing=workers.get(symbol)
            if existing is not None:
                if existing.poll() is None:continue
                LOG.info('%s training process exited with code %s',symbol,existing.returncode)
                workers.pop(symbol,None)
            count,latest=store.db.execute('SELECT COUNT(*),MAX(time) FROM bars WHERE symbol=?',(symbol,)).fetchone()
            past=state.get(symbol)
            new=(store.db.execute('SELECT COUNT(*) FROM bars WHERE symbol=? AND time>?',
                    (symbol,int(past.get('latest_bar_time',0)))).fetchone()[0] if past else count)
            eligible,_=due(past,latest,count,now,new_bar_count=new)
            if not eligible:continue
            state[symbol]={'attempted_at':now,'latest_bar_time':latest,'status':'started'}
            atomic_json(root/'central_training_state.json',state)
            env=training_env()
            for secret in ('TEMPESTBOT_MT5_PASSWORD','TEMPESTBOT_LIVE_ENABLED','SUPABASE_USER_JWT'):
                env.pop(secret,None)
            logfile=open(root/f'central_train_{symbol}.log','ab',buffering=0)
            try:
                command=[sys.executable,'-m','tempestbot.central_daemon','--train-once',
                         '--symbol',symbol,'--data-dir',str(root)]
                kwargs={'cwd':str(Path(__file__).resolve().parent.parent),'env':env,
                        'stdin':subprocess.DEVNULL,'stdout':logfile,'stderr':subprocess.STDOUT}
                if os.name=='nt':kwargs['creationflags']=subprocess.CREATE_NEW_PROCESS_GROUP
                workers[symbol]=subprocess.Popen(command,**kwargs)
            except OSError as exc:
                state[symbol]['status']='spawn_failed'
                state[symbol]['reason']=type(exc).__name__
                atomic_json(root/'central_training_state.json',state)
                LOG.exception('Challenger subprocess unavailable for %s',symbol)
            finally:logfile.close()
    finally:store.close()


def loop(root,once=False,poll=60):
    root=Path(root).expanduser().resolve()
    root.mkdir(parents=True,exist_ok=True)
    logging.basicConfig(level=logging.INFO,filename=str(root/'central.log'),
                        format='%(asctime)s %(levelname)s %(message)s')
    with ProcessLock(root/'.central.lock'):
        workers={}
        while True:
            now=time.time()
            state=read_json(root/'central_training_state.json')
            try:
                cycle=cycle_once(root,now=now)
                atomic_json(root/'central_cycle_status.json',{'checked_at':now,'symbols':cycle})
                schedule(root,state,now,workers)
            except Exception:
                # Never promote a model or send an order due to scheduler failure.
                LOG.exception('Shared data/inference cycle failed; client workers fail closed')
            if once:return
            time.sleep(poll)


def main():
    p=argparse.ArgumentParser(description='Trusted TempestBot central daemon — NO MT5 execution')
    p.add_argument('--data-dir',type=Path,default=Path.home()/'.tempestbot'/'central-learning')
    p.add_argument('--once',action='store_true')
    p.add_argument('--poll',type=int,default=60)
    p.add_argument('--train-once',action='store_true')
    p.add_argument('--symbol',choices=('XAUUSD','BTCUSD'))
    args=p.parse_args()
    if args.train_once:
        if not args.symbol:p.error('--train-once requires --symbol')
        lower_priority()
        from .central_learning import train_central
        print(train_central(args.symbol,args.data_dir))
    else:
        if not 30<=args.poll<=3600:p.error('poll outside 30-3600 seconds')
        loop(args.data_dir,once=args.once,poll=args.poll)

if __name__=='__main__':main()
