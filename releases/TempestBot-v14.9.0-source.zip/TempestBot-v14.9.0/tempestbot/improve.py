"""Evaluate bounded scalping candidates and explicitly approve verified demo profiles."""
import argparse
from contextlib import closing
from dataclasses import asdict
from datetime import datetime, timezone
from hashlib import file_digest as hash_stream, sha256
from itertools import takewhile
import json
import math
import os
from pathlib import Path
import sqlite3
import time
from uuid import uuid4

from .live import MAGIC
from .shared import SharedError, SupabaseTransport
from .scalp_replay import read_ticks, replay
from .replay_costs import Costs

DEFAULT_DB = Path.home()/'.tempestbot'/'improvement.sqlite3'
MIN_TRADES = 20


def connect(path):
    path.parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(path, timeout=10)
    db.execute('PRAGMA journal_mode=WAL')
    db.executescript("""
      CREATE TABLE IF NOT EXISTS evaluations(
        id TEXT PRIMARY KEY, symbol TEXT NOT NULL, cutoff REAL NOT NULL, end_tick REAL NOT NULL,
        report TEXT NOT NULL, qualified INTEGER NOT NULL, approved_at TEXT
      );
      CREATE TABLE IF NOT EXISTS observed_positions(
        profile TEXT NOT NULL, mode TEXT NOT NULL, account INTEGER NOT NULL, server TEXT NOT NULL,
        position TEXT NOT NULL, closed_at INTEGER NOT NULL, pnl REAL NOT NULL,
        PRIMARY KEY(profile,mode,account,server,position)
      );
      CREATE TABLE IF NOT EXISTS demo_sessions(
        id TEXT PRIMARY KEY, profile TEXT NOT NULL, account INTEGER NOT NULL, server TEXT NOT NULL,
        started_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, ended_at TEXT
      );
    """)
    try:
        path.chmod(0o600)
    except OSError:
        pass
    return db


def demo_session(db, profile, account, server):
    session = uuid4().hex
    with db:
        db.execute('INSERT INTO demo_sessions(id,profile,account,server) VALUES(?,?,?,?)',
                   (session,profile,account,server.casefold()))
    return session


def end_demo_session(db, session):
    with db:
        db.execute('UPDATE demo_sessions SET ended_at=CURRENT_TIMESTAMP WHERE id=?',(session,))


def sync_review(db, transport, profile):
    row = db.execute('SELECT report FROM evaluations WHERE id=?',(profile,)).fetchone()
    if not row:
        raise ValueError('Unknown evaluation profile')
    evidence = []
    accounts = db.execute('''SELECT account,server FROM demo_sessions WHERE profile=?
                             UNION SELECT account,server FROM observed_positions WHERE profile=? AND mode='demo'
                             ORDER BY account,server''',(profile,profile)).fetchall()
    for account,server in accounts:
        count,days,pnl = db.execute('''SELECT count(*),count(DISTINCT date(closed_at,'unixepoch')),coalesce(sum(pnl),0)
               FROM observed_positions WHERE profile=? AND mode='demo' AND account=? AND server=?''',
               (profile,account,server)).fetchone()
        sessions = db.execute('SELECT started_at,ended_at FROM demo_sessions WHERE profile=? AND account=? AND server=? '
                              'ORDER BY started_at DESC LIMIT 10',(profile,account,server)).fetchall()
        evidence.append(dict(mode='demo',account=f'••••{str(account)[-4:]}',server=server,positions=count,days=days,
                             net_pnl=pnl,sessions=[dict(start=a,end=b) for a,b in sessions]))
    transport.rpc('sync_improvement_review',{'candidate_id':profile,'report_text':row[0],'demo_log':evidence})


def file_digest(path):
    with path.open('rb') as stream:
        return hash_stream(stream, 'sha256').hexdigest()


def evaluate(db, path, symbol, costs, *, baseline='breakout', initial_cutoff=None):
    """Select on older ticks, freeze the selection, then score one new holdout."""
    costs.validate()
    original = file_digest(path)
    data_bytes = path.stat().st_size
    first, end = None, None
    for stamp, _, _ in read_ticks(path):
        if first is None:
            first = stamp
        end = stamp
    previous = db.execute('SELECT end_tick,report FROM evaluations WHERE symbol=? ORDER BY end_tick DESC LIMIT 1',
                          (symbol,)).fetchone()
    latest = previous[0] if previous else None
    if previous:
        prior = json.loads(previous[1])
        remaining = prior['data_bytes']
        digest = sha256()
        with path.open('rb') as stream:
            while remaining:
                block = stream.read(min(remaining, 1024*1024))
                if not block:
                    break
                digest.update(block)
                remaining -= len(block)
        if remaining or digest.hexdigest() != prior['data_sha256']:
            raise ValueError('Append new ticks to the existing file without replacing previously evaluated bytes')
    if first is None:
        raise ValueError('No ticks in file')
    if end + 1 > datetime.now(timezone.utc).timestamp():
        raise ValueError('Future ticks are not valid evaluation evidence')
    if latest is None and initial_cutoff is None:
        raise ValueError('First evaluation requires --initial-cutoff for untouched data')
    cutoff = math.nextafter(latest, math.inf) if latest is not None else initial_cutoff
    if cutoff - first < 100 * 3600:
        raise ValueError('Need at least 100 hours of history before the holdout, plus enough tuning trades')
    if end - cutoff < 86400:
        return None
    configurations = [
        {'entry_style':style,'retest_bars':bars,'max_entry_distance_atr':distance}
        for style,bars,distance in [('breakout',3,.5),('distance',3,.5),('distance',3,.75),
                                   ('retest',2,.5),('retest',3,.5),('retest',4,.75)]
    ]
    control = next(config for config in configurations if config['entry_style'] == baseline)
    def run(config, holdout):
        stream = read_ticks(path)
        if not holdout:
            stream = takewhile(lambda tick: tick[0] < cutoff, stream)
        return replay(stream,symbol,costs,evaluate_from=cutoff if holdout else None,**config)['performance']
    tuning = [(config,run(config,False)) for config in configurations if config != control]
    eligible = [item for item in tuning if item[1]['trades'] >= MIN_TRADES]
    selected = max(eligible, key=lambda item:(item[1]['net_pnl'],-item[1]['max_drawdown_pct']), default=None)
    control_result = run(control,True)
    candidate_result = run(selected[0],True) if selected else None
    qualified = bool(candidate_result and candidate_result['trades'] >= MIN_TRADES and
                     candidate_result['net_pnl'] > max(0,control_result['net_pnl']) and
                     candidate_result['max_drawdown_pct'] <= max(.1,control_result['max_drawdown_pct']))
    if original != file_digest(path):
        raise ValueError('Tick file changed during evaluation; retry on a stable snapshot')
    report = dict(symbol=symbol,cutoff=cutoff,end_tick=end,data_sha256=original,data_bytes=data_bytes,costs=asdict(costs),
                  baseline=control,baseline_holdout=control_result,candidate=selected[0] if selected else None,
                  candidate_holdout=candidate_result,tuning=tuning,qualified=qualified)
    payload = json.dumps(report,sort_keys=True,allow_nan=False)
    profile = sha256(payload.encode()).hexdigest()
    with db:
        db.execute('BEGIN IMMEDIATE')
        current, = db.execute('SELECT max(end_tick) FROM evaluations WHERE symbol=?',(symbol,)).fetchone()
        if current != latest:
            raise ValueError('Another evaluation published first; rerun with new ticks')
        db.execute('INSERT INTO evaluations VALUES(?,?,?,?,?,?,NULL)',(profile,symbol,cutoff,end,payload,int(qualified)))
    return {'profile':profile,**report}


def load_profile(db, profile, mode, *, verify_digest=False):
    row = db.execute('SELECT report,qualified,approved_at FROM evaluations WHERE id=?',(profile,)).fetchone()
    if not row or not row[1] or (mode == 'live' and not row[2]):
        raise ValueError('Profile has not passed the required historical and approval checks')
    if verify_digest and sha256(row[0].encode()).hexdigest() != profile:
        raise ValueError('Profile settings do not match their approved ID')
    return json.loads(row[0])


def approve(db, profile, account, server):
    with db:
        db.execute('BEGIN IMMEDIATE')
        load_profile(db,profile,'demo')
        dates, trades, profit = db.execute("""
          SELECT count(DISTINCT date(closed_at,'unixepoch')),count(*),coalesce(sum(pnl),0)
          FROM observed_positions WHERE profile=? AND mode='demo' AND account=? AND server=?
        """,(profile,account,server.casefold())).fetchone()
        if trades < MIN_TRADES or dates < 2 or profit <= 0:
            raise ValueError(f'Demo gate requires {MIN_TRADES} completed positions over at least two UTC days and positive net P&L')
        db.execute('UPDATE evaluations SET approved_at=coalesce(approved_at,CURRENT_TIMESTAMP) WHERE id=?',(profile,))
    return {'profile':profile,'demo_positions':trades,'demo_days':dates,'demo_net_pnl':profit}


def observe(db, journal, broker, profile, mode, login, server, recent_deals):
    """Count only fully closed positions attributable to a profile-tagged entry."""
    candidates = broker.positions_get()
    if candidates is None:
        return
    still_open = {getattr(p,'identifier',p.ticket) for p in candidates}
    closed_ids = {d.position_id for d in recent_deals if d.entry in (1,3) and d.position_id > 0} - still_open
    for position in closed_ids:
        params = profile, mode, login, server.casefold(), str(position)
        if db.execute('SELECT 1 FROM observed_positions WHERE profile=? AND mode=? AND account=? AND server=? AND position=?',
                      params).fetchone():
            continue
        deals = broker.history_deals_get(position=position)
        if not deals or any(d.magic != MAGIC or d.entry not in (0,1,3) for d in deals):
            continue
        entries = [d for d in deals if d.entry == 0]
        exits = [d for d in deals if d.entry in (1,3)]
        if (not entries or not exits or len({d.order for d in entries}) != 1
                or not math.isclose(sum(d.volume for d in entries),sum(d.volume for d in exits),abs_tol=1e-8)):
            continue
        tagged = journal.db.execute("""
          SELECT 1 FROM orders WHERE account=? AND substr(key,1,length(?))=?
          AND json_extract(data,'$.request.improvement_profile')=?
          AND (json_extract(data,'$.result.order')=? OR json_extract(data,'$.broker_evidence.order')=?)
          AND json_extract(data,'$.request.improvement_mode')=? AND status IN ('FILLED','PARTIAL_SETTLED') LIMIT 1
        """,(login,f'{login}:{server.casefold()}:',f'{login}:{server.casefold()}:',profile,
              entries[0].order,entries[0].order,mode)).fetchone()
        if not tagged:
            continue
        pnl = sum(d.profit+d.commission+d.swap+d.fee for d in deals)
        if math.isfinite(pnl):
            with db:
                db.execute('INSERT OR IGNORE INTO observed_positions VALUES(?,?,?,?,?,?,?)',
                           (*params,max(d.time for d in exits),pnl))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--db',type=Path,default=DEFAULT_DB)
    commands = parser.add_subparsers(dest='command',required=True)
    evaluate_cmd = commands.add_parser('evaluate')
    evaluate_cmd.add_argument('ticks',type=Path)
    evaluate_cmd.add_argument('--symbol',choices=('XAUUSD','BTCUSD'),required=True)
    evaluate_cmd.add_argument('--baseline',choices=('breakout','distance','retest'),default='breakout')
    evaluate_cmd.add_argument('--initial-cutoff',type=str)
    evaluate_cmd.add_argument('--interval',type=int,default=0,help='Minimum minutes between evaluations; zero runs once')
    for name in ('point','slippage-points','commission-bps','buy-swap-bps','sell-swap-bps'):
        evaluate_cmd.add_argument('--'+name,type=float,required=True)
    approve_cmd = commands.add_parser('approve')
    approve_cmd.add_argument('profile')
    approve_cmd.add_argument('--demo-login',type=int,required=True)
    approve_cmd.add_argument('--demo-server',required=True)
    commands.add_parser('status')
    commands.add_parser('show').add_argument('profile')
    sync = commands.add_parser('sync-review')
    sync.add_argument('profile',nargs='?',help='Omit to sync all evaluations')
    sync.add_argument('--interval',type=int,default=0,help='Repeat at this interval in minutes')
    args=parser.parse_args()
    try:
        with closing(connect(args.db)) as db:
            if args.command == 'approve':
                print(json.dumps(approve(db,args.profile,args.demo_login,args.demo_server)))
            elif args.command == 'sync-review':
                token = os.environ.get('SUPABASE_USER_JWT','').strip()
                if not token:
                    raise ValueError('An authenticated administrator JWT is required')
                transport = SupabaseTransport(os.environ.get('SUPABASE_URL',''),os.environ.get('SUPABASE_PUBLISHABLE_KEY',''),token)
                if args.interval < 0:
                    parser.error('Interval must be nonnegative')
                while True:
                    try:
                        profiles = ([args.profile] if args.profile else
                                    [row[0] for row in db.execute('SELECT id FROM evaluations ORDER BY end_tick')])
                        for profile in profiles:
                            sync_review(db,transport,profile)
                        print(f'Admin review evidence synchronized for {len(profiles)} profiles',flush=True)
                    except SharedError as exc:
                        if not args.interval:
                            raise
                        print(f'Review sync failed: {exc}',flush=True)
                    if not args.interval:
                        break
                    time.sleep(args.interval*60)
            elif args.command == 'show':
                row = db.execute('SELECT report,approved_at FROM evaluations WHERE id=?',(args.profile,)).fetchone()
                if not row:
                    raise ValueError('Unknown evaluation profile')
                print(json.dumps(dict(profile=args.profile,approved_at=row[1],**json.loads(row[0])),indent=2))
            elif args.command == 'status':
                for profile,symbol,qualified,approved in db.execute(
                    'SELECT id,symbol,qualified,approved_at FROM evaluations ORDER BY end_tick DESC'
                ):
                    outcomes = db.execute('SELECT mode,account,server,count(*),sum(pnl) FROM observed_positions '
                                          'WHERE profile=? GROUP BY mode,account,server',(profile,)).fetchall()
                    print(json.dumps(dict(profile=profile,symbol=symbol,qualified=bool(qualified),approved_at=approved,
                                          outcomes=[dict(mode=m,login=a,server=s,positions=n,net_pnl=p)
                                                    for m,a,s,n,p in outcomes])))
            else:
                from .replay_costs import utc_stamp
                costs = Costs(args.point,args.slippage_points,args.commission_bps,args.buy_swap_bps,args.sell_swap_bps)
                cutoff = utc_stamp(args.initial_cutoff) if args.initial_cutoff else None
                if args.interval < 0:
                    parser.error('Interval must be nonnegative')
                while True:
                    try:
                        report = evaluate(db,args.ticks,args.symbol,costs,baseline=args.baseline,initial_cutoff=cutoff)
                        print(json.dumps(report) if report else 'Waiting for a new holdout of at least 24 hours',flush=True)
                    except (OSError,ValueError) as exc:
                        if not args.interval:
                            raise
                        print(f'Evaluation window skipped: {exc}',flush=True)
                    if not args.interval:
                        break
                    time.sleep(args.interval*60)
    except (ValueError,OSError,sqlite3.Error,SharedError) as exc:
        parser.exit(2,f'{exc}\n')


if __name__ == '__main__':
    main()
