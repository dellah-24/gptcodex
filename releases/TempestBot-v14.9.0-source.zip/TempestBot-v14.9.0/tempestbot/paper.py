"""Auditable PAPER-ONLY execution journal. No broker calls, no fabricated market feeds."""
import json
import math
import sqlite3
import threading
from datetime import datetime, timezone
from pathlib import Path
from .core import canonical_symbol, RiskConfig, risk_gate, performance

class PaperLedger:
    """Serialized SQLite transitions: simulated fills only at user-supplied prices."""
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        with self._connect() as db:
            db.executescript('''
                CREATE TABLE IF NOT EXISTS trades (
                  id INTEGER PRIMARY KEY AUTOINCREMENT, account TEXT NOT NULL,
                  symbol TEXT NOT NULL, side TEXT NOT NULL, qty REAL NOT NULL,
                  entry REAL NOT NULL, sl REAL NOT NULL, tp REAL NOT NULL,
                  opened_at TEXT NOT NULL, closed_at TEXT, exit REAL, pnl REAL,
                  CHECK(qty>0), CHECK(side IN ('buy','sell')));
                CREATE TABLE IF NOT EXISTS events (
                  id INTEGER PRIMARY KEY AUTOINCREMENT, stamp TEXT NOT NULL,
                  kind TEXT NOT NULL, details TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS keys (
                  request_id TEXT PRIMARY KEY, trade_id INTEGER NOT NULL);
            ''')
    def _connect(self):
        db = sqlite3.connect(str(self.path), timeout=10)
        db.row_factory = sqlite3.Row
        return db
    @staticmethod
    def _number(value, name):
        if isinstance(value, bool):
            raise ValueError(f'{name}: number required')
        try: v = float(value)
        except (ValueError, TypeError): raise ValueError(f'{name}: number required') from None
        if not math.isfinite(v) or v <= 0: raise ValueError(f'{name}: positive finite number required')
        return v
    @staticmethod
    def _now():
        return datetime.now(timezone.utc).isoformat()
    def log(self, db, kind, data):
        db.execute('INSERT INTO events(stamp,kind,details) VALUES(?,?,?)', (self._now(),kind,json.dumps(data, sort_keys=True)))
    def open(self, *, request_id, account, symbol, side, qty, entry, sl, tp, risk, starting_equity=10000):
        canonical_symbol(symbol)
        if symbol.upper() not in ('XAUUSD','BTCUSD'):
            raise ValueError('Paper ledger accepts exact canonical symbols only')
        if side not in ('buy','sell'): raise ValueError('Invalid side')
        if not isinstance(request_id,str) or not 8 <= len(request_id) <= 100 or not request_id.isascii():
            raise ValueError('Unique request ID required')
        if not isinstance(account,str) or not account.isdigit(): raise ValueError('Configured account required')
        qty,entry,sl,tp = (self._number(x,n) for x,n in [(qty,'qty'),(entry,'entry'),(sl,'sl'),(tp,'tp')])
        if not ((sl<entry<tp) if side=='buy' else (tp<entry<sl)):
            raise ValueError('SL/TP must bracket entry')
        cfg = RiskConfig(**risk).validate()
        start = self._number(starting_equity,'starting_equity')
        # Paper notional convention: 1 quantity = 1 price-unit exposure. NOT broker lot sizing.
        risk_cash = abs(entry-sl)*qty
        if risk_cash > start*cfg.risk_percent/100 + 1e-8:
            raise ValueError('Paper position exceeds risk per trade')
        with self.lock, self._connect() as db:
            db.execute('BEGIN IMMEDIATE')
            existing=db.execute('SELECT trade_id FROM keys WHERE request_id=?',(request_id,)).fetchone()
            if existing: return {'id':existing['trade_id'],'duplicate':True}
            positions=db.execute('SELECT COUNT(*) n FROM trades WHERE closed_at IS NULL AND account=?',(account,)).fetchone()['n']
            today=datetime.now(timezone.utc).date().isoformat()
            realized=db.execute('SELECT COALESCE(SUM(pnl),0) p FROM trades WHERE account=? AND substr(closed_at,1,10)=?',(account,today)).fetchone()['p']
            equity=start+realized
            ok, reason=risk_gate(config=cfg,day_start_equity=start,current_equity=equity,positions=positions,
                spread=0, stop_distance=abs(entry-sl),reward_distance=abs(tp-entry),subscribed=True,enabled=True)
            if not ok: raise ValueError(reason)
            cursor=db.execute('INSERT INTO trades(account,symbol,side,qty,entry,sl,tp,opened_at) VALUES(?,?,?,?,?,?,?,?)',
                (account,symbol,side,qty,entry,sl,tp,self._now()))
            trade_id=cursor.lastrowid
            db.execute('INSERT INTO keys(request_id,trade_id) VALUES(?,?)',(request_id,trade_id))
            self.log(db,'PAPER_OPEN',{'id':trade_id,'account':account,'symbol':symbol,'side':side,'qty':qty,'entry':entry,'sl':sl,'tp':tp})
            return {'id':trade_id,'duplicate':False}
    def close(self, trade_id, exit_price):
        exit_price=self._number(exit_price,'exit_price')
        with self.lock, self._connect() as db:
            db.execute('BEGIN IMMEDIATE')
            trade=db.execute('SELECT * FROM trades WHERE id=?',(int(trade_id),)).fetchone()
            if trade is None: raise ValueError('Trade not found')
            if trade['closed_at']: raise ValueError('Trade already closed')
            pnl=round((exit_price-trade['entry'])*(1 if trade['side']=='buy' else -1)*trade['qty'],2)
            db.execute('UPDATE trades SET closed_at=?,exit=?,pnl=? WHERE id=?',(self._now(),exit_price,pnl,trade_id))
            self.log(db,'PAPER_CLOSE',{'id':trade_id,'exit':exit_price,'pnl':pnl})
            return {'id':trade_id,'net_pnl':pnl}
    def snapshot(self):
        with self.lock, self._connect() as db:
            rows=[dict(r) for r in db.execute('SELECT * FROM trades ORDER BY id DESC LIMIT 200')]
            events=[dict(r) for r in db.execute('SELECT * FROM events ORDER BY id DESC LIMIT 50')]
        closed=[r for r in reversed(rows) if r['closed_at'] is not None]
        return {'trades':rows,'events':events,'metrics':performance([{'net_pnl':r['pnl']} for r in closed]),
                'note':'PAPER ONLY: prices are manually supplied, one quantity = one price-unit exposure; no actual broker lot, spread, fees or slippage.'}
