"""TempestBot local dashboard server. Bind exclusively to loopback."""
import json
import os
import secrets
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit
from .core import REFERRAL_URL, ALLOWED_SYMBOLS, RiskConfig, performance
from .storage import Store
from .mt5_adapter import launch_terminal
from .paper import PaperLedger
from .live import ExecutionJournal
from .background import start_detached, read_json

ROOT = Path(__file__).resolve().parent.parent
STORE = Store(Path.home() / '.tempestbot' / 'settings.json')
LEDGER = PaperLedger(Path.home() / '.tempestbot' / 'paper.sqlite3')
TOKEN = secrets.token_urlsafe(24)

class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass

    def respond(self, value, code=200):
        payload = json.dumps(value).encode()
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Content-Length', str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def _check_host(self):
        host = self.headers.get('Host','')
        return host == f'127.0.0.1:{self.server.server_port}'

    def do_GET(self):
        if not self._check_host():
            return self.respond({'error':'Invalid host'},403)
        if urlsplit(self.path).path in ('/', '/index.html'):
            data = (ROOT / 'web' / 'index.html').read_bytes()
            self.send_response(200)
            self.send_header('Content-Type','text/html; charset=utf-8')
            self.send_header('Content-Security-Policy',"default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; img-src 'self' data:; base-uri 'none'; frame-ancestors 'none'")
            self.send_header('Content-Length',str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        elif urlsplit(self.path).path == '/app.js':
            data = (ROOT / 'web' / 'app.js').read_bytes()
            self.send_response(200)
            self.send_header('Content-Type','application/javascript; charset=utf-8')
            self.send_header('Content-Length',str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        elif urlsplit(self.path).path == '/api/execution-history':
            path=Path.home() / '.tempestbot' / 'execution.sqlite3'
            if path.exists():
                journal=ExecutionJournal(path)
                try: self.respond({'records':journal.history()})
                finally: journal.db.close()
            else: self.respond({'records':[]})
        elif urlsplit(self.path).path == '/api/learning-status':
            self.respond(read_json(Path.home() / '.tempestbot' / 'learning' / 'background_status.json', {'service':'starting', 'deployment':'manual_only'}))
        elif urlsplit(self.path).path == '/api/paper':
            self.respond(LEDGER.snapshot())
        elif urlsplit(self.path).path == '/api/state':
            with STORE.lock:
                public = dict(STORE.data)
                public['token'] = TOKEN
                public['symbols'] = sorted(ALLOWED_SYMBOLS)
                public['referral'] = REFERRAL_URL
                public['mode'] = 'CONFIGURATION / DEMO — NO LIVE EXECUTION'
                public['metrics'] = performance([])
            self.respond(public)
        else:
            self.respond({'error':'Not found'},404)

    def do_POST(self):
        if not self._check_host():
            return self.respond({'error':'Invalid host'},403)
        if self.headers.get('X-Tempest-Token') != TOKEN:
            return self.respond({'error':'Invalid local session token'},403)
        if self.headers.get('Origin') not in (None, f'http://127.0.0.1:{self.server.server_port}'):
            return self.respond({'error':'Invalid origin'},403)
        try:
            if int(self.headers.get('Content-Length','0')) > 10000:
                return self.respond({'error':'Request too large'},413)
            length = int(self.headers.get('Content-Length','0'))
            if length <= 0 or length > 10000:
                raise ValueError('Invalid request size')
            data = json.loads(self.rfile.read(length))
            if not isinstance(data,dict):
                raise ValueError('Expected JSON object')
            path = urlsplit(self.path).path
            if path == '/api/paper/open':
                if not any(a['login']==str(data.get('account')) for a in STORE.data['accounts']):
                    raise ValueError('Choose a configured account')
                result=LEDGER.open(request_id=data['request_id'],account=str(data['account']),
                    symbol=data['symbol'],side=data['side'],qty=data['qty'],entry=data['entry'],
                    sl=data['sl'],tp=data['tp'],risk=STORE.data['risk'])
                return self.respond({'ok':True,**result})
            elif path == '/api/paper/close':
                return self.respond({'ok':True,**LEDGER.close(data['trade_id'],data['exit_price'])})
            elif path == '/api/servers/add':
                STORE.add_server(data['server'])
            elif path == '/api/servers/remove':
                STORE.remove_server(data['server'])
            elif path == '/api/accounts/add':
                STORE.add_account(data['login'],data['server'])
            elif path == '/api/accounts/remove':
                with STORE.lock:
                    STORE.data['accounts'] = [a for a in STORE.data['accounts'] if a['login'] != str(data['login'])]
                    STORE.save()
            elif path == '/api/risk':
                STORE.set_risk(data)
            elif path == '/api/mt5/launch':
                pid = launch_terminal(data.get('path') or None)
                return self.respond({'ok':True,'pid':pid,'message':'MT5 launch requested (not authenticated)'})
            else:
                return self.respond({'error':'Not found'},404)
            self.respond({'ok':True})
        except (KeyError,TypeError,ValueError,RuntimeError,OSError) as exc:
            self.respond({'error':str(exc)},400)


def run():
    if os.environ.get('TEMPESTBOT_SHARED_MODE') == '1':
        print('TempestBot shared mode: local retraining disabled; central Supabase learner is authoritative',flush=True)
    else:
        try:
            pid = start_detached(Path.home() / '.tempestbot' / 'learning')
            print(f'TempestBot background learner launch requested (PID {pid})',flush=True)
        except OSError as exc:
            print(f'Background learning failed to start: {exc}',flush=True)
    server = ThreadingHTTPServer(('127.0.0.1',0),Handler)
    url = f'http://127.0.0.1:{server.server_port}/'
    print(f'TempestBot local dashboard: {url}',flush=True)
    threading.Timer(0.5, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        server.server_close()

if __name__ == '__main__':
    run()
