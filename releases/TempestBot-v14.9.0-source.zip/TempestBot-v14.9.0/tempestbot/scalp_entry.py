"""Scalping entry qualification, independent of directional exit analysis."""
from dataclasses import dataclass
from math import isfinite

from .scalping import scalp_bracket

ENTRY_STYLES = ('breakout', 'distance', 'retest')


@dataclass(frozen=True)
class EntryRules:
    style: str = 'breakout'
    retest_bars: int = 3
    max_distance_atr: float = .5
    retest_tolerance_atr: float = .15
    commission_bps: float = 0
    slippage_points: float = 0
    minimum_net_rr: float = 1.5

    def validate(self):
        fields = (self.max_distance_atr, self.retest_tolerance_atr, self.commission_bps,
                  self.slippage_points, self.minimum_net_rr)
        if (self.style not in ENTRY_STYLES or not 1 <= self.retest_bars <= 10
                or not all(isfinite(value) and value >= 0 for value in fields)
                or self.minimum_net_rr < 1 or self.max_distance_atr <= 0):
            raise ValueError('Invalid scalping entry rules')
        return self


@dataclass(frozen=True)
class Setup:
    side: str
    level: float
    atr: float
    candle: int


def entry_decision(signal, pending, rules):
    """Advance a setup once per closed M1 candle."""
    side, candle = signal['side'], signal['candle_time']
    fresh = Setup(side, signal['breakout_level'], signal['atr'], candle) if side else None
    if rules.style != 'retest':
        return None, fresh, 'Breakout qualified' if fresh else None
    if pending:
        age = (candle - pending.candle) // 60
        if age <= 0:
            return pending, None, 'Waiting for a later M1 retest'
        if age > rules.retest_bars:
            return None, None, 'Retest expired'
        if any(value != pending.side for value in signal['context'].values()):
            return None, None, 'Retest cancelled: higher-timeframe direction changed'
        sign = 1 if pending.side == 'buy' else -1
        tolerance = rules.retest_tolerance_atr * pending.atr
        close = signal['close']
        extreme = signal['low'] if sign == 1 else signal['high']
        if (close - pending.level) * sign < -tolerance:
            return None, None, 'Retest cancelled: breakout level failed'
        if abs(extreme - pending.level) <= tolerance and (close - pending.level) * sign > 0:
            return None, pending, 'Retest confirmed'
        return pending, None, 'Waiting for M1 retest'
    return fresh, None, 'Waiting for M1 retest' if fresh else None


def quote_guard(setup, rules, quote, stop, target, point):
    """Return a rejection reason and net reward/risk for the executable quote."""
    sign = 1 if setup.side == 'buy' else -1
    if rules.style != 'breakout':
        distance = (quote - setup.level) * sign
        if not 0 <= distance <= setup.atr * rules.max_distance_atr:
            return 'Executable price is outside the breakout distance limit', None
    if not isfinite(point) or point <= 0:
        return 'Broker point size unavailable', None
    slippage = 2 * rules.slippage_points * point
    commission = rules.commission_bps / 10000
    loss = sign * (quote - stop)
    reward = sign * (target - quote)
    if min(loss, reward) <= 0:
        return 'Stop or target is on the wrong side of the entry', None
    net_risk = loss + slippage + (quote + stop) * commission
    net_reward = reward - slippage - (quote + target) * commission
    ratio = net_reward / net_risk
    return ('Reward-to-risk after estimated execution costs is too low'
            if ratio < rules.minimum_net_rr else None), ratio


def entry_bracket(setup, rules, quote):
    anchor = quote if rules.style == 'breakout' else setup.level
    return scalp_bracket(setup.side, anchor, setup.atr)
