"""Trusted central worker: sync validated canonical bars and train candidate only.

This module does not have MT5 credentials, is not distributed to a client with
secret configuration and never auto-promotes a model or sends broker orders.
"""
import os
from pathlib import Path
from .shared import CentralHub, SupabaseTransport, normalize_symbol
from .adaptive import LearningStore, train_candidate


def sync_canonical(hub, store, symbol, since=0, page_size=1000):
    symbol=normalize_symbol(symbol)
    count=0
    cursor=int(since)
    while True:
        rows=hub.db.request('canonical_bars',params={
            'select':'symbol,bar_time,open,high,low,close,tick_volume',
            'symbol':'eq.'+symbol,'bar_time':'gt.'+str(cursor),
            'order':'bar_time.asc','limit':str(page_size)})
        if not rows:break
        parsed=[{'time':r['bar_time'],**{k:r[k] for k in ('open','high','low','close','tick_volume')}} for r in rows]
        store.ingest(symbol,parsed)
        count+=len(parsed)
        cursor=int(rows[-1]['bar_time'])
        if len(rows)<page_size:break
    return count


def train_central(symbol,root):
    symbol=normalize_symbol(symbol)
    db=SupabaseTransport(os.environ['SUPABASE_URL'],os.environ['SUPABASE_SECRET_KEY'])
    hub=CentralHub(db)
    store=LearningStore(root)
    try:
        latest=store.db.execute('SELECT COALESCE(MAX(time),0) FROM bars WHERE symbol=?',(symbol,)).fetchone()[0]
        downloaded=sync_canonical(hub,store,symbol,latest)
        # Train candidate even if no new data only for explicit CLI invocation.
        result=train_candidate(store,symbol)
        # Publish metadata only; no untrusted pickle distributed to clients.
        hub.db.request('shared_model_registry',method='POST',body={
            'symbol':symbol,'version':result['version'],'artifact_sha256':result['sha256'],
            'metrics':{k:v for k,v in result.items() if k not in ('symbol','version','sha256')},
            'status':'CANDIDATE'},prefer='return=minimal')
        return {'new_validated_bars':downloaded,**result}
    finally:store.close()


def promote_central(symbol,version,root,ack):
    """Manual-only promotion; both local registry and Supabase must agree."""
    from .adaptive import digest_file
    symbol=normalize_symbol(symbol)
    if ack != f'APPROVE-{symbol}-{version}':raise ValueError('Exact manual acknowledgement required')
    store=LearningStore(root)
    try:
        candidate=store.db.execute('SELECT sha256,status,metrics FROM models WHERE symbol=? AND version=?',
                                   (symbol,version)).fetchone()
        if not candidate or candidate[1]!='CANDIDATE':raise ValueError('Candidate not found')
        import json
        if not json.loads(candidate[2]).get('passed'):raise ValueError('Candidate failed evaluation')
        file=store.root/'models'/symbol/(version+'.joblib')
        if not file.exists() or digest_file(file)!=candidate[0]:raise ValueError('Model artifact SHA mismatch')
        db=SupabaseTransport(os.environ['SUPABASE_URL'],os.environ['SUPABASE_SECRET_KEY'])
        db.rpc('approve_shared_model',{'p_symbol':symbol,'p_version':version,'p_sha256':candidate[0]})
        # If interrupted after server approval, the central publisher fails closed
        # until the local operator repairs the local registry.
        store.approve(symbol,version,ack)
        return {'symbol':symbol,'approved':version,'sha256':candidate[0]}
    finally:store.close()


def calculate_shared_signal(store,symbol,central_models):
    """Predict only from last CLOSED canonical bar, approved central model and SMC.

    Failure or no active model -> FLAT; never generates client order instructions.
    """
    import joblib
    import numpy as np
    from .adaptive import digest_file,features_at,FEATURE_NAMES
    from .core import smc_ict_confirm
    symbol=normalize_symbol(symbol)
    bars=store.market(symbol)
    if len(bars)<40:return None
    last=bars[-1]
    record=store.approved(symbol)
    if record is None:return {'symbol':symbol,'candle_time':last['time'],'direction':'flat',
                              'confidence':0.,'model_version':'none','strategy_version':'smc-ict-v1'}
    version,sha,metrics=record
    matching=[m for m in central_models if m.get('symbol')==symbol and
              m.get('version')==version and m.get('artifact_sha256')==sha and m.get('status')=='APPROVED']
    if not matching:return {'symbol':symbol,'candle_time':last['time'],'direction':'flat',
                            'confidence':0.,'model_version':'unverified','strategy_version':'smc-ict-v1'}
    path=store.root/'models'/symbol/(version+'.joblib')
    if not path.exists() or digest_file(path)!=sha:
        return {'symbol':symbol,'candle_time':last['time'],'direction':'flat',
                'confidence':0.,'model_version':'hash-mismatch','strategy_version':'smc-ict-v1'}
    # Artifact must be generated locally by trusted central trainer; joblib/pickle
    # must NEVER be loaded from community uploads.
    bundle=joblib.load(path)
    if bundle.get('symbol')!=symbol or bundle.get('version')!=version or tuple(bundle.get('features',()))!=FEATURE_NAMES:
        raise ValueError('Unrecognized approved model bundle')
    model=bundle['model']
    values=model.predict_proba(np.asarray([features_at(bars,len(bars)-1)]))[0]
    classes=list(map(int,model.classes_))
    probs=dict(zip(classes,map(float,values)))
    klass=max(probs,key=probs.get)
    confidence=probs[klass]
    direction='buy' if klass==1 else 'sell' if klass==-1 else 'flat'
    if confidence<0.62 or direction=='flat' or not smc_ict_confirm(bars[-40:],direction)['confirmed']:
        direction='flat'
    return {'symbol':symbol,'candle_time':last['time'],'direction':direction,
            'confidence':confidence,'model_version':version,'strategy_version':'smc-ict-v1'}
