"""Replay the live M1 scalping rules using chronological bid/ask ticks."""
import argparse
import csv
from pathlib import Path
import json
import math
from collections import defaultdict, deque

from .core import RiskConfig, performance, risk_gate
from .fast_market import entry_filter, parse_session
from .live import ExecutionBlocked
from .reversal import reversal_streak
from .scalping import TIMEFRAMES, WARMUP, scalp_signal
from .scalp_entry import ENTRY_STYLES, EntryRules, entry_bracket, entry_decision, quote_guard
from .replay_costs import Costs, utc_stamp


class History:
    def __init__(self):
        self.closed = {name: deque(maxlen=WARMUP+1) for name, _ in TIMEFRAMES}
        self.active = {}

    def add(self, stamp, bid):
        for name, seconds in TIMEFRAMES:
            start = int(stamp // seconds) * seconds
            bar = self.active.get(name)
            if bar is None or start != bar['time']:
                if bar is not None:
                    self.closed[name].append(bar)
                self.active[name] = dict(time=start, open=bid, high=bid, low=bid, close=bid)
            else:
                bar['high'] = max(bar['high'], bid)
                bar['low'] = min(bar['low'], bid)
                bar['close'] = bid

    def copy_rates_from_pos(self, symbol, timeframe, offset, count):
        return list(self.closed[timeframe])[-count:]


for _frame, _ in TIMEFRAMES:
    setattr(History, 'TIMEFRAME_'+_frame, _frame)


def read_ticks(path):
    previous = None
    with path.open(newline='', encoding='utf-8-sig') as file:
        reader = csv.DictReader(file)
        if not {'time','bid','ask'}.issubset(reader.fieldnames or []):
            raise ValueError('Tick CSV requires time,bid,ask')
        for row in reader:
            stamp = utc_stamp(row['time'])
            bid, ask = float(row['bid']), float(row['ask'])
            if not (stamp > 0 and math.isfinite(stamp) and 0 < bid < ask < math.inf):
                raise ValueError('Invalid tick timestamp or bid/ask')
            if previous is not None and stamp < previous:
                raise ValueError('Tick timestamps must be chronological')
            previous = stamp
            yield stamp, bid, ask


def replay(ticks, symbol, costs, *, sessions=(), spread_cap=None, cooldown=0,
           exit_reversals=False, reverse_entry=False, reversal_bars=2, starting_balance=10000, entry_style='breakout',
           retest_bars=3, max_entry_distance_atr=.5, evaluate_from=None):
    costs.validate()
    risk = RiskConfig()
    rules = EntryRules(entry_style, retest_bars, max_entry_distance_atr,
                       commission_bps=costs.commission_bps, slippage_points=costs.slippage_points).validate()
    pending = None
    bars = History()
    trades, skipped = [], defaultdict(int)
    cash = baseline = starting_balance
    day = minute = position = streak = last_exit = None
    halted = False
    slippage = costs.slippage_points * costs.point

    def settle(stamp, raw_price, reason):
        nonlocal cash, position, last_exit
        side, entry_time, entry, units, _, _, spread = position
        price = raw_price - side * slippage
        commission = (price+entry)*units*costs.commission_bps/10000
        swap = entry*units*(costs.buy_swap_bps if side == 1 else costs.sell_swap_bps)/10000
        swap *= int(stamp//86400)-int(entry_time//86400)
        pnl = (price-entry)*side*units-commission-swap
        trades.append(dict(entry_time=entry_time,exit_time=stamp,side='buy' if side==1 else 'sell',net_pnl=pnl,
                           spread_points=spread,slippage_points=costs.slippage_points,holding_seconds=stamp-entry_time,
                           utc_session=('00–08 UTC','08–16 UTC','16–24 UTC')[int(entry_time//28800)%3],
                           exit_reason=reason))
        cash += pnl
        position = None
        last_exit = stamp

    tick = None
    for tick in ticks:
        stamp,bid,ask = tick
        mark = cash
        if position:
            side, _, entry, units, stop, target, _ = position
            quote = bid if side == 1 else ask
            mark += (quote-entry)*side*units
        if int(stamp//86400) != day:
            day, baseline, halted = int(stamp//86400), mark, False
        halted |= mark <= baseline*(1-risk.daily_loss_percent/100)
        if position:
            if (quote-stop)*side <= 0:
                settle(stamp,quote,'stop')
            elif (quote-target)*side >= 0:
                settle(stamp,target,'target')
        bars.add(stamp,bid)
        if int(stamp//60) == minute:
            continue
        minute = int(stamp//60)
        if evaluate_from is not None and stamp < evaluate_from:
            continue
        try:
            decision = scalp_signal(bars,symbol,now=stamp)
        except ExecutionBlocked:
            pending = None
            skipped['Timeframe unavailable'] += 1
            continue
        direction = decision['side']
        streak = reversal_streak(streak,candle=decision['candle_time'],side=direction,
                                 confidence=decision['decision_confidence'],threshold=.7,candle_seconds=60)
        pending, setup, setup_reason = entry_decision(decision, pending, rules)
        if position:
            if (not exit_reversals or not direction or streak[2] < reversal_bars
                    or (position[0] == 1) == (direction == 'buy')):
                continue
            settle(stamp, bid if position[0]==1 else ask, 'reversal')
            if not reverse_entry:
                continue
        if setup is None:
            if setup_reason:
                skipped[setup_reason] += 1
            continue
        side = 1 if setup.side == 'buy' else -1
        reason = entry_filter(stamp,sessions=sessions,spread=ask-bid,point=costs.point,
                              spread_cap=spread_cap,last_exit=last_exit,cooldown=cooldown)
        if reason or halted:
            skipped['Daily loss halt' if halted else reason.split(' —')[0]] += 1
            continue
        quote = ask if side==1 else bid
        stop,target = entry_bracket(setup,rules,quote)
        reason, _ = quote_guard(setup,rules,quote,stop,target,costs.point)
        if reason:
            skipped[reason] += 1
            continue
        allowed, reason = risk_gate(config=risk,day_start_equity=baseline,current_equity=cash,positions=0,spread=ask-bid,
                                    stop_distance=abs(quote-stop),reward_distance=abs(quote-target),subscribed=True,enabled=True)
        if not allowed:
            skipped[reason] += 1
            continue
        entry = quote+side*slippage
        units = cash*risk.risk_percent/100/abs(entry-stop)
        position = side,stamp,entry,units,stop,target,(ask-bid)/costs.point
    if tick is None:
        raise ValueError('No ticks in file')
    if position:
        settle(tick[0],tick[1] if position[0]==1 else tick[2],'end_of_data')
    def summarize(group_key):
        buckets = defaultdict(list)
        for trade in trades:
            buckets[group_key(trade)].append(trade)
        return {name: performance(bucket, starting_balance) for name, bucket in sorted(buckets.items())}

    return {'symbol':symbol,'entry_style':entry_style,'performance':performance(trades,starting_balance),
            'utc_sessions':summarize(lambda trade: trade['utc_session']),
            'spread_bands_points':summarize(lambda trade: '<10' if trade['spread_points'] < 10 else
                                            '10–<25' if trade['spread_points'] < 25 else '25+'),
            'holding_bands':summarize(lambda trade: '<1 min' if trade['holding_seconds'] < 60 else
                                      '1–<5 min' if trade['holding_seconds'] < 300 else '5+ min'),
            'slippage_points_per_fill':costs.slippage_points,
            'skipped':dict(skipped),'trades':trades,
            'assumptions':'USD quote/account, one symbol at a time, fractional sizing, configured costs, no broker latency or margin simulation.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('ticks',type=Path)
    parser.add_argument('--out',type=Path,required=True)
    parser.add_argument('--symbol',choices=('XAUUSD','BTCUSD'),required=True)
    for name in ('point','slippage-points','commission-bps','buy-swap-bps','sell-swap-bps'):
        parser.add_argument('--'+name,type=float,required=True)
    parser.add_argument('--entry-style', choices=(*ENTRY_STYLES, 'compare'), default='breakout')
    parser.add_argument('--retest-bars', type=int, default=3)
    parser.add_argument('--max-entry-distance-atr', type=float, default=.5)
    parser.add_argument('--entry-session',action='append',type=parse_session,default=[])
    parser.add_argument('--max-spread-points',type=float)
    parser.add_argument('--exit-cooldown',type=int,default=0)
    parser.add_argument('--exit-on-reversal',action='store_true')
    parser.add_argument('--reverse-on-signal',action='store_true')
    parser.add_argument('--reversal-bars',type=int,choices=range(1,5),default=2)
    args = parser.parse_args()
    if args.reverse_on_signal and not args.exit_on_reversal:
        parser.error('--reverse-on-signal requires --exit-on-reversal')
    if not 0 <= args.exit_cooldown <= 86400 or (args.max_spread_points is not None and not 0 < args.max_spread_points < math.inf):
        parser.error('Invalid cooldown or broker-point spread limit')
    costs = Costs(args.point,args.slippage_points,args.commission_bps,args.buy_swap_bps,args.sell_swap_bps)
    try:
        def run(style):
            return replay(read_ticks(args.ticks),args.symbol,costs,sessions=args.entry_session,
                          spread_cap=args.max_spread_points,cooldown=args.exit_cooldown,exit_reversals=args.exit_on_reversal,
                          reverse_entry=args.reverse_on_signal,reversal_bars=args.reversal_bars,
                          entry_style=style,retest_bars=args.retest_bars,max_entry_distance_atr=args.max_entry_distance_atr)
        result = ({style:run(style) for style in ENTRY_STYLES} if args.entry_style == 'compare'
                  else run(args.entry_style))
        with args.out.open('x',encoding='utf-8') as file:
            json.dump(result,file,indent=2,allow_nan=False)
        print(json.dumps({style:value['performance'] for style,value in result.items()} if args.entry_style == 'compare'
                         else result['performance'],indent=2))
    except (ValueError,OSError) as error:
        parser.exit(2,f'{error}\n')


if __name__=='__main__':
    main()
