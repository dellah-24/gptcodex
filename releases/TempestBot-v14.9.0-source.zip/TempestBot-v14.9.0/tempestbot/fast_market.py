"""Optional entry-only filters, also used by the historical replay."""
from datetime import datetime, timezone, timedelta
from math import isfinite

from .live import ExecutionBlocked, MAGIC


def parse_session(value):
    start, separator, end = value.partition('-')
    if not separator:
        raise ValueError('Session must have format HH:MM-HH:MM UTC')
    def minute(text):
        if len(text) != 5 or text[2] != ':' or not (text[:2]+text[3:]).isdigit():
            raise ValueError('Session must have format HH:MM-HH:MM UTC')
        hour, minute = int(text[:2]), int(text[3:])
        if hour > 23 or minute > 59:
            raise ValueError('Invalid UTC session clock time')
        return hour * 60 + minute
    interval = minute(start), minute(end)
    if interval[0] == interval[1]:
        raise ValueError('Session start and end must differ')
    return interval


def entry_filter(stamp, *, sessions, spread, point, spread_cap, last_exit, cooldown):
    minute = int(stamp // 60) % 1440
    if sessions and not any(a <= minute < b if a < b else minute >= a or minute < b for a,b in sessions):
        return 'Outside configured UTC entry sessions'
    if spread_cap is not None and (not isfinite(point) or point <= 0 or spread / point > spread_cap + 1e-8):
        return 'Spread exceeds broker-point limit'
    if last_exit is not None and stamp - last_exit < cooldown:
        return f'Exit cooldown — {max(1, int(cooldown - (stamp-last_exit) + .999))}s remaining'
    return None


def latest_exit(mt5, symbol, stamp, cooldown):
    if not cooldown:
        return None
    now = datetime.fromtimestamp(stamp, timezone.utc)
    deals = mt5.history_deals_get(now - timedelta(seconds=cooldown + 1), now)
    if deals is None:
        raise ExecutionBlocked('Exit cooldown history unavailable')
    return max((d.time for d in deals if d.magic == MAGIC and d.symbol.casefold() == symbol.casefold()
                and d.entry in (getattr(mt5, 'DEAL_ENTRY_OUT', 1), getattr(mt5, 'DEAL_ENTRY_OUT_BY', 3))),
               default=None)
