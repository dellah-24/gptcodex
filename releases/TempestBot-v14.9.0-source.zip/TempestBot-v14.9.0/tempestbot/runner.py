"""Opt-in MT5 scanner/worker using the uploaded legacy project's trained models."""
import argparse
import getpass
import json
import logging
import os
import platform
import re
import time
from pathlib import Path
from functools import lru_cache
from contextlib import ExitStack, closing
from datetime import datetime, timedelta, timezone

from .core import RiskConfig, smc_ict_confirm
from .live import ExecutionBlocked, ExecutionJournal, execute_order, select_symbol, verify_identity, base_symbol, account_lease, stop_exposure, _num, MAGIC
from .adaptive import LearningStore, confirmation
from .management import manage_positions, ManagementConfig
from .reconciliation import audit_account
from .improve import DEFAULT_DB, connect as connect_improvement, load_profile, observe, demo_session, end_demo_session
from .telemetry import Telemetry
from .fast_market import entry_filter, latest_exit, parse_session
from .scalping import scalp_signal
from .scalp_entry import ENTRY_STYLES, EntryRules, entry_bracket, entry_decision, quote_guard
from .reversal import close_on_reversal, exit_key, reversal_streak
from .shared import UserHub, SupabaseTransport, SharedError

ROOT=Path(__file__).resolve().parent.parent
LOGGER=logging.getLogger('tempestbot.worker')


@lru_cache(maxsize=2)
def _model(base):
    import joblib

    file = ROOT / 'legacy' / 'ALL_MODELS' / f'HL_MAIN_THL_3H_10M_{base}_model.pkl'
    if not file.is_file():
        raise ExecutionBlocked(f'Missing model for {base}')
    # Only release-bundled, trusted artifacts may be loaded.
    return joblib.load(file)


def candle_frame(rates):
    import pandas as pd

    df=pd.DataFrame(rates)
    df['Date']=pd.to_datetime(df['time'],unit='s',utc=True)
    df=df.rename(columns={'open':'Open','high':'High','low':'Low','close':'Close',
                         'tick_volume':'Volume','spread':'Spread'})
    return df[['Date','Open','High','Low','Close','Volume','Spread']].sort_values('Date').reset_index(drop=True)


def model_features(frame, symbol, target=None):
    from legacy.PY_FILES.func import apply_features, set_logger

    set_logger(LOGGER)
    bundle = _model(base_symbol(symbol))
    features = apply_features(frame, drop_sparse=False)
    columns = bundle['features']
    if any(column not in features for column in columns) or 'ATR' not in features:
        raise ExecutionBlocked('Model feature mismatch')
    if target is None:
        target = frame.iloc[-1]['Date']
    if target not in features.index:
        raise ExecutionBlocked('Model features do not match the latest completed candle')
    row = features.loc[[target], [*dict.fromkeys([*columns, 'ATR'])]]
    row = row.replace([float('inf'), float('-inf')], float('nan'))
    if row.isna().any().any() or row.iloc[0]['ATR'] <= 0:
        raise ExecutionBlocked('Incomplete or invalid features for the latest completed candle')
    return row, bundle


def candle_decision(frame, symbol, min_probability):
    row, bundle = model_features(frame, symbol)
    model = bundle['model']
    inputs = row[bundle['features']]
    probabilities = dict(zip(model.classes_, model.predict_proba(inputs)[0], strict=True))
    if set(probabilities) != {0, 1} or not all(0 <= p <= 1 for p in probabilities.values()):
        raise ExecutionBlocked('Unsupported model classifier output')
    up, down = float(probabilities[1]), float(probabilities[0])
    direction = 'buy' if up >= min_probability and up > down else 'sell' if down >= min_probability and down > up else None
    completed = frame.tail(40)[['Open', 'High', 'Low', 'Close']]
    completed = completed.rename(columns=str.lower).to_dict('records')
    confirm=smc_ict_confirm(completed,direction) if direction else {'confirmed':False,'reason':'Model below confidence threshold'}
    return direction, up, down, confirm, float(row.iloc[0]['ATR'])


def bracket(side, entry, atr):
    direction = 1 if side == 'buy' else -1
    return entry - direction * 1.75 * atr, entry + direction * 3.5 * atr


def signals(mt5, symbol, *, min_probability=.62):
    """Use the latest completed M10 candle for both inference and confirmation."""
    rates = mt5.copy_rates_from_pos(symbol, mt5.TIMEFRAME_M10, 1, 600)
    if rates is None or len(rates) < 600:
        raise ExecutionBlocked('Insufficient closed MT5 M10 candles')
    frame = candle_frame(rates)
    candle_time = int(frame.iloc[-1]['Date'].timestamp())
    age = time.time() - (candle_time + 600)
    if not 0 <= age < 600 or frame['Date'].duplicated().any():
        raise ExecutionBlocked('Latest M10 candle is stale, incomplete, or duplicated')
    direction, up, down, confirm, atr = candle_decision(frame, symbol, min_probability)
    tick=mt5.symbol_info_tick(symbol)
    if tick is None: raise ExecutionBlocked('No broker tick')
    entry=float(tick.ask if direction=='buy' else tick.bid) if direction else None
    stop, target = bracket(direction, entry, atr) if direction else (None, None)
    return {'symbol':symbol,'candle_time':candle_time,'side':direction,
            'prob_up':round(up,4),'prob_down':round(down,4),'decision_confidence':max(up,down),
            'smc':confirm,'sl':stop,'tp':target,'atr':atr,
            '_closed_bars':[{'time':int(r['time']),'open':float(r['open']),'high':float(r['high']),
                             'low':float(r['low']),'close':float(r['close']),
                             'tick_volume':float(r['tick_volume'])} for r in rates]}


def run_worker(args):
    if platform.system() != 'Windows':
        raise ExecutionBlocked('Official MT5 Python execution worker requires Windows; dashboard works on Linux/macOS')
    try: import MetaTrader5 as mt5
    except ImportError as exc: raise ExecutionBlocked('Install MetaTrader5 on the Windows execution machine') from exc
    if not args.server.lower().startswith('justmarkets') and 'justmarkets' not in args.server.lower():
        raise ExecutionBlocked('Only JustMarkets server names are accepted')
    if args.mode=='demo' and not args.enable_demo:
        raise ExecutionBlocked('Demo orders need explicit --enable-demo; dry-run is the default')
    if args.mode=='live':
        if not args.enable_live or os.environ.get('TEMPESTBOT_LIVE_ENABLED')!='YES' or args.ack_live!=f'LIVE-{args.login}':
            raise ExecutionBlocked('Live needs --enable-live --ack-live LIVE-<login> and TEMPESTBOT_LIVE_ENABLED=YES')
    scalp = args.strategy == 'scalp'
    candle_seconds = 60 if scalp else 600
    retests = {}
    with ExitStack() as cleanup:
        improvement = None
        report = None
        if args.improvement_profile:
            improvement = cleanup.enter_context(closing(connect_improvement(args.improvement_db)))
            report = load_profile(improvement, args.improvement_profile, 'demo', verify_digest=True)
            if report['symbol'] != base_symbol(args.symbol[0]):
                raise ExecutionBlocked('Improvement profile is for a different symbol')
            candidate = report['candidate']
            costs = report['costs']
            rules = EntryRules(style=candidate['entry_style'], retest_bars=candidate['retest_bars'],
                               max_distance_atr=candidate['max_entry_distance_atr'],
                               commission_bps=costs['commission_bps'], slippage_points=costs['slippage_points']).validate()
        else:
            rules = EntryRules(style=args.scalp_entry, retest_bars=args.retest_bars,
                               max_distance_atr=args.max_entry_distance_atr,
                               commission_bps=args.entry_commission_bps, slippage_points=args.entry_slippage_points).validate()
        shared = None
        cloud_approval = bool(report and args.mode == 'live')
        if args.shared_feed or args.contribute_shared or args.monitor_label or cloud_approval:
            try:
                token = os.environ['SUPABASE_USER_JWT'].strip()
                if not token:
                    raise ValueError('Missing authenticated user JWT')
                shared = UserHub(SupabaseTransport(os.environ['SUPABASE_URL'],
                    os.environ['SUPABASE_PUBLISHABLE_KEY'], token))
            except (KeyError, ValueError) as exc:
                raise ExecutionBlocked('Cloud features require SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY and authenticated SUPABASE_USER_JWT') from exc
        def require_cloud_approval():
            try:
                allowed = shared.db.rpc('improvement_profile_is_approved', {'candidate_id':args.improvement_profile})
            except SharedError as exc:
                raise ExecutionBlocked('Cannot verify the admin approval of this live profile') from exc
            if allowed is not True:
                raise ExecutionBlocked('Live profile needs approval from the admin dashboard')

        if cloud_approval:
            require_cloud_approval()
        heartbeat = None
        telemetry = None
        decisions = {}
        if args.monitor_label:
            heartbeat = Heartbeat(shared.db, args.monitor_label, args.mode)
            if args.telemetry:
                telemetry = Telemetry(shared.db, args.monitor_label, LOGGER)
        journal = ExecutionJournal(Path.home() / '.tempestbot' / 'execution.sqlite3')
        cleanup.callback(journal.db.close)
        cleanup.enter_context(account_lease(journal, args.login))
        passwd = os.environ.get('TEMPESTBOT_MT5_PASSWORD') or getpass.getpass('MT5 trading password (not stored): ')
        init = {'login': args.login, 'password': passwd, 'server': args.server}
        if args.terminal:
            init['path'] = str(Path(args.terminal).expanduser().resolve())
        if not mt5.initialize(**init):
            if heartbeat:
                heartbeat.publish('disconnected', force=True)
            raise ExecutionBlocked(f'MT5 initialize failed (code {mt5.last_error()[0]})')
        cleanup.callback(mt5.shutdown)
        del passwd, init
        learning = LearningStore(args.learning_dir)
        cleanup.callback(learning.close)
        expected_mode = {
            'demo': getattr(mt5, 'ACCOUNT_TRADE_MODE_DEMO', 0),
            'live': getattr(mt5, 'ACCOUNT_TRADE_MODE_REAL', 2),
        }.get(args.mode)
        try:
            info = verify_identity(mt5, args.login, args.server, expected_mode=expected_mode)
        except ExecutionBlocked:
            if heartbeat:
                heartbeat.publish('disconnected', force=True)
            raise
        if heartbeat:
            cleanup.callback(heartbeat.publish, 'stopped', force=True)
        symbols=[select_symbol(mt5,s) for s in args.symbol]
        if report:
            contract = mt5.symbol_info(symbols[0])
            if contract is None or float(contract.point) != costs['point'] or getattr(info, 'currency', '') != 'USD':
                raise ExecutionBlocked('Profile requires a USD account and the evaluated symbol point size')
        if report and args.mode == 'demo':
            session = demo_session(improvement,args.improvement_profile,args.login,args.server)
            cleanup.callback(end_demo_session,improvement,session)
        LOGGER.info('Connected login=%s broker=%s server=%s mode=%s symbols=%s',info.login,info.company,info.server,args.mode,symbols)
        seen={}
        reversal_history={}
        shared_sent={}
        last_observation = float('-inf')
        while True:
            try:
                account = verify_identity(mt5, args.login, args.server, expected_mode=expected_mode)
            except ExecutionBlocked as exc:
                LOGGER.warning('Waiting for the verified terminal connection: %s', exc)
                if heartbeat:
                    heartbeat.publish('disconnected')
                if args.once:
                    raise
                time.sleep(min(args.poll, 30))
                continue
            state = 'online'
            issues = []
            if args.mode != 'dry-run':
                equity = _num(account.equity)
                if equity <= 0:
                    raise ExecutionBlocked('Account equity must be positive')
                _, daily_halted = journal.sample_daily_equity(args.login, equity, risk.daily_loss_percent)
                issues = audit_account(mt5, journal, args.login, args.server)
                try:
                    journal.require_reconciled(args.login)
                except ExecutionBlocked as exc:
                    issues.append(str(exc))
                if issues:
                    state = 'reconciliation'
                    LOGGER.warning('Broker audit: %s', '; '.join(issues))
                elif daily_halted:
                    state = 'daily_halt'
                else:
                    try:
                        positions, pending = mt5.positions_get(), mt5.orders_get()
                        if positions is None or pending is None or stop_exposure(mt5, positions, pending) >= equity * risk.max_exposure_percent / 100:
                            state = 'exposure_halt'
                    except ExecutionBlocked:
                        state = 'exposure_halt'
            if journal.file.with_name('PAUSE_TRADING').exists():
                state = 'paused'
            if heartbeat:
                heartbeat.publish(state)
            if args.mode != 'dry-run':
                account = verify_identity(mt5, args.login, args.server, expected_mode=expected_mode)
                start=datetime.now(timezone.utc)-timedelta(days=7)
                # Closed-deal audit is supplementary; MT5 history remains authoritative.
                deals=mt5.history_deals_get(start,datetime.now(timezone.utc))
                if deals is None:
                    LOGGER.warning('Broker closed-deal history unavailable; outcome tracking incomplete')
                else:
                    own=[d for d in deals if int(getattr(d,'magic',-1))==MAGIC]
                    LOGGER.debug('New closed deals stored: %s',learning.record_closed_deals(args.login,own))
                    if improvement is not None and time.monotonic() - last_observation >= 60:
                        verify_identity(mt5, args.login, args.server, expected_mode=expected_mode)
                        observe(improvement, journal, mt5, args.improvement_profile, args.mode,
                                args.login, args.server, own)
                        last_observation = time.monotonic()
            for symbol in symbols:
                decision = None
                try:
                    if scalp:
                        signal = scalp_signal(mt5, symbol)
                    else:
                        signal=signals(mt5,symbol,min_probability=args.threshold)
                        closed=signal.pop('_closed_bars')
                        learning.ingest(symbol,closed)
                        if args.contribute_shared:
                            pending=[r for r in closed if r['time']>shared_sent.get(symbol,0)]
                            if pending:
                                try:
                                    shared.contribute(symbol,pending)
                                    shared_sent[symbol]=max(r['time'] for r in pending)
                                except (SharedError, ValueError) as exc:
                                    LOGGER.warning('Shared contribution unavailable; market data retained locally: %s',exc)
                        learning.settle_predictions(symbol)
                        monitor=learning.monitoring(symbol)
                        if monitor['status']=='ALERT':
                            LOGGER.warning('Adaptive performance alert for %s: %s',symbol,monitor)
                    key=(symbol,signal['candle_time'])
                    if seen.get(symbol) == key[1]: continue
                    if scalp:
                        side = signal.get('side')
                        trigger = signal.get('trigger')
                        disagree = [frame for frame, direction in signal['context'].items() if direction != trigger]
                        decision = dict(candle=key[1], symbol=symbol, trigger=trigger, context=signal['context'], side=side,
                                        reason='No M1 breakout' if not trigger else
                                        ('Direction disagrees: ' + ', '.join(disagree) if disagree else 'Aligned setup'))
                    setup = None
                    if scalp:
                        previous = retests.get(symbol)
                        if previous and previous[0] == key[1]:
                            _, pending, setup, setup_reason = previous
                        else:
                            old_pending = previous[1] if previous and previous[0] == key[1]-60 else None
                            pending, setup, setup_reason = entry_decision(signal, old_pending, rules)
                            retests[symbol] = (key[1], pending, setup, setup_reason)
                        if setup_reason:
                            decision['reason'] = setup_reason
                        decision['entry_style'] = rules.style
                        decision['breakout_level'] = (setup or pending).level if (setup or pending) else signal['breakout_level']
                        if setup:
                            decision['side'] = setup.side
                    LOGGER.info('Signal %s',json.dumps(signal,default=str))
                    if args.shared_feed:
                        # Official shared feed is authoritative for direction. Never
                        # fall back to per-client signals when network access fails.
                        try:
                            public=shared.latest_signal(symbol)
                        except (SharedError,ValueError) as exc:
                            LOGGER.warning('Shared signal unavailable, execution blocked: %s',exc)
                            continue
                        if not public or int(public['candle_time'])!=signal['candle_time']:
                            LOGGER.info('No current central signal for the closed candle: %s',symbol)
                            continue
                        if public['direction']=='flat':
                            LOGGER.info('Central shared signal is FLAT: %s',symbol)
                            continue
                        if not args.threshold <= float(public['confidence']) <= 1:
                            LOGGER.info('Central confidence below configured threshold')
                            continue
                        # Common direction; each broker account has unique tick,
                        # contract size, stops and its own risk veto.
                        side=public['direction']
                        tick=mt5.symbol_info_tick(symbol)
                        if tick is None:continue
                        entry=float(tick.ask if side=='buy' else tick.bid)
                        atr=signal['atr']
                        stop, target = bracket(side, entry, atr)
                        signal.update(side=side, sl=stop, tp=target)
                        LOGGER.info('Central signal %s for %s model=%s strategy=%s',
                                    public['id'],symbol,public['model_version'],public['strategy_version'])
                    elif (not signal['side'] or not signal['smc']['confirmed']) and setup is None:
                        continue
                    if not 0 <= time.time() - (signal['candle_time'] + candle_seconds) < candle_seconds:
                        continue
                    if args.mode != 'dry-run':
                        verify_identity(mt5, args.login, args.server, expected_mode=expected_mode)
                    # Closed-candle AI decision drives an OPTIONAL protection-only manager.
                    # Shared mode MUST use the central signal, never a local disagreement.
                    if args.mode != 'dry-run':
                        if issues:
                            raise ExecutionBlocked('Account needs broker reconciliation')
                        journal.require_unpaused()
                        journal.require_reconciled(args.login)
                    reversal_confidence = (float(public['confidence']) if args.shared_feed
                                           else signal['decision_confidence'])
                    prior_exit = None
                    if args.exit_on_reversal:
                        streak = reversal_streak(reversal_history.get(symbol), candle=key[1],
                                                  side=signal['side'], confidence=reversal_confidence,
                                                  threshold=args.reversal_threshold, candle_seconds=candle_seconds)
                        reversal_history[symbol] = streak
                        prior_exit = journal.db.execute(
                            'SELECT status FROM orders WHERE key=?',
                            (exit_key(args.login, args.server, symbol, key[1]),),
                        ).fetchone()
                        if streak[2] >= args.reversal_bars and prior_exit is None:
                            exited = close_on_reversal(
                                mt5, login=args.login, server=args.server, symbol=symbol,
                                direction=signal['side'], candle=key[1], journal=journal,
                                expected_mode=expected_mode, dry_run=args.mode == 'dry-run',
                                candle_seconds=candle_seconds,
                            )
                            if exited:
                                if decision:
                                    decision['reason'] = 'Reversal exit confirmed' if args.mode != 'dry-run' else 'Dry run: reversal exit qualified'
                                LOGGER.info('%s reversal exit %s on %s',
                                            'DRY RUN: would attempt' if args.mode == 'dry-run' else 'Confirmed',
                                            signal['side'], symbol)
                                prior_exit = ('FILLED',)
                        if prior_exit and (not args.reverse_on_signal or prior_exit[0] != 'FILLED'
                                           or streak[2] < args.reversal_bars):
                            seen[symbol] = key[1]
                            continue
                    elif journal.db.execute('SELECT 1 FROM orders WHERE key=?',
                                            (exit_key(args.login, args.server, symbol, key[1]),)).fetchone():
                        # An exit-only candle must stay exit-only even after a restart.
                        seen[symbol] = key[1]
                        continue
                    if args.manage_positions and signal['side']:
                        management_confidence=(float(public['confidence']) if args.shared_feed
                                               else signal['decision_confidence'])
                        if args.mode == 'dry-run':
                            LOGGER.info('DRY RUN: would evaluate SL/TP management for %s',symbol)
                        else:
                            try:
                                modifications=manage_positions(mt5,login=args.login,server=args.server,
                                    approved_servers=[args.server],symbol=symbol,
                                    direction=signal['side'],confidence=management_confidence,
                                    atr=signal['atr'],candle_time=signal['candle_time'],
                                    journal=journal,config=ManagementConfig(min_confidence=args.management_threshold, max_tick_age=10 if scalp else 120),
                                    live_enabled=True, expected_mode=expected_mode, enforce_candle_freshness=True, candle_seconds=candle_seconds)
                                if modifications: LOGGER.info('Protected open trades: %s',modifications)
                            except ExecutionBlocked as exc:
                                LOGGER.warning('Position management blocked for %s: %s',symbol,exc)
                    seen[symbol] = key[1]
                    if not scalp and not args.shared_feed and learning.approved(symbol):
                        adaptive=confirmation(learning,symbol,closed,signal['side'],min_probability=args.adaptive_threshold)
                        LOGGER.info('Adaptive shadow decision %s',adaptive)
                    else:
                        adaptive={'allowed':False,'reason':'No approved challenger'}
                    if args.adaptive_gate and not args.shared_feed:
                        if monitor['status']=='ALERT':
                            LOGGER.warning('Adaptive gate halted: monitoring alert');continue
                        if not adaptive['allowed']:
                            LOGGER.info('Adaptive gate vetoed signal: %s',adaptive['reason']);continue
                    if scalp and setup is None:
                        continue
                    entry_side = setup.side if scalp else signal['side']
                    if state in ('daily_halt', 'exposure_halt'):
                        raise ExecutionBlocked('Daily loss limit reached' if state == 'daily_halt' else 'Account exposure limit reached')
                    if args.shared_feed and datetime.fromisoformat(public['expires_at'].replace('Z', '+00:00')) <= datetime.now(timezone.utc):
                        continue
                    tick = mt5.symbol_info_tick(symbol)
                    if tick is None:
                        raise ExecutionBlocked('Missing entry quote')
                    if scalp:
                        stamp = time.time()
                        info = mt5.symbol_info(symbol) if args.max_spread_points is not None else None
                        reason = entry_filter(stamp, sessions=args.entry_session, spread=tick.ask-tick.bid,
                                              point=getattr(info, 'point', 0), spread_cap=args.max_spread_points,
                                              last_exit=latest_exit(mt5, symbol, stamp, args.exit_cooldown),
                                              cooldown=args.exit_cooldown)
                        if args.exit_cooldown and prior_exit:
                            reason = reason or f'Exit cooldown — {args.exit_cooldown}s remaining'
                        if reason:
                            if decision and reason.startswith('Exit cooldown'):
                                decision['cooldown_until'] = stamp + int(reason.split(' — ')[1].split('s')[0])
                            raise ExecutionBlocked(reason)
                    quote = float(tick.ask if entry_side == 'buy' else tick.bid)
                    guard = None
                    if scalp:
                        stop, target = entry_bracket(setup, rules, quote)
                        info = mt5.symbol_info(symbol)
                        reason, ratio = quote_guard(setup, rules, quote, stop, target, getattr(info,'point',0))
                        if ratio is not None:
                            decision['net_rr'] = round(ratio, 2)
                        if reason:
                            raise ExecutionBlocked(reason)
                        def guard(price, sl, tp, point):
                            return quote_guard(setup, rules, price, sl, tp, point)[0]
                    else:
                        stop, target = bracket(entry_side, quote, signal['atr'])
                    if args.mode=='dry-run':
                        LOGGER.info('DRY RUN ONLY: order not sent')
                        if decision:
                            decision['reason'] = 'Dry run: order disabled'
                        continue
                    if cloud_approval:
                        require_cloud_approval()
                    receipt=execute_order(mt5,login=args.login,server=args.server,approved_servers=[args.server],
                                          symbol=symbol,side=entry_side,sl=stop,tp=target,
                                          candle_time=signal['candle_time'],journal=journal,
                                          risk=risk,live_enabled=True, max_tick_age=10 if scalp else 120,
                                          max_spread_points=args.max_spread_points,entry_quote_guard=guard,
                                          improvement_profile=args.improvement_profile, improvement_mode=args.mode,
                                          expected_mode=expected_mode, enforce_candle_freshness=True, candle_seconds=candle_seconds)
                    LOGGER.info('Broker receipt %s',receipt)
                    if decision:
                        decision['reason'] = 'Order filled'
                except ExecutionBlocked as exc:
                    if decision:
                        decision['reason'] = str(exc)
                    elif scalp:
                        decision = dict(symbol=symbol, candle=int(time.time()//60)*60-60, context={}, reason=str(exc))
                    LOGGER.warning('Blocked %s: %s',symbol,exc)
                except Exception:
                    LOGGER.exception('Unexpected scanner/worker failure: %s (no retry of unknown order)',symbol)
                    raise
                finally:
                    if decision:
                        decisions[symbol] = decision
            if telemetry:
                try:
                    telemetry.sample(mt5, journal, args.login, args.server, args.mode, state, decisions)
                except Exception:
                    LOGGER.exception('Optional telemetry snapshot failed')
            if args.once: break
            time.sleep(min(args.poll, 30) if heartbeat else args.poll)


class Heartbeat:
    def __init__(self, transport, label, mode):
        self.transport = transport
        self.label = label
        self.mode = mode
        self.last_time = None
        self.last_state = None

    def publish(self, state, *, force=False):
        now = time.monotonic()
        if not force and self.last_time is not None:
            elapsed = now - self.last_time
            if elapsed < 5 or (state == self.last_state and elapsed < 25):
                return
        self.last_time, self.last_state = now, state
        try:
            self.transport.rpc('publish_worker_heartbeat', {
                'worker_label': self.label, 'worker_mode': self.mode, 'worker_state': state,
            })
        except (SharedError, ValueError) as exc:
            LOGGER.warning('Worker status could not be published: %s', exc)


def worker_risk(args):
    return RiskConfig(risk_percent=args.risk, daily_loss_percent=args.daily_loss,
                      max_positions=args.max_positions, max_exposure_percent=args.max_exposure).validate()


def main(argv=None):
    p=argparse.ArgumentParser(description='TempestBot guarded MT5 signal and execution worker')
    p.add_argument('--login',type=int,required=True)
    p.add_argument('--server',required=True,help='Exact server name shown in your JustMarkets account')
    p.add_argument('--terminal',help='Absolute path to Windows terminal64.exe')
    p.add_argument('--symbol',action='append',required=True,help='Exact symbol, e.g. XAUUSDm; repeat for BTCUSDm')
    p.add_argument('--mode',choices=('dry-run','demo','live'),default='dry-run')
    p.add_argument('--enable-live',action='store_true')
    p.add_argument('--enable-demo',action='store_true')
    p.add_argument('--ack-live',default='')
    p.add_argument('--risk',type=float,default=.5)
    p.add_argument('--daily-loss',type=float,default=2.0)
    p.add_argument('--max-exposure',type=float,default=2.0,help='Combined stop risk as a percentage of current account equity')
    p.add_argument('--monitor-label',help='Opt in to private cloud heartbeat, using a unique label such as Main VPS')
    p.add_argument('--telemetry', action='store_true', help='Opt in to private decision, position and order telemetry')
    p.add_argument('--max-spread-points', type=float)
    p.add_argument('--entry-session', action='append', type=parse_session, default=[])
    p.add_argument('--exit-cooldown', type=int, default=0)
    p.add_argument('--max-positions',type=int,default=2)
    p.add_argument('--threshold',type=float,default=.62)
    p.add_argument('--learning-dir',type=Path,default=Path.home()/'.tempestbot'/'learning')
    p.add_argument('--shared-feed',action='store_true',help='Use only central Supabase signals, fail closed if unavailable')
    p.add_argument('--contribute-shared',action='store_true',help='Opt-in: submit closed M10 bars under user Auth JWT')
    p.add_argument('--adaptive-gate',action='store_true',help='Opt in to APPROVED adaptive model as a veto-only signal filter')
    p.add_argument('--adaptive-threshold',type=float,default=.62)
    p.add_argument('--manage-positions',action='store_true',help='Opt in: adjust own open TempestBot SL/TP only on confirmed closed-candle signals')
    p.add_argument('--management-threshold',type=float,default=.70)
    p.add_argument('--exit-on-reversal', action='store_true', help='Exit own trades on confirmed opposite signals')
    p.add_argument('--reverse-on-signal', action='store_true', help='Also permit a new entry after a confirmed exit')
    p.add_argument('--reversal-threshold', type=float, default=.70)
    p.add_argument('--reversal-bars', type=int, default=2, choices=range(1, 5))
    p.add_argument('--strategy', choices=('scalp', 'm10'), help='Multi-timeframe scalp or bundled M10 model. Explicit selection required for live scalping.')
    p.add_argument('--improvement-profile', help='Run a historically qualified profile; live execution also requires approval')
    p.add_argument('--improvement-db', type=Path, default=DEFAULT_DB)
    p.add_argument('--scalp-entry', choices=ENTRY_STYLES)
    p.add_argument('--retest-bars', type=int, default=3)
    p.add_argument('--max-entry-distance-atr', type=float, default=.5)
    p.add_argument('--entry-commission-bps', type=float, default=0, help='Estimated commission per fill')
    p.add_argument('--entry-slippage-points', type=float, default=0, help='Estimated adverse slippage per fill')
    p.add_argument('--poll',type=float)
    p.add_argument('--once',action='store_true')
    args=p.parse_args(argv)
    m10_features = args.shared_feed or args.contribute_shared or args.adaptive_gate
    args.strategy = args.strategy or ('m10' if m10_features or args.mode == 'live' else 'scalp')
    if args.strategy == 'scalp' and m10_features:
        p.error('Shared and adaptive signal features require the M10 strategy')
    if args.telemetry and not args.monitor_label:
        p.error('--telemetry requires --monitor-label')
    if args.max_spread_points is not None and not 0 < args.max_spread_points < float('inf'):
        p.error('Spread limit must be positive and finite')
    if not 0 <= args.exit_cooldown <= 86400:
        p.error('Cooldown must be 0–86400 seconds')
    if args.strategy != 'scalp' and (args.max_spread_points is not None or args.entry_session or args.exit_cooldown):
        p.error('Fast-market entry filters require the scalp strategy')
    if args.improvement_profile and (
        args.strategy != 'scalp' or len(args.symbol) != 1 or args.exit_on_reversal or args.manage_positions
        or args.entry_session or args.max_spread_points is not None or args.exit_cooldown
        or args.scalp_entry is not None or args.retest_bars != 3 or args.max_entry_distance_atr != .5
        or args.entry_commission_bps or args.entry_slippage_points
        or worker_risk(args) != RiskConfig()
    ):
        p.error('Improvement profiles require one scalp symbol, default risk settings, and profile-controlled entry rules')
    args.scalp_entry = args.scalp_entry or ('breakout' if args.mode == 'live' else 'retest')
    try:
        EntryRules(style=args.scalp_entry, retest_bars=args.retest_bars, max_distance_atr=args.max_entry_distance_atr,
                   commission_bps=args.entry_commission_bps, slippage_points=args.entry_slippage_points).validate()
    except ValueError as exc:
        p.error(str(exc))
    if args.poll is None:
        args.poll = 5 if args.strategy == 'scalp' else 30
    if not (0.5 <= args.threshold <= .95 and 0.5 <= args.adaptive_threshold <= .99):
        p.error('Threshold outside permitted range')
    if not 1 <= args.poll <= (30 if args.strategy == 'scalp' else 3600):
        p.error('Polling must be 1–30 seconds for scalping or 1–3600 seconds for M10')
    if args.monitor_label is not None and not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9 _-]{0,47}', args.monitor_label):
        p.error('monitor label must be 1–48 letters, digits, spaces, underscores or hyphens')
    if args.reverse_on_signal and not args.exit_on_reversal:
        p.error('--reverse-on-signal requires --exit-on-reversal')
    if not .5 <= args.reversal_threshold <= .99:
        p.error('--reversal-threshold must be between 0.50 and 0.99')
    worker_risk(args)
    ManagementConfig(min_confidence=args.management_threshold).validate()
    if len(args.symbol)>2 or len(set(map(base_symbol,args.symbol)))!=len(args.symbol):
        p.error('Use at most one exact XAUUSD symbol and one exact BTCUSD symbol')
    logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s')
    try: run_worker(args)
    except (ExecutionBlocked,ValueError) as exc: p.exit(2,f'TempestBot refused execution: {exc}\n')

if __name__=='__main__': main()
