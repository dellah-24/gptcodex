"""Rule-based multi-timeframe analysis using only fully closed MT5 bars."""
import math
import time

from .live import ExecutionBlocked

TIMEFRAMES = (('M1', 60), ('M5', 300), ('M15', 900), ('H1', 3600))
WARMUP = 100
STOP_ATR = 1.25
TARGET_ATR = 2.5


def _closed(mt5, symbol, timeframe, seconds, as_of):
    rates = mt5.copy_rates_from_pos(symbol, getattr(mt5, 'TIMEFRAME_' + timeframe), 1, WARMUP + 1)
    if rates is None:
        raise ExecutionBlocked(f'{timeframe} rates unavailable')
    bars = []
    for rate in sorted(rates, key=lambda row: row['time']):
        stamp = int(rate['time'])
        if stamp + seconds > as_of:
            continue
        opening, high, low, close = (float(rate[name]) for name in ('open', 'high', 'low', 'close'))
        if (stamp % seconds or not all(math.isfinite(v) for v in (opening, high, low, close))
                or not 0 < low <= min(opening, close) <= max(opening, close) <= high):
            raise ExecutionBlocked(f'{timeframe} contains invalid bar data')
        if bars and stamp <= bars[-1][0]:
            raise ExecutionBlocked(f'{timeframe} contains duplicate bars')
        bars.append((stamp, opening, high, low, close))
    if (len(bars) < WARMUP or bars[-1][0] != (int(as_of) // seconds - 1) * seconds
            or any(b[0] - a[0] != seconds for a, b in zip(bars[-4:], bars[-3:]))):
        raise ExecutionBlocked(f'{timeframe} history is stale, incomplete, or has recent gaps')
    return bars[-WARMUP:]


def _ema(values, length):
    value = sum(values[:length]) / length
    weight = 2 / (length + 1)
    for close in values[length:]:
        value += weight * (close - value)
    return value


def _trend(bars, fast, slow):
    closes = [b[4] for b in bars]
    quick, gradual = _ema(closes, fast), _ema(closes, slow)
    return 'buy' if closes[-1] > quick > gradual else 'sell' if closes[-1] < quick < gradual else None


def scalp_bracket(side, quote, atr):
    sign = 1 if side == 'buy' else -1
    return quote - sign * STOP_ATR * atr, quote + sign * TARGET_ATR * atr


def scalp_signal(mt5, symbol, *, now=None):
    now = time.time() if now is None else now
    lower = _closed(mt5, symbol, 'M1', 60, now)
    candle = lower[-1][0]
    context = {
        name: _trend(_closed(mt5, symbol, name, period, candle + 60), *lengths)
        for (name, period), lengths in zip(TIMEFRAMES[1:], ((8, 21), (12, 26), (12, 26)), strict=True)
    }
    previous = lower[-4:-1]
    _, opening, high, low, close = lower[-1]
    trigger = (
        'buy' if close > opening and close > max(b[2] for b in previous) else
        'sell' if close < opening and close < min(b[3] for b in previous) else None
    )
    side = trigger if trigger and all(direction == trigger for direction in context.values()) else None
    ranges = [max(b[2] - b[3], abs(b[2] - a[4]), abs(b[3] - a[4]))
              for a, b in zip(lower[-15:], lower[-14:])]
    atr = sum(ranges) / len(ranges)
    if not math.isfinite(atr) or atr <= 0:
        raise ExecutionBlocked('Invalid M1 average true range')
    return {
        'symbol': symbol, 'candle_time': candle, 'side': side, 'atr': atr,
        'timeframe': 'M1', 'context': context, 'trigger': trigger,
        'breakout_level': max(b[2] for b in previous) if side == 'buy' else
                          min(b[3] for b in previous) if side == 'sell' else None,
        'high': high, 'low': low, 'close': close,
        'decision_confidence': 1.0 if side else 0.0,
        'smc': {'confirmed': bool(side), 'reason': 'M1 breakout with M5/M15/H1 alignment' if side else
                'M1 trigger and higher timeframes do not align'},
    }
