"""TempestBot controlled model learning. No unattended live-model promotion.

Closed-bar store -> chronological purged walk-forward evaluation -> quarantined
candidate -> explicit manual approval -> optional confirmation-only inference.
Never accepts arbitrary pickle paths from a CLI or API.
"""
import argparse
import csv
import hashlib
import json
import math
import os
import sqlite3
import tempfile
from datetime import datetime, timezone
from pathlib import Path

FEATURE_NAMES=('ret3','ret10','ret20','atr14_pct','break_high','break_low',
               'range_pct','body_pct','log_volume')
BASES=('XAUUSD','BTCUSD')


def utcnow():
    return datetime.now(timezone.utc).isoformat()


def base_symbol(symbol):
    from .live import base_symbol as check
    return check(symbol)


class LearningStore:
    def __init__(self, root):
        self.root=Path(root).expanduser().resolve()
        self.root.mkdir(parents=True,exist_ok=True)
        self.db=sqlite3.connect(self.root/'learning.sqlite3')
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.executescript('''
          CREATE TABLE IF NOT EXISTS bars(symbol TEXT NOT NULL, time INTEGER NOT NULL,
            open REAL NOT NULL, high REAL NOT NULL, low REAL NOT NULL,
            close REAL NOT NULL, tick_volume REAL NOT NULL,
            PRIMARY KEY(symbol,time));
          CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL, symbol TEXT NOT NULL, event TEXT NOT NULL, detail TEXT NOT NULL);
          CREATE TABLE IF NOT EXISTS models(symbol TEXT NOT NULL, version TEXT NOT NULL,
            sha256 TEXT NOT NULL, status TEXT NOT NULL, metrics TEXT NOT NULL,
            created_at TEXT NOT NULL, PRIMARY KEY(symbol,version));
          CREATE TABLE IF NOT EXISTS deals(account INTEGER NOT NULL, ticket INTEGER NOT NULL, symbol TEXT NOT NULL,
            time INTEGER NOT NULL, net_pnl REAL NOT NULL, volume REAL NOT NULL,
            PRIMARY KEY(account,ticket));
          CREATE TABLE IF NOT EXISTS predictions(symbol TEXT NOT NULL, bar_time INTEGER NOT NULL,
            model_version TEXT NOT NULL, predicted INTEGER NOT NULL, confidence REAL NOT NULL,
            realized INTEGER, PRIMARY KEY(symbol,bar_time,model_version));
        ''')
        self.db.commit()
        try: os.chmod(self.root/'learning.sqlite3',0o600)
        except OSError: pass

    def close(self):self.db.close()

    def log(self,symbol,event,detail):
        symbol=base_symbol(symbol)
        with self.db:
            self.db.execute('INSERT INTO events(timestamp,symbol,event,detail) VALUES(?,?,?,?)',
                            (utcnow(),symbol,event,json.dumps(detail,sort_keys=True,default=str)))

    def ingest(self,symbol,rows):
        symbol=base_symbol(symbol)
        verified=[]
        for r in rows:
            timestamp=int(r['time'])
            vals=[float(r[k]) for k in ('open','high','low','close','tick_volume')]
            o,h,l,c,v=vals
            if timestamp<=0 or not all(map(math.isfinite,vals)) or min(o,h,l,c)<=0 or v<0 or h<max(o,c) or l>min(o,c) or h<l:
                raise ValueError('Invalid closed market bar')
            verified.append((symbol,timestamp,*vals))
        with self.db:
            self.db.executemany('INSERT OR IGNORE INTO bars VALUES(?,?,?,?,?,?,?)',verified)
        return len(verified)

    def record_closed_deals(self,account,deals):
        """Store MT5 exit deals, not inferred full-trade P/L; partial fills remain separate."""
        written=0
        for deal in deals:
            if getattr(deal,'entry',None) not in (1,2,3): # OUT, INOUT, OUT_BY
                continue
            try: symbol=base_symbol(deal.symbol)
            except (ValueError,RuntimeError):continue
            values=[float(getattr(deal,k,0)) for k in ('profit','commission','swap','fee','volume')]
            if not all(map(math.isfinite,values)) or values[-1]<=0:continue
            with self.db:
                changed=self.db.execute('INSERT OR IGNORE INTO deals VALUES(?,?,?,?,?,?)',
                    (int(account),int(deal.ticket),symbol,int(deal.time),sum(values[:-1]),values[-1]))
                written+=changed.rowcount
        return written

    def deal_summary(self,symbol,account=None):
        symbol=base_symbol(symbol)
        if account is None:
            rows=self.db.execute('SELECT net_pnl FROM deals WHERE symbol=?',(symbol,)).fetchall()
        else:
            rows=self.db.execute('SELECT net_pnl FROM deals WHERE symbol=? AND account=?',(symbol,int(account))).fetchall()
        values=[v for (v,) in rows]
        return {'closed_deals':len(values),'net_realized_pnl':round(sum(values),2),
                'winning_deals':sum(v>0 for v in values),'losing_deals':sum(v<0 for v in values)}

    def market(self,symbol):
        symbol=base_symbol(symbol)
        return [dict(zip(('time','open','high','low','close','tick_volume'),r)) for r in
                self.db.execute('SELECT time,open,high,low,close,tick_volume FROM bars WHERE symbol=? ORDER BY time',(symbol,))]

    def candidate(self,symbol,version,digest,metrics):
        symbol=base_symbol(symbol)
        with self.db:
            self.db.execute('INSERT INTO models VALUES(?,?,?,?,?,?)',
                            (symbol,version,digest,'CANDIDATE',json.dumps(metrics),utcnow()))
        self.log(symbol,'candidate_created',{'version':version,'sha256':digest,'metrics':metrics})

    def approved(self,symbol):
        symbol=base_symbol(symbol)
        return self.db.execute("SELECT version,sha256,metrics FROM models WHERE symbol=? AND status='APPROVED'",(symbol,)).fetchone()

    def approve(self,symbol,version,acknowledge):
        symbol=base_symbol(symbol)
        if acknowledge != f'APPROVE-{symbol}-{version}':
            raise ValueError('Approval acknowledgement does not match exact candidate')
        row=self.db.execute('SELECT sha256,status,metrics FROM models WHERE symbol=? AND version=?',(symbol,version)).fetchone()
        if not row or row[1]!='CANDIDATE': raise ValueError('No candidate with that exact version')
        artifact=self.root/'models'/symbol/(version+'.joblib')
        if not artifact.is_file() or digest_file(artifact)!=row[0]: raise ValueError('Candidate artifact missing or modified')
        metrics=json.loads(row[2])
        if not metrics.get('passed'): raise ValueError('Candidate failed out-of-sample acceptance gates')
        with self.db:
            self.db.execute("UPDATE models SET status='RETIRED' WHERE symbol=? AND status='APPROVED'",(symbol,))
            self.db.execute("UPDATE models SET status='APPROVED' WHERE symbol=? AND version=?",(symbol,version))
        self.log(symbol,'candidate_approved',{'version':version})

    def rollback(self,symbol,acknowledge):
        symbol=base_symbol(symbol)
        if acknowledge!=f'DISABLE-{symbol}':raise ValueError('Explicit disable acknowledgement required')
        with self.db:
            self.db.execute("UPDATE models SET status='RETIRED' WHERE symbol=? AND status='APPROVED'",(symbol,))
        self.log(symbol,'approved_model_disabled',{})

    def track_prediction(self,symbol,bar_time,version,predicted,confidence):
        symbol=base_symbol(symbol)
        with self.db:
            self.db.execute('INSERT OR IGNORE INTO predictions(symbol,bar_time,model_version,predicted,confidence) VALUES(?,?,?,?,?)',
                            (symbol,int(bar_time),version,int(predicted),float(confidence)))

    def settle_predictions(self,symbol,horizon=3,threshold=.0005):
        symbol=base_symbol(symbol)
        bars=self.market(symbol)
        by_time={r['time']:i for i,r in enumerate(bars)}
        rows=self.db.execute('SELECT bar_time,model_version FROM predictions WHERE symbol=? AND realized IS NULL',(symbol,)).fetchall()
        settled=0
        with self.db:
            for t,version in rows:
                if t not in by_time or by_time[t]+horizon>=len(bars):continue
                i=by_time[t]; ret=bars[i+horizon]['close']/bars[i]['close']-1
                label=1 if ret>threshold else -1 if ret<-threshold else 0
                self.db.execute('UPDATE predictions SET realized=? WHERE symbol=? AND bar_time=? AND model_version=?',
                                (label,symbol,t,version))
                settled+=1
        return settled

    def monitoring(self,symbol,window=100):
        symbol=base_symbol(symbol)
        rows=self.db.execute('SELECT predicted,realized,confidence FROM predictions WHERE symbol=? AND realized IS NOT NULL ORDER BY bar_time DESC LIMIT ?',
                             (symbol,window)).fetchall()
        if not rows:return {'count':0,'status':'INSUFFICIENT_DATA'}
        correct=sum(p==y for p,y,_ in rows)/len(rows)
        n=len(rows)
        counts={k:sum(y==k for _,y,_ in rows) for k in (-1,0,1)}
        baseline=max(counts.values())/n
        # Explicit conservative alert; requires at least 30 independently resolved labels.
        alert=n>=30 and (correct < baseline or correct < .40)
        return {'count':n,'accuracy':round(correct,4),'majority_baseline':round(baseline,4),
                'status':'ALERT' if alert else 'INSUFFICIENT_DATA' if n<30 else 'OK'}


def digest_file(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda:f.read(65536),b''): h.update(chunk)
    return h.hexdigest()


def features_at(bars,i):
    """Only present/past closed candles; must match research feature definition."""
    if i<20:raise ValueError('Requires 20 preceding bars')
    recent=bars[i-20:i+1];close=recent[-1]['close']
    returns=[recent[j]['close']/recent[j-1]['close']-1 for j in range(1,len(recent))]
    tr=[max(recent[k]['high']-recent[k]['low'],abs(recent[k]['high']-recent[k-1]['close']),
            abs(recent[k]['low']-recent[k-1]['close'])) for k in range(1,len(recent))]
    result=[sum(returns[-3:]),sum(returns[-10:]),sum(returns)/20,
            sum(tr[-14:])/14/close,
            (close-max(b['high'] for b in recent[:-1]))/close,
            (close-min(b['low'] for b in recent[:-1]))/close,
            (recent[-1]['high']-recent[-1]['low'])/close,
            (recent[-1]['close']-recent[-1]['open'])/close,
            math.log1p(recent[-1]['tick_volume'])]
    if not all(math.isfinite(x) for x in result):raise ValueError('Nonfinite features')
    return result


def labeled_dataset(bars,horizon=3,threshold=.0005):
    if horizon<1 or threshold<0:raise ValueError('Invalid label settings')
    import numpy as np
    X=[];y=[];indexes=[]
    for i in range(30,len(bars)-horizon):
        x=features_at(bars,i)
        ret=bars[i+horizon]['close']/bars[i]['close']-1
        label=1 if ret>threshold else -1 if ret<-threshold else 0
        X.append(x);y.append(label);indexes.append(i)
    if not X:raise ValueError('Insufficient history')
    return np.asarray(X),np.asarray(y),indexes


def evaluate_candidate(bars,*,horizon=3,threshold=.0005,min_train=300,test_size=80):
    """Purged, expanding-time folds; never trains on overlapping test-label horizon."""
    import numpy as np
    from sklearn.ensemble import HistGradientBoostingClassifier
    from sklearn.metrics import balanced_accuracy_score,accuracy_score
    X,y,indices=labeled_dataset(bars,horizon,threshold)
    if len(y)<min_train+horizon+test_size*2:raise ValueError('Insufficient data for two OOS folds')
    predictions=[]; actual=[];folds=[]
    cut=min_train+horizon
    while cut+test_size<=len(y):
        train_end=cut-horizon
        if len(set(y[:train_end]))<2:raise ValueError('Training has fewer than two classes')
        model=HistGradientBoostingClassifier(max_iter=90,max_leaf_nodes=15,l2_regularization=2,random_state=23)
        model.fit(X[:train_end],y[:train_end]); pred=model.predict(X[cut:cut+test_size]); target=y[cut:cut+test_size]
        predictions.extend(map(int,pred));actual.extend(map(int,target))
        folds.append({'test_start_index':indices[cut],'test_end_index':indices[cut+test_size-1],
                      'accuracy':round(float(accuracy_score(target,pred)),4),'size':test_size})
        cut+=test_size
    if len(folds)<2:raise ValueError('Require at least two walk-forward folds')
    accuracy=float(accuracy_score(actual,predictions)); balanced=float(balanced_accuracy_score(actual,predictions))
    majority=max(actual.count(label) for label in set(actual))/len(actual)
    # Accuracy is a directional proxy, not a cost-aware backtest or profitability metric.
    passed=len(actual)>=160 and accuracy>=majority+.02 and balanced>=.40
    return {'accuracy':round(accuracy,4),'balanced_accuracy':round(balanced,4),
            'majority_baseline':round(majority,4),'oos_samples':len(actual),
            'folds':folds,'passed':bool(passed),'horizon':horizon,'threshold':threshold,
            'evaluation':'3-class closed-candle direction; no cost or profitability inference'}


def train_candidate(store,symbol):
    from sklearn.ensemble import HistGradientBoostingClassifier
    import joblib
    symbol=base_symbol(symbol);bars=store.market(symbol)
    result=evaluate_candidate(bars)
    X,y,indices=labeled_dataset(bars)
    # Exclude last horizon labels by dataset construction. Candidate is NEVER auto-approved.
    model=HistGradientBoostingClassifier(max_iter=90,max_leaf_nodes=15,l2_regularization=2,random_state=23)
    if len(set(y))<2:raise ValueError('Not enough label variation')
    model.fit(X,y)
    version=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    folder=store.root/'models'/symbol;folder.mkdir(parents=True,exist_ok=True)
    target=folder/(version+'.joblib')
    with tempfile.NamedTemporaryFile(dir=folder,suffix='.joblib',delete=False) as tmp:
        path=Path(tmp.name)
    try:
        joblib.dump({'model':model,'features':FEATURE_NAMES,'version':version,'symbol':symbol},path)
        os.replace(path,target)
    finally:
        if path.exists():path.unlink()
    digest=digest_file(target)
    store.candidate(symbol,version,digest,result)
    return {'symbol':symbol,'version':version,'sha256':digest,**result}


def confirmation(store,symbol,bars,expected_direction,*,min_probability=.62):
    """Approved model only VETOES legacy signals. No candidate generates an order."""
    import joblib
    import numpy as np
    symbol=base_symbol(symbol)
    row=store.approved(symbol)
    if row is None:return {'allowed':False,'reason':'No approved adaptive model'}
    version,digest,metrics=row
    path=store.root/'models'/symbol/(version+'.joblib')
    if not path.is_file() or digest_file(path)!=digest:
        return {'allowed':False,'reason':'Approved model file failed integrity check'}
    # Only operator-created trusted artifacts inside the model registry may be deserialized.
    bundle=joblib.load(path)
    if bundle.get('symbol')!=symbol or tuple(bundle.get('features',()))!=FEATURE_NAMES or bundle.get('version')!=version:
        return {'allowed':False,'reason':'Approved model schema mismatch'}
    proba=bundle['model'].predict_proba(np.asarray([features_at(bars,len(bars)-1)]))[0]
    classes=list(map(int,bundle['model'].classes_))
    likelihood={c:float(p) for c,p in zip(classes,proba)}
    predicted=max(likelihood,key=likelihood.get);confidence=likelihood[predicted]
    store.track_prediction(symbol,bars[-1]['time'],version,predicted,confidence)
    expected=1 if expected_direction=='buy' else -1 if expected_direction=='sell' else None
    allowed=expected is not None and predicted==expected and confidence>=min_probability
    return {'allowed':bool(allowed),'version':version,'predicted':predicted,'confidence':round(confidence,4),
            'reason':'Approved challenger agrees' if allowed else 'Adaptive confirmation did not agree'}


def main(argv=None):
    parser=argparse.ArgumentParser(description='TempestBot controlled learning; NO automatic live model replacement')
    parser.add_argument('--data-dir',type=Path,default=Path.home()/'.tempestbot'/'learning')
    sub=parser.add_subparsers(dest='command',required=True)
    for cmd in ('train','status','monitor','approve','disable','ingest-csv'):
        p=sub.add_parser(cmd);p.add_argument('--symbol',required=True)
        if cmd=='approve':p.add_argument('--version',required=True);p.add_argument('--ack',required=True)
        if cmd=='disable':p.add_argument('--ack',required=True)
        if cmd=='ingest-csv':p.add_argument('--csv',type=Path,required=True)
    args=parser.parse_args(argv);store=LearningStore(args.data_dir)
    try:
        symbol=base_symbol(args.symbol)
        if args.command=='train':result=train_candidate(store,symbol)
        elif args.command=='approve':store.approve(symbol,args.version,args.ack);result={'approved':args.version}
        elif args.command=='disable':store.rollback(symbol,args.ack);result={'disabled':symbol}
        elif args.command=='ingest-csv':
            with args.csv.open(newline='',encoding='utf-8-sig') as fp:
                reader=csv.DictReader(fp)
                if not {'time','open','high','low','close','tick_volume'}.issubset(reader.fieldnames or []):
                    raise ValueError('CSV requires time (Unix seconds),open,high,low,close,tick_volume')
                count=store.ingest(symbol,reader)
            result={'ingested_rows':count}
        elif args.command=='monitor':
            store.settle_predictions(symbol)
            result=store.monitoring(symbol)
        else:
            result={'bars':len(store.market(symbol)),'approved':store.approved(symbol),
                    'candidates':store.db.execute('SELECT version,status,metrics FROM models WHERE symbol=? ORDER BY created_at DESC LIMIT 10',(symbol,)).fetchall(),
                    'monitor':store.monitoring(symbol),'closed_deals':store.deal_summary(symbol)}
        print(json.dumps(result,indent=2))
    finally:store.close()
if __name__=='__main__':main()
