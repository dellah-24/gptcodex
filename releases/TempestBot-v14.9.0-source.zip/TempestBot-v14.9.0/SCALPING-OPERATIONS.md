# TempestBot v14.6 scalping operations

## Dashboard and telemetry

Apply `supabase/006_worker_telemetry.sql` after migration 005. Deploy the existing `web/` directory using your established Cloudflare Pages configuration. No broker orders or account passwords are sent to Supabase.

Start a Windows worker with both `--monitor-label "Demo worker"` and `--telemetry`. The worker uses its existing authenticated Supabase user JWT. Sign in to the dashboard as that user. The monitoring guide describes JWT renewal. The worker uploads bounded snapshots asynchronously and does not rely on telemetry delivery to make trade decisions.

- **Signals** shows the latest M1 decision per symbol and worker, its M5/M15/H1 alignment and the reason recorded by the worker.
- **Positions** shows sampled broker-confirmed bot positions, their protective levels, holding time and unrealized P&L. Snapshots age out after two minutes. The execution timeline includes recent entry and exit attempts and status changes from the local journal. A prepared submission is a durable local reservation, distinct from a broker-reported submission.
- **Overview** has an opt-in trading-alert toggle. Alerts are grouped by type and shown in-app. The setting is saved per user in the current browser. There is no background push delivery.
- The mobile shortcut bar links directly to Overview, Signals and Positions. Trading controls remain on the Windows host.

## Fast-market filters

Optional scalping flags:

- `--max-spread-points 25` caps the ask–bid spread in **broker points**. Choose a value for the exact symbol specification. The existing spread-to-stop check also applies.
- Repeat `--entry-session HH:MM-HH:MM` for UTC entry windows, including windows that cross midnight.
- `--exit-cooldown 45` blocks new exposure on the same symbol for 45 seconds after a bot closing deal. A positive cooldown also blocks same-candle reversal re-entry after a recorded exit. Existing exits and protective actions remain available subject to their own checks.

Spread, session and cooldown checks apply to new entries. They do not close positions when a session ends. Check the worker's logs and Signals page during demo testing.

## Bid/ask tick replay

Export chronological JustMarkets ticks for one symbol with the CSV header `time,bid,ask`. Time accepts Unix seconds or ISO timestamps with a timezone. Allow at least 100 completed hours of warmup. Supply broker-specific costs. The example values are placeholders.

```powershell
python -m tempestbot.scalp_replay XAUUSD-ticks.csv --symbol XAUUSD --point 0.01 --slippage-points 2 --commission-bps 1 --buy-swap-bps 0 --sell-swap-bps 0 --exit-on-reversal --reverse-on-signal --max-spread-points 25 --out scalp-report.json
```

The JSON contains net performance and drawdown, UTC session, spread and holding-time breakdowns, skipped-decision counts, and the spread, configured slippage and holding duration of each trade. The replay aggregates bid ticks into the live strategy's timeframes, uses bid/ask for entry and exit, and exercises the same reversal streak and fast-market checks. It assumes one symbol at a time, fractional sizing, configured slippage and a USD quote/account. Broker latency, margin and partial-fill behavior still need demo checks. A report with no entries or insufficient warmup provides no performance estimate.
