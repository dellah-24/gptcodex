# TempestBot v14.5 multi-timeframe scalping

`--strategy scalp` uses a rules-based decision across four MT5 timeframes:

| Timeframe | Role |
|---|---|
| H1 | Direction from price and 12/26 EMA alignment |
| M15 | Independent direction confirmation with 12/26 EMAs |
| M5 | Near-term confirmation with 8/21 EMAs |
| M1 | Directional close beyond the preceding three candles' high or low |

All four must agree. Decisions use completed candles only. The worker skips a decision if a required timeframe is stale or has gaps in its latest four bars. M1 true range sets the initial stop at 1.25 ATR and target at 2.5 ATR, subject to the usual broker, spread, position-size, and exposure checks. Scalping polls every five seconds by default and rejects execution quotes older than ten seconds. The rule score expresses agreement, with no estimated win probability.

For a demo dry run on Windows, substitute the actual login, server and symbol:

```powershell
python -m worker.main --login 123456 --server JustMarkets-Demo --symbol XAUUSDm --strategy scalp --exit-on-reversal
```

Add `--mode demo --enable-demo` to permit demo orders after checking logs. Add `--reverse-on-signal` to let the worker consider an opposite entry after it verifies the exit. The default exit streak is two consecutive aligned opposite M1 candles in scalp mode. Stop and target orders remain at the broker while positions are open. There is no forced time-based exit.

Scalping is the default for new dry-run and demo sessions without M10-only options. Existing live commands stay on M10 unless `--strategy scalp` is explicit. The bundled classifier, central shared feed and adaptive gate remain M10-only, and scalping signals are logged on the worker rather than published to Supabase. Mobile monitoring can still report worker status.

The bundled M10 historical replay does not measure scalping performance. Verify feed cadence, spread, slippage, and fills on your broker's demo account before considering live use.
