begin;
create table if not exists public.worker_telemetry (
 user_id uuid not null,
 label text not null,
 sampled_at timestamptz not null default now(),
 snapshot jsonb not null check (jsonb_typeof(snapshot) = 'object' and octet_length(snapshot::text) <= 48000),
 primary key(user_id,label),
 foreign key(user_id,label) references public.worker_heartbeats(user_id,label) on delete cascade
);
alter table public.worker_telemetry enable row level security;
revoke all on public.worker_telemetry from public,anon,authenticated;
grant select on public.worker_telemetry to authenticated;
drop policy if exists own_worker_telemetry on public.worker_telemetry;
create policy own_worker_telemetry on public.worker_telemetry for select to authenticated
 using(user_id=(select auth.uid()));
create or replace function public.publish_worker_telemetry(worker_label text, worker_snapshot jsonb)
returns void language sql security definer set search_path = '' as $$
 insert into public.worker_telemetry(user_id,label,snapshot)
 values(auth.uid(),worker_label,worker_snapshot)
 on conflict(user_id,label) do update set sampled_at=now(),snapshot=excluded.snapshot
$$;
revoke all on function public.publish_worker_telemetry(text,jsonb) from public,anon,authenticated;
grant execute on function public.publish_worker_telemetry(text,jsonb) to authenticated;
commit;
