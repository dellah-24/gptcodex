-- Apply after 001_shared_learning.sql and 002_app_foundation.sql on a STAGING database first.
-- Remove access granted by default to PUBLIC and minimize exposure of RPCs.
revoke all on function public.enforce_two_accounts() from public, anon, authenticated;
revoke all on function public.approve_shared_model(text,text,text) from public, anon, authenticated;
-- Prevent updates of an account from bypassing the registration guard. User updates are denied by grants/RLS.
-- Create durable admin-only security events. No client grants.
create table if not exists public.security_events (
 id bigint generated always as identity primary key,
 actor_id uuid, action text not null, details jsonb not null default '{}'::jsonb,
 created_at timestamptz not null default now()
);
alter table public.security_events enable row level security;
revoke all on public.security_events from public, anon, authenticated;
-- Default privileges in existing schemas and application RLS must be reviewed with Supabase advisor.
