begin;

create table if not exists public.worker_heartbeats (
  user_id uuid not null references auth.users(id) on delete cascade,
  label text not null check (label ~ '^[A-Za-z0-9][A-Za-z0-9 _-]{0,47}$'),
  mode text not null check (mode in ('dry-run','demo','live')),
  state text not null check (state in ('online','paused','disconnected','reconciliation','daily_halt','exposure_halt','stopped')),
  sampled_at timestamptz not null default now(),
  primary key (user_id, label)
);
alter table public.worker_heartbeats enable row level security;
revoke all on public.worker_heartbeats from public, anon, authenticated;
grant select on public.worker_heartbeats to authenticated;
drop policy if exists worker_heartbeat_own_read on public.worker_heartbeats;
create policy worker_heartbeat_own_read on public.worker_heartbeats
  for select to authenticated using (user_id = (select auth.uid()));

create or replace function public.publish_worker_heartbeat(worker_label text, worker_mode text, worker_state text)
returns void language plpgsql security definer set search_path = '' as $$
declare owner_id uuid := auth.uid();
begin
  if owner_id is null then
    raise exception 'Authentication required' using errcode = '42501';
  end if;
  -- Serialize label allocation per user. Remove expired rows so labels can be reused.
  perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended(owner_id::text, 0));
  delete from public.worker_heartbeats where user_id = owner_id and sampled_at < now() - interval '30 days';
  if not exists (select 1 from public.worker_heartbeats where user_id = owner_id and label = worker_label)
     and (select count(*) from public.worker_heartbeats where user_id = owner_id) >= 10 then
    raise exception 'Worker label limit reached';
  end if;
  insert into public.worker_heartbeats as heartbeat(user_id,label,mode,state)
  values (owner_id, worker_label, worker_mode, worker_state)
  on conflict (user_id,label) do update
    set mode = excluded.mode, state = excluded.state, sampled_at = now();
end;
$$;
revoke all on function public.publish_worker_heartbeat(text,text,text) from public, anon, authenticated;
grant execute on function public.publish_worker_heartbeat(text,text,text) to authenticated;

commit;
