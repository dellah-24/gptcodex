-- Apply in Supabase SQL Editor. This is an additive migration, not a user-broker credential store.
create extension if not exists pgcrypto;
create table if not exists public.market_contributions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  symbol text not null check (symbol in ('XAUUSD','BTCUSD')),
  timeframe text not null default 'M10' check (timeframe = 'M10'),
  bar_time bigint not null check (bar_time > 0 and bar_time % 600 = 0),
  open double precision not null check (open > 0),
  high double precision not null check (high > 0),
  low double precision not null check (low > 0),
  close double precision not null check (close > 0),
  tick_volume double precision not null check (tick_volume >= 0),
  created_at timestamptz not null default now(),
  unique(user_id,symbol,bar_time),
  check(high >= greatest(open, close, low) and low <= least(open, close))
);
create index if not exists market_contrib_scan on public.market_contributions(symbol,bar_time);
create table if not exists public.canonical_bars (
  symbol text not null check (symbol in ('XAUUSD','BTCUSD')),
  bar_time bigint not null check (bar_time > 0 and bar_time % 600 = 0),
  open double precision not null, high double precision not null,
  low double precision not null, close double precision not null,
  tick_volume double precision not null,
  contributors integer not null check(contributors >= 2),
  approved_at timestamptz not null default now(),
  primary key(symbol,bar_time)
);
create table if not exists public.shared_signals (
  id uuid primary key default gen_random_uuid(),
  symbol text not null check (symbol in ('XAUUSD','BTCUSD')),
  timeframe text not null default 'M10' check(timeframe='M10'),
  candle_time bigint not null check(candle_time > 0),
  direction text not null check(direction in ('buy','sell','flat')),
  model_version text not null,
  strategy_version text not null,
  confidence double precision not null check(confidence >= 0 and confidence <= 1),
  expires_at timestamptz not null,
  created_at timestamptz not null default now(),
  unique(symbol,timeframe,candle_time)
);
create index if not exists shared_signals_latest on public.shared_signals(symbol,candle_time desc);
create table if not exists public.shared_model_registry (
  id uuid primary key default gen_random_uuid(),
  symbol text not null check(symbol in ('XAUUSD','BTCUSD')),
  version text not null,
  artifact_sha256 text not null check(artifact_sha256 ~ '^[0-9a-f]{64}$'),
  metrics jsonb not null default '{}'::jsonb,
  status text not null default 'CANDIDATE' check(status in ('CANDIDATE','APPROVED','RETIRED')),
  approved_by uuid references auth.users(id),
  approved_at timestamptz,
  created_at timestamptz not null default now(),
  unique(symbol,version)
);
create unique index if not exists one_approved_model_per_symbol on public.shared_model_registry(symbol) where status = 'APPROVED';
-- RLS on every exposed table. No general users may write authoritative data.
alter table public.market_contributions enable row level security;
alter table public.canonical_bars enable row level security;
alter table public.shared_signals enable row level security;
alter table public.shared_model_registry enable row level security;
revoke all on public.market_contributions, public.canonical_bars, public.shared_signals, public.shared_model_registry from anon,authenticated;
grant select,insert on public.market_contributions to authenticated;
grant select on public.canonical_bars, public.shared_signals, public.shared_model_registry to authenticated;
create policy contribution_select_own on public.market_contributions for select to authenticated using (user_id = (select auth.uid()));
create policy contribution_insert_own on public.market_contributions for insert to authenticated with check (user_id = (select auth.uid()));
create policy canonical_read on public.canonical_bars for select to authenticated using (true);
create policy signals_read on public.shared_signals for select to authenticated using (true);
create policy models_read on public.shared_model_registry for select to authenticated using (true);
-- Security invariants: no update/delete grants to authenticated users; only trusted
-- server secret-key backend can create canonical bars/signals or approve models.
-- Use dedicated server authorization and audit approval, NOT browser service-role keys.

-- Opt-in, per-user normalized deal outcomes. Never store broker passwords/logins.
create table if not exists public.trade_outcomes (
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  signal_id uuid not null references public.shared_signals(id),
  local_deal_id text not null check(length(local_deal_id) between 1 and 128),
  symbol text not null check(symbol in ('XAUUSD','BTCUSD')),
  net_r_multiple double precision not null check(net_r_multiple between -100 and 100),
  closed_at timestamptz not null,
  created_at timestamptz not null default now(),
  primary key(user_id,local_deal_id)
);
alter table public.trade_outcomes enable row level security;
revoke all on public.trade_outcomes from anon,authenticated;
grant select,insert on public.trade_outcomes to authenticated;
create policy own_trade_outcomes_read on public.trade_outcomes for select to authenticated using(user_id=(select auth.uid()));
create policy own_trade_outcomes_insert on public.trade_outcomes for insert to authenticated with check(user_id=(select auth.uid()));

-- Atomic manually authorized shared model promotion. Only backend service-role
-- can invoke this RPC, and the caller must first verify local artifact SHA256.
create or replace function public.approve_shared_model(p_symbol text,p_version text,p_sha256 text)
returns void language plpgsql security definer set search_path = '' as $$
begin
  if current_user <> 'postgres' and auth.role() <> 'service_role' then
    raise exception 'Only trusted backend may approve';
  end if;
  if not exists (
    select 1 from public.shared_model_registry
    where symbol=p_symbol and version=p_version and artifact_sha256=p_sha256
      and status='CANDIDATE' and (metrics->>'passed')::boolean is true
  ) then raise exception 'Passing candidate not found'; end if;
  update public.shared_model_registry set status='RETIRED' where symbol=p_symbol and status='APPROVED';
  update public.shared_model_registry set status='APPROVED',approved_at=now()
    where symbol=p_symbol and version=p_version and artifact_sha256=p_sha256;
end;
$$;
revoke all on function public.approve_shared_model(text,text,text) from public,anon,authenticated;
grant execute on function public.approve_shared_model(text,text,text) to service_role;
