-- Apply AFTER 001_shared_learning.sql. No MT5 passwords or live order commands stored here.
create table if not exists public.approved_broker_servers (
  name text primary key check(length(name) between 5 and 100 and name ~* '^JustMarkets'),
  enabled boolean not null default true,
  created_at timestamptz not null default now()
);
create table if not exists public.user_broker_accounts (
  user_id uuid not null references auth.users(id) on delete cascade default auth.uid(),
  login text not null check(login ~ '^[0-9]{4,15}$'),
  server text not null references public.approved_broker_servers(name),
  label text not null default 'MT5 account' check(length(label) between 1 and 60),
  created_at timestamptz not null default now(),
  primary key (user_id,login)
);
create index if not exists broker_accounts_owner on public.user_broker_accounts(user_id);
-- Serialize concurrent account additions for each owner and enforce the two-account limit.
create or replace function public.enforce_two_accounts()
returns trigger language plpgsql set search_path = '' as $$
begin
  if new.user_id is null then raise exception 'Missing authenticated user'; end if;
  perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtext(new.user_id::text));
  if (select count(*) from public.user_broker_accounts where user_id=new.user_id) >= 2 then
    raise exception 'Maximum two broker accounts per user';
  end if;
  if not exists (select 1 from public.approved_broker_servers where name=new.server and enabled) then
    raise exception 'Broker server is not approved';
  end if;
  return new;
end;
$$;
drop trigger if exists limit_broker_accounts on public.user_broker_accounts;
create trigger limit_broker_accounts before insert on public.user_broker_accounts
for each row execute function public.enforce_two_accounts();
create table if not exists public.user_entitlements (
  user_id uuid primary key references auth.users(id) on delete cascade,
  plan text not null default 'FREE' check(plan in ('FREE','PRO')),
  active_until timestamptz,
  updated_at timestamptz not null default now()
);
-- Admin roles must be assigned by a trusted database administrator/service backend only.
create table if not exists public.tempest_admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);
alter table public.approved_broker_servers enable row level security;
alter table public.user_broker_accounts enable row level security;
alter table public.user_entitlements enable row level security;
alter table public.tempest_admins enable row level security;
revoke all on public.approved_broker_servers,public.user_broker_accounts,public.user_entitlements,public.tempest_admins from anon,authenticated;
grant select on public.approved_broker_servers to authenticated;
grant select,insert,delete on public.user_broker_accounts to authenticated;
grant select on public.user_entitlements,public.tempest_admins to authenticated;
create policy approved_servers_visible on public.approved_broker_servers for select to authenticated using(enabled);
create policy own_broker_accounts_read on public.user_broker_accounts for select to authenticated using(user_id=(select auth.uid()));
create policy own_broker_accounts_add on public.user_broker_accounts for insert to authenticated with check(user_id=(select auth.uid()));
create policy own_broker_accounts_delete on public.user_broker_accounts for delete to authenticated using(user_id=(select auth.uid()));
create policy own_entitlement_read on public.user_entitlements for select to authenticated using(user_id=(select auth.uid()));
create policy own_admin_status_read on public.tempest_admins for select to authenticated using(user_id=(select auth.uid()));
-- No UPDATE/INSERT/DELETE entitlements, server names or admin membership from untrusted clients.
-- Users' MT5 passwords are never uploaded to Supabase.
