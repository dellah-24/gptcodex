-- TempestBot multi-page website additions.
-- Apply AFTER 001_shared_learning.sql, 002_app_foundation.sql and 003_v14_hardening.sql.
-- Back up and verify on staging before applying to an existing production database.
-- Browser access remains guarded by Supabase Auth and Row Level Security (RLS).

-- Cloud-saved user preferences are informative only until the local MT5 worker
-- implements a verified, authenticated, explicit configuration synchronization.
create table if not exists public.user_risk_preferences (
  user_id uuid primary key default auth.uid() references auth.users(id) on delete cascade,
  risk_per_trade numeric(4,2) not null default 0.50 check (risk_per_trade between 0.10 and 2.00),
  daily_loss_limit numeric(4,2) not null default 2.00 check (daily_loss_limit between 0.50 and 5.00),
  max_positions smallint not null default 2 check (max_positions between 1 and 2),
  manage_positions boolean not null default true,
  updated_at timestamptz not null default now()
);
alter table public.user_risk_preferences enable row level security;
revoke all on public.user_risk_preferences from public, anon, authenticated;
grant select, insert, update on public.user_risk_preferences to authenticated;
drop policy if exists own_risk_read on public.user_risk_preferences;
create policy own_risk_read on public.user_risk_preferences
  for select to authenticated using (user_id = (select auth.uid()));
drop policy if exists own_risk_create on public.user_risk_preferences;
create policy own_risk_create on public.user_risk_preferences
  for insert to authenticated with check (user_id = (select auth.uid()));
drop policy if exists own_risk_update on public.user_risk_preferences;
create policy own_risk_update on public.user_risk_preferences
  for update to authenticated using (user_id = (select auth.uid()))
  with check (user_id = (select auth.uid()));

-- Check membership in the protected tempest_admins table without recursively
-- relying on caller-facing RLS. Never trust user-editable profile claims.
create or replace function public.tempest_is_admin()
returns boolean
language sql stable security definer set search_path = ''
as $$
  select exists (
    select 1 from public.tempest_admins a
    where a.user_id = (select auth.uid())
  );
$$;
revoke all on function public.tempest_is_admin() from public, anon, authenticated;
grant execute on function public.tempest_is_admin() to authenticated;

-- Admins can see disabled servers; ordinary authenticated users continue to see
-- enabled ones via the original approved_servers_visible policy.
grant insert, update on public.approved_broker_servers to authenticated;
drop policy if exists approved_servers_admin_read on public.approved_broker_servers;
create policy approved_servers_admin_read on public.approved_broker_servers
  for select to authenticated using ((select public.tempest_is_admin()));
drop policy if exists approved_servers_admin_insert on public.approved_broker_servers;
create policy approved_servers_admin_insert on public.approved_broker_servers
  for insert to authenticated with check ((select public.tempest_is_admin()) and name ~* '^JustMarkets');
drop policy if exists approved_servers_admin_update on public.approved_broker_servers;
create policy approved_servers_admin_update on public.approved_broker_servers
  for update to authenticated using ((select public.tempest_is_admin()))
  with check ((select public.tempest_is_admin()));
-- No browser grants to update user entitlements, publish shared signals,
-- approve shared models or run MT5 orders.

-- Read-only admin operational overview; all rows are aggregates.
create or replace function public.admin_overview()
returns table(total_users bigint, total_accounts bigint)
language plpgsql stable security definer set search_path = ''
as $$
begin
  if not (select public.tempest_is_admin()) then
    raise exception 'Administrator permission required' using errcode = '42501';
  end if;
  return query select
    (select count(*) from auth.users)::bigint,
    (select count(*) from public.user_broker_accounts)::bigint;
end;
$$;
revoke all on function public.admin_overview() from public, anon, authenticated;
grant execute on function public.admin_overview() to authenticated;

-- Masked user directory. Never expose full email, password hashes,
-- recovery tokens or MT5 credentials. Limited to the latest 100 users.
create or replace function public.admin_user_overview()
returns table(email_masked text, registered_at timestamptz,
              broker_accounts bigint, plan text, active_until timestamptz)
language plpgsql stable security definer set search_path = ''
as $$
begin
  if not (select public.tempest_is_admin()) then
    raise exception 'Administrator permission required' using errcode = '42501';
  end if;
  return query
    select
      case when u.email is null then '[email unavailable]'
      else left(split_part(u.email,'@',1),1) || '***@' || split_part(u.email,'@',2)
      end::text,
      u.created_at,
      (select count(*) from public.user_broker_accounts b where b.user_id=u.id)::bigint,
      coalesce(e.plan,'FREE')::text,
      e.active_until
    from auth.users u
    left join public.user_entitlements e on e.user_id=u.id
    order by u.created_at desc
    limit 100;
end;
$$;
revoke all on function public.admin_user_overview() from public, anon, authenticated;
grant execute on function public.admin_user_overview() to authenticated;

-- Audit actual role assignments and privileged configuration changes
-- separately with a trusted administrative backend when activated.
