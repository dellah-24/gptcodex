begin;
create table if not exists public.improvement_reviews (
 profile text primary key check(profile ~ '^[0-9a-f]{64}$'),
 report jsonb not null,
 demo jsonb not null default '[]',
 synced_at timestamptz not null default now(),
 synced_by uuid not null references auth.users(id),
 approved_at timestamptz,
 approved_by uuid references auth.users(id),
 approved_demo jsonb
);
alter table public.improvement_reviews enable row level security;
revoke all on public.improvement_reviews from public,anon,authenticated;
grant select on public.improvement_reviews to authenticated;
drop policy if exists improvement_admin_read on public.improvement_reviews;
create policy improvement_admin_read on public.improvement_reviews for select to authenticated
 using ((select public.tempest_is_admin()));

create or replace function public.sync_improvement_review(candidate_id text, report_text text, demo_log jsonb)
returns void language plpgsql security definer set search_path='' as $$
begin
 if not public.tempest_is_admin() then
   raise exception 'Administrator permission required' using errcode='42501';
 end if;
 if octet_length(report_text)>64000 or octet_length(demo_log::text)>64000
    or candidate_id is distinct from encode(sha256(convert_to(report_text,'UTF8')),'hex')
    or jsonb_typeof(demo_log) is distinct from 'array'
    or jsonb_typeof(report_text::jsonb) is distinct from 'object' then
   raise exception 'Invalid review evidence';
 end if;
 insert into public.improvement_reviews(profile,report,demo,synced_by)
 values(candidate_id,report_text::jsonb,demo_log,auth.uid())
 on conflict(profile) do update set demo=excluded.demo,synced_at=now(),synced_by=excluded.synced_by
 where public.improvement_reviews.demo is distinct from excluded.demo;
end;
$$;

create or replace function public.approve_improvement_profile(candidate_id text)
returns void language plpgsql security definer set search_path='' as $$
declare evidence jsonb;
begin
 if not public.tempest_is_admin() then
   raise exception 'Administrator permission required' using errcode='42501';
 end if;
 -- Lock the reviewed evidence so an uploader cannot change it mid-approval.
 select item into evidence
 from public.improvement_reviews r
 cross join lateral jsonb_array_elements(r.demo) item
 where r.profile=candidate_id
   and r.report->'qualified'='true'::jsonb
   and (r.report#>>'{candidate_holdout,trades}')::integer >= 20
   and (r.report#>>'{candidate_holdout,net_pnl}')::numeric > greatest(0,(r.report#>>'{baseline_holdout,net_pnl}')::numeric)
   and (r.report#>>'{candidate_holdout,max_drawdown_pct}')::numeric <= greatest(.1,(r.report#>>'{baseline_holdout,max_drawdown_pct}')::numeric)
   and item->>'mode'='demo'
   and (item->>'positions')::integer>=20 and (item->>'days')::integer>=2 and (item->>'net_pnl')::numeric>0
 order by item->>'account' limit 1 for update of r;
 if not found then
   raise exception 'A qualified holdout and positive demo evidence from one account are required';
 end if;
 update public.improvement_reviews set approved_at=now(),approved_by=auth.uid(),approved_demo=evidence
 where profile=candidate_id and approved_at is null;
end;
$$;

create or replace function public.improvement_profile_is_approved(candidate_id text)
returns boolean language sql stable security definer set search_path='' as $$
 select auth.uid() is not null and exists(
   select 1 from public.improvement_reviews where profile=candidate_id and approved_at is not null)
$$;

revoke all on function public.sync_improvement_review(text,text,jsonb) from public,anon,authenticated;
revoke all on function public.approve_improvement_profile(text) from public,anon,authenticated;
revoke all on function public.improvement_profile_is_approved(text) from public,anon,authenticated;
grant execute on function public.sync_improvement_review(text,text,jsonb) to authenticated;
grant execute on function public.approve_improvement_profile(text) to authenticated;
grant execute on function public.improvement_profile_is_approved(text) to authenticated;
commit;
