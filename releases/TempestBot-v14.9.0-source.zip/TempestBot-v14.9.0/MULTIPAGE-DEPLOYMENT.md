# TempestBot v14.1 — Multi-page web platform

## What changed
The original v14-layout/v0.8 frontend was one `web/index.html` with sections toggled by JavaScript. It is now a **real multi-page static website**: each route listed below owns a distinct HTML file and uses shared `web/styles.css`, `web/app.js`, and `web/js/client.js`. It retains the original Python trading engine and all existing migrations.

| URL | File | Purpose |
| --- | --- | --- |
| `/` | `web/index.html` | Public landing page |
| `/login/` | `web/login/index.html` | Supabase Auth sign-in and sign-up |
| `/overview/` | `web/overview/index.html` | Shared signals and account readiness |
| `/signals/` | `web/signals/index.html` | Latest and historical shared signals |
| `/trades/` | `web/trades/index.html` | Local execution information; intentionally no invented live positions |
| `/history/` | `web/history/index.html` | Your own normalized trade outcomes and CSV export |
| `/accounts/` | `web/accounts/index.html` | JustMarkets server/account metadata; max two |
| `/learning/` | `web/learning/index.html` | Approved and candidate shared model registry |
| `/strategy/` | `web/strategy/index.html` | Strategy reference and cloud risk preferences |
| `/subscription/` | `web/subscription/index.html` | Verified entitlement display, no payments |
| `/settings/` | `web/settings/index.html` | Current identity and app status |
| `/admin/` | `web/admin/index.html` | Restricted aggregate overview |
| `/admin/brokers/` | `web/admin/brokers/index.html` | Restricted allowlist configuration |
| `/admin/users/` | `web/admin/users/index.html` | Restricted masked user directory |

## Requirements and security
- Browser configuration in `web/config.js` contains **only the public Supabase URL and publishable key**. Never place MT5 account passwords, Supabase service-role keys, database passwords, Cloudflare OAuth tokens, or other privileged secrets in it.
- **Rotate/revoke the privileged tokens exposed in the user-supplied CREDENTIALS.txt before deploying.** No privileged tokens are included in this ZIP.
- The PWA is a dashboard only. MT5 live orders, user position tracking and AI SL/TP changes still happen within a separate Windows trading worker. The web app does not bridge to that worker yet.
- A central coordinator for model training and official signal publication still needs independent hosting and operation. Supabase tables do not train AI on their own.
- New risk preferences saved to Supabase are **not enforced by local MT5** until a future secure synchronization design is implemented and tested. Keep existing local risk limits.
- No new broker passwords or payment information are collected through the website.

## Supabase setup (staging first)
1. Back up your project/database and confirm whether migrations `001`, `002`, and `003` have previously been applied. Do not blindly rerun migrations that have already created policies.
2. For a fresh staging project, apply in order:
   - `supabase/001_shared_learning.sql`
   - `supabase/002_app_foundation.sql`
   - `supabase/003_v14_hardening.sql`
   - `supabase/004_multipage_platform.sql` **(new)**
3. For an existing upgraded v14 database, apply `004_multipage_platform.sql` after reviewing existing schema state. It is designed to be rerunnable for its policies and functions.
4. Configure Supabase Auth allowed Site URL and redirects for your HTTPS website. Enable email confirmation, rate limiting and any additional authorization safeguards required for your rollout.
5. Assign initial admin role **only through a trusted SQL Editor/backend session**. Never insert into `tempest_admins` from the website. Example, after verifying the intended person's account ID:

   ```sql
   insert into public.tempest_admins (user_id)
   select id from auth.users where email = 'YOUR_VERIFIED_ADMIN_EMAIL'
   on conflict do nothing;
   ```

6. Admins can manage `approved_broker_servers` using the browser, guarded by `tempest_is_admin` and RLS. Only add JustMarkets servers confirmed in MT5.
7. Test with at least two independent users: row isolation, third-account rejection, admin role denial, URL direct access, history records, stale signals and session expiry.

## Local test
From the project root:

```bash
python3 -m unittest discover -s tests -v
python3 -m unittest discover -s production_tests -v
node --check web/app.js
node --check web/js/client.js
python3 -m http.server 8080 --directory web
```

Browse `http://localhost:8080/` for the public landing page. Secure pages redirect to `/login/` unless authenticated. Some Supabase redirect settings may require adding `http://localhost:8080` for development. Do not add unrestricted redirects to production.

## Cloudflare Pages deploy
1. Install Node.js and authenticate locally using a **fresh** `npx wrangler login`, rather than reusing the supplied expired/exposed OAuth token.
2. Run `npm install && npm run check`.
3. Run `npm run deploy:web`; only `web/` is published to the existing `tempestbot` Pages project.
4. Validate each direct path above, including browser refresh at that path, after publishing. Confirm the domain `https://bot.tempesttechnologies.co.zw` points to the intended Pages project.
5. Test Supabase sign-up/sign-in, admin RLS checks, content security policy, logout, and expiry handling. Use a staging Supabase project first.

## Known production blockers
- The PWA cannot control or even inspect live MT5 positions until a local-agent bridge with user/session binding, credentials isolation and end-to-end testing exists.
- No production subscription payment processing or credit ledger is connected.
- The central learner/model-promotion path is not independently validated with actual trading data.
- No real JustMarkets multi-account execution, broker reconciliation, failure/restart or performance soak tests have been completed in this environment.
- Model scores are not evidence of profitability. An approval workflow needs independent risk/performance validation and ongoing monitoring.

**Do not enable unattended live-money trading based solely on these website and unit tests.**
