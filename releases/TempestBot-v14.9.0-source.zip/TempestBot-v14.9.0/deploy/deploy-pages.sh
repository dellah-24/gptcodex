#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
echo "TempestBot multi-page website deployment"
echo "This replaces the website files in the existing Cloudflare Pages project: tempestbot."
echo "It does NOT migrate or erase the Supabase database, deploy Cloudflare Workers, or start MT5."
python3 -m unittest discover -s production_tests -q
node --check web/app.js
node --check web/js/client.js
if [ -f CREDENTIALS.txt ] || [ -f web/.env ]; then
  echo "Private credential file detected; remove it from deploy folder before proceeding." >&2
  exit 1
fi
if ! command -v npx >/dev/null 2>&1; then echo "Install Node.js and npm first." >&2; exit 1; fi
echo "Use a freshly authenticated Cloudflare session (npx wrangler login if necessary)."
# Never deploy the Python worker or project credentials to the static site.
npx wrangler pages deploy web --project-name tempestbot
