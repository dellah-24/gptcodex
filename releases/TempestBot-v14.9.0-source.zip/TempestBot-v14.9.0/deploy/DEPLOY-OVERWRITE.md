# TempestBot — overwrite the existing site without erasing user data

This release is prepared for Cloudflare Pages project `tempestbot`, intended domain `https://bot.tempesttechnologies.co.zw`.

**Deployment has not been executed by ChatGPT.** Production Cloudflare and Supabase access must be established separately. Existing data, memberships, payments, and MT5 account state must be preserved.

## Critical preflight
1. Rotate the previously exposed Supabase service-role and project-management tokens and Cloudflare OAuth/refresh tokens. The ZIP intentionally excludes them. Use a fresh Cloudflare login or appropriately scoped API token on the deploying machine.
2. Back up the existing Supabase project database and record the current Cloudflare Pages production deployment ID for rollback.
3. Check if the existing Pages project is Direct Upload or Git-integrated. If Git-integrated, commit changes to the configured deployment branch rather than dragging the web ZIP into Pages.
4. Confirm the site is served from the existing Pages project `tempestbot`, production branch, and correct custom domain. Do not create a separate unintended project.
5. Test new site first on a Pages preview branch when possible.

## Replace website on Cloudflare

From project root, with Node.js and Cloudflare authentication available:

```bash
npm install
npm run check
bash deploy/deploy-pages.sh
```

Or use `TempestBot-v14.1-web-only.zip` in the Cloudflare Pages Direct Upload drag-and-drop interface. If using Wrangler, deploy the **web directory**, not a ZIP:

```bash
npx wrangler pages deploy web --project-name tempestbot
```

Check direct refresh for `/login/`, `/overview/`, `/signals/`, `/history/`, `/accounts/`, `/learning/`, `/strategy/`, `/subscription/`, `/settings/`, `/admin/`, `/admin/brokers/`, and `/admin/users/`.

## Existing Supabase database

**Never delete existing tables or rerun migrations blindly.** Review the existing schema and migration history first, and test on a backup or staging clone. Preserve preexisting rows.

- `supabase/001_shared_learning.sql`, `002_app_foundation.sql`, `003_v14_hardening.sql`: prerequisites for a fresh database only. Check whether already applied.
- `supabase/004_multipage_platform.sql`: new additive schema/permissions for this frontend. Review policies/functions for conflicts and apply to a staging project before production.
- If the existing database was managed by Supabase CLI migration history, register and apply changes through that workflow rather than making untracked SQL changes.
- After migration, test Auth redirects, admin permissions, maximum two JustMarkets accounts, user isolation, signals and history reads.

This folder deliberately does not contain service-role keys or SQL deployment passwords. The public Supabase publishable key in `web/config.js` is not a privileged credential.

## Rollback

Cloudflare: select the last verified Pages production deployment in the project and roll it back using Cloudflare dashboard deployment controls. Do not attempt to revert database migration through destructive DROP commands; use a reviewed compatibility migration if necessary.

## Scope and limitations
- PWA is only a web dashboard. Local Windows MT5 worker runs separately. Website replacement does **not** deploy worker agents, grant broker permissions, or start live orders.
- No direct PWA-to-local-MT5 bridge or proven production billing gateway exists in this version.
- Browser admin role checks are backed by Supabase RLS, but these still require staging security tests.
- Do not enable unattended live-money execution without broker demo/soak testing and order reconciliation validation.
