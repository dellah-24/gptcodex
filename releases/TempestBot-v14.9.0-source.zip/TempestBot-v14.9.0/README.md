> For demo session logging and admin approval, see [admin learning review](ADMIN-LEARNING-REVIEW.md).

> For recurring scalping evaluation and profile promotion, see [continuous improvement](CONTINUOUS-IMPROVEMENT.md).

> For entry styles and the ICT/SMC distinction, see [scalping entries](SCALP-ENTRY.md).

> For mobile telemetry, fast-market filters and tick replay, see [scalping operations](SCALPING-OPERATIONS.md).

> For the lower-timeframe strategy, see [multi-timeframe scalping](SCALPING.md).

> For signal-driven position exits and re-entry, see [reversal trading](REVERSAL-TRADING.md).

> For this production candidate, see the [v14.3 upgrade guide](V14.3-UPGRADE.md) and [production runbook](PRODUCTION-RUNBOOK.md).

# TempestBot v14.1 — Multi-page PWA + local MT5 worker

This package extends the v14 deployment-layout snapshot (derived from TempestBot v0.8) into a **multi-page installable website**. It contains all original Python engine modules and models, `worker/`, `supabase/` migrations 001–004 and the rewritten `web/` frontend.

**Important:** This package is built from the available v14-layout archive, **not** a separately verified upstream v14 release. See [MULTIPAGE-DEPLOYMENT.md](MULTIPAGE-DEPLOYMENT.md) for page routes, setup, deployment, security, and production limitations.

- Static web application: `web/`
- Supabase migrations: `supabase/001_shared_learning.sql` through `004_multipage_platform.sql`
- Local execution worker: `worker/` and `tempestbot/`
- Model assets and legacy trading scripts: `legacy/`

Run `npm run check` (requires Node.js, Python) or `python3 -m unittest discover -s production_tests -v` to validate the deployment foundation.

**Broker execution remains local to the user's running PC. The website does not place orders.** Live-money deployment is not validated.
