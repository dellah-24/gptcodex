# TempestBot production candidate

For v14.3 strategy replay, risk controls and worker monitoring, see [the upgrade guide](V14.3-UPGRADE.md).

The mobile dashboard is a web app. The Windows worker sends orders through the JustMarkets MT5 terminal. The dashboard shows published signals and voluntarily synced trade history. Broker orders, account credentials, and execution controls stay on the Windows host.

## Install and verify

Use 64-bit Python 3.12 on a dedicated Windows PC or VPS with the JustMarkets MT5 terminal. Run one order-enabled worker per account and use a dedicated MT5 terminal instance for each account. Keep Windows and the worker clock synchronized. Use a dedicated Windows user whose profile and journal are retained across restarts.

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-worker.txt
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
npm run check
```

Start with the exact demo server and symbol shown in MT5. The example login, server and symbol below are placeholders.

```powershell
.\.venv\Scripts\python.exe -m worker.main --login 123456 --server JustMarkets-Demo --symbol XAUUSDm --once
.\.venv\Scripts\python.exe -m worker.main --login 123456 --server JustMarkets-Demo --symbol XAUUSDm --mode demo --enable-demo
```

The worker prompts for the password by default. For unattended startup, supply the password as a process environment variable through the host's secret store. Start under the same Windows user and terminal session used during demo validation. Capture stdout and stderr in an operator-owned log with rotation. Use the existing local-only mode for private operation or the existing `--shared-feed` option with an authenticated Supabase user JWT. Verify the central publisher independently and plan for token renewal before using shared signals for unattended operation.

## Deploy the dashboard

On your authorized staging project, apply `supabase/001` through `005` in order using the full filenames. Set the public Supabase URL and publishable key in `web/config.js`. Update the allowed Supabase origin in `web/_headers` to match. Configure Supabase Auth site and redirect URLs for the HTTPS dashboard. Publish the `web/` directory to your authorized Cloudflare Pages project, then verify login, two-user data isolation, the admin role, signal expiration, and the mobile menu. With HTTPS active, use the browser's install or Add to Home Screen option where supported.

## Broker acceptance and live activation

Use a demo session to check both configured symbols during market hours. Confirm the returned ticket, actual entry, volume, stop, target and deal history in MT5. Confirm the worker blocks stale candles, existing positions and pending orders, and verify behavior through terminal disconnects, process restarts, and rejected orders. Verify protection changes if you intend to enable `--manage-positions`. Validate the strategy on unseen data and in demo with broker costs and slippage before exposing capital. The bundled model scores classify which modeled barrier is hit first and have no demonstrated live profitability in this package.

Once those checks pass on your host, explicitly set `TEMPESTBOT_LIVE_ENABLED=YES` in the worker environment and use `--mode live --enable-live --ack-live LIVE-<login>` with the verified real-account login and exact server. The worker checks the MT5 account type separately. Its daily equity baseline starts from the first recorded equity on the UTC day, and actual losses can exceed the modeled stop loss due to fills, gaps, or fees.

## Pause and reconcile

Create an empty `PAUSE_TRADING` file beside `%USERPROFILE%\.tempestbot\execution.sqlite3` to block subsequent worker order and protection requests. This leaves broker-side orders and existing stops in place. A send already in progress may complete. Use MT5 to inspect positions and outstanding orders. Preserve the execution database and its WAL files.

An ambiguous order or protection change blocks subsequent broker requests for that account. Stop the worker, list the outstanding journal entries, compare them with MT5 orders, deals, positions and journal, and record the outcome using the exact key printed by the journal tool.

```powershell
.\.venv\Scripts\python.exe -m worker.reconcile --login 123456
.\.venv\Scripts\python.exe -m worker.reconcile --login 123456 --resolve orders "<key>" --note "Verified broker order and deal IDs and current exposure"
```

Use `modifications` as the table for stop or target changes. Acknowledging the entry preserves the original attempt and prevents it from being sent again. Investigate any unexpected exposure before removing the pause file and restarting. Keep a timestamped backup using SQLite's backup facility or copy the database and companion files after stopping all writers.

## Release verification

The included checks cover fake MT5 execution, scanning synthetic candles with the bundled models, and static web checks. No Windows terminal, JustMarkets account, or deployed Supabase project was used to certify this build. Production acceptance on the target host remains required.
