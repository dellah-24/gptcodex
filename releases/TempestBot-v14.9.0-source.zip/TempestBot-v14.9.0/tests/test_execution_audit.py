import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace as NS

from tempestbot.live import MAGIC, ExecutionBlocked, ExecutionJournal, execute_order
from tempestbot.reconciliation import audit_account
from tempestbot.runner import Heartbeat
from tempestbot.shared import SharedError
from test_live import FakeMT5


class ExecutionAuditTests(unittest.TestCase):
    def setUp(self):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.path = Path(directory.name) / 'journal.sqlite3'
        self.journal = ExecutionJournal(self.path)
        self.addCleanup(self.journal.db.close)
        self.broker = FakeMT5()
        self.login, self.server = self.broker.acc.login, self.broker.acc.server
        self.order = dict(login=self.login, server=self.server, approved_servers=[self.server],
                          symbol='XAUUSDm', side='buy', sl=98, tp=104, candle_time=123,
                          journal=self.journal, live_enabled=True)

    def test_loss_halt_persists_after_equity_recovers_and_database_reopens(self):
        self.journal.sample_daily_equity(self.login, 10000, 2)
        _, halted = self.journal.sample_daily_equity(self.login, 9800, 2)
        self.assertTrue(halted)
        reopened = ExecutionJournal(self.path)
        self.addCleanup(reopened.db.close)
        with self.assertRaisesRegex(ExecutionBlocked, 'latched'):
            execute_order(self.broker, **{**self.order, 'journal': reopened})
        self.assertEqual(self.broker.calls, 0)

    def test_other_symbol_uses_remaining_stop_budget(self):
        self.broker.positions = [NS(symbol='BTCUSDm', type=0, volume=1, sl=98.2)]
        receipt = execute_order(self.broker, **self.order)
        # Existing stop risk is 180 of 200; adverse deviation-adjusted new risk stays <=20.
        self.assertLessEqual(receipt['volume'] * 225, 20)
        self.assertGreater(receipt['volume'], 0)

    def test_unprotected_external_position_blocks_new_exposure(self):
        self.broker.positions = [NS(symbol='BTCUSDm', type=0, volume=1, sl=0)]
        with self.assertRaisesRegex(ExecutionBlocked, 'protective stop'):
            execute_order(self.broker, **self.order)
        self.assertEqual(self.broker.calls, 0)

    def test_pending_other_symbol_contributes_to_cap(self):
        self.broker.orders_get = lambda: [
            NS(symbol='BTCUSDm', type=2, price_open=100, volume_current=2, sl=98)]
        with self.assertRaisesRegex(ExecutionBlocked, 'stop-risk cap'):
            execute_order(self.broker, **self.order)
        self.assertEqual(self.broker.calls, 0)

    def test_uncertain_submission_uses_tag_and_confirms_terminal_partial_fill(self):
        request = {}
        def lose_receipt(order):
            request.update(order)
            return None
        self.broker.order_send = lose_receipt
        with self.assertRaises(ExecutionBlocked):
            execute_order(self.broker, **self.order)
        order = NS(ticket=81, magic=MAGIC, symbol=request['symbol'], comment=request['comment'],
                   state=2, volume_initial=request['volume'], volume_current=request['volume'] - .01)
        deal = NS(ticket=82, order=order.ticket, entry=0, type=0, magic=MAGIC,
                  symbol=order.symbol, position_id=83, volume=.01)
        position = NS(ticket=84, identifier=83, magic=MAGIC, symbol=order.symbol, sl=98., tp=104.)
        self.broker.positions = [position]
        self.broker.history_orders_get = lambda *a, **kw: [order]
        self.broker.history_deals_get = lambda **kw: [deal]
        self.broker.orders_get = lambda: [order]
        self.assertTrue(audit_account(self.broker, self.journal, self.login, self.server))
        with self.assertRaises(ExecutionBlocked):
            self.journal.require_reconciled(self.login)
        self.broker.orders_get = lambda: []
        self.assertEqual(audit_account(self.broker, self.journal, self.login, self.server), [])
        self.assertEqual(self.journal.history()[0]['status'], 'PARTIAL_SETTLED')
        self.journal.require_reconciled(self.login)

    def test_legacy_or_unmatched_position_surfaces_in_audit(self):
        self.broker.positions = [NS(ticket=50, magic=MAGIC, symbol='XAUUSDm', sl=0, tp=0)]
        self.broker.history_deals_get = lambda **kw: []
        issues = audit_account(self.broker, self.journal, self.login, self.server)
        self.assertTrue(any('protection' in item for item in issues))
        self.assertTrue(any('matching local journal' in item for item in issues))

    def test_heartbeat_error_does_not_stop_worker_and_payload_is_minimal(self):
        calls = []
        def rpc(function, payload):
            calls.append((function, payload))
            raise SharedError('test unavailable')
        heartbeat = Heartbeat(NS(rpc=rpc), 'Demo VPS', 'demo')
        with self.assertLogs('tempestbot.worker', level='WARNING'):
            heartbeat.publish('online')
            heartbeat.publish('online')
        self.assertEqual(calls, [('publish_worker_heartbeat',
                                 {'worker_label': 'Demo VPS', 'worker_mode': 'demo', 'worker_state': 'online'})])
