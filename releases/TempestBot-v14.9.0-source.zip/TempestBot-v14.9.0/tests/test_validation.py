import csv
import importlib.util
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from tempestbot.core import RiskConfig
from tempestbot.validation import Costs, close_trade, replay_fold, validate


class ReplayTests(unittest.TestCase):
    def test_gap_and_stop_win_over_target_on_same_bar(self):
        costs = Costs(.01, 1, 0, 0, 0)
        candles = [{'open': 95., 'low': 94., 'high': 107., 'close': 104., 'spread': 10}]
        self.assertEqual(close_trade(candles, 0, 1, 'buy', 97, 105, costs), (0, 95, 'stop'))
        self.assertEqual(close_trade(candles, 0, 1, 'sell', 105, 96, costs), (0, 105, 'stop'))

    def test_replay_charges_spread_slippage_commission_and_swap(self):
        rows = [
            {'time': 84600, 'open': 100, 'low': 99, 'high': 102, 'close': 101, 'spread': 10},
            {'time': 85200, 'open': 101, 'low': 101, 'high': 102, 'close': 101, 'spread': 10},
            {'time': 85800, 'open': 101, 'low': 101, 'high': 102, 'close': 101, 'spread': 10},
            {'time': 86400, 'open': 101, 'low': 101, 'high': 102, 'close': 102, 'spread': 10},
        ]
        frame = unittest.mock.MagicMock()
        with patch('tempestbot.validation.smc_ict_confirm', return_value={'confirmed': True}), patch(
            'tempestbot.validation.candle_decision', return_value=('buy', .8, .2, {'confirmed': True}, 1)
        ):
            trades, blocked = replay_fold(rows, frame, 'XAUUSD', 0, len(rows),
                                          Costs(.01, 2, 4, 1, 1), .62, 10000, RiskConfig())
        self.assertEqual(blocked, 0)
        self.assertEqual(len(trades), 1)
        trade = trades[0]
        # Buy entry uses the ask plus adverse slippage, and the final bid is slipped on exit.
        volume = 50 / 1.77
        commission = volume * (101.12 + 101.98) * .0004
        swap = volume * 101.12 * .0001
        self.assertEqual(trade['entry_time'], 85200)
        self.assertAlmostEqual(trade['net_pnl'], (101.98 - 101.12) * volume - commission - swap)

    @unittest.skipUnless(all(importlib.util.find_spec(name) for name in
                             ('numpy', 'pandas', 'ta', 'lightgbm', 'joblib')),
                         'worker model dependencies are required')
    def test_live_features_have_no_lookahead_on_synthetic_history(self):
        import numpy as np

        rng = np.random.default_rng(193)
        size = 640
        mid = 2300 + rng.normal(0, 1, size).cumsum()
        opening = np.r_[mid[0], mid[:-1]]
        high = np.maximum(mid, opening) + rng.uniform(.1, 2, size)
        low = np.minimum(mid, opening) - rng.uniform(.1, 2, size)
        stamps = 1_740_000_000 + np.arange(size) * 600
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'bars.csv'
            with path.open('w', newline='') as file:
                writer = csv.writer(file)
                writer.writerow(['time', 'open', 'high', 'low', 'close', 'tick_volume', 'spread'])
                writer.writerows(zip(stamps, opening, high, low, mid,
                                     rng.integers(100, 1500, size), rng.integers(10, 100, size)))
            for symbol in ('XAUUSD', 'BTCUSD'):
                with self.subTest(symbol=symbol):
                    report = validate(path, symbol, int(stamps[600]), Costs(.01, 1, 1, 2, 2), fold_bars=40)
                    self.assertEqual(report['symbol'], symbol)
                    self.assertEqual(report['folds'][0]['first_bar'], stamps[600])
                    self.assertEqual(report['folds'][0]['lookahead_samples'], 3)
                    self.assertFalse(report['training_overlap_independently_verified'])
