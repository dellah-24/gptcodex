from contextlib import closing
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace as Row
import unittest
from unittest.mock import patch

from tempestbot.improve import approve, connect, evaluate, load_profile, observe, MIN_TRADES, demo_session, end_demo_session, sync_review
from tempestbot.live import ExecutionJournal, MAGIC
from tempestbot.validation import Costs


class ImprovementTests(unittest.TestCase):
    def setUp(self):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.root = Path(directory.name)
        self.db = connect(self.root/'improvement.sqlite3')
        self.addCleanup(self.db.close)

    def candidate(self):
        with self.db:
            self.db.execute("INSERT INTO evaluations VALUES('candidate','XAUUSD',1,2,'{}',1,NULL)")

    def test_demo_gate_uses_one_account_and_excludes_live_results(self):
        self.candidate()
        with self.assertRaises(ValueError):
            load_profile(self.db,'candidate','live')
        with self.db:
            self.db.executemany('INSERT INTO observed_positions VALUES(?,?,?,?,?,?,?)',
                                [('candidate','live',30,'demo',str(i),86400*(1+i%2),5) for i in range(MIN_TRADES)])
        with self.assertRaises(ValueError):
            approve(self.db,'candidate',30,'demo')
        with self.db:
            self.db.executemany('INSERT INTO observed_positions VALUES(?,?,?,?,?,?,?)',
                                [('candidate','demo',30,'demo',str(i),86400*(1+i%2),5) for i in range(MIN_TRADES)])
        self.assertEqual(approve(self.db,'candidate',30,'demo')['demo_positions'],MIN_TRADES)
        self.assertEqual(load_profile(self.db,'candidate','live'),{})

    def test_observes_full_position_once_including_entry_commission(self):
        with closing(ExecutionJournal(self.root/'execution.sqlite3').db) as db:
            journal = Row(db=db)
            with db:
                db.execute("INSERT INTO orders(key,account,symbol,status,data) VALUES(?,?,?,?,?)",
                           ('30:demo:xauusd:700',30,'XAUUSD','FILLED',json.dumps(
                               {'request':{'improvement_profile':'candidate','improvement_mode':'demo'},
                                'result':{'order':19}})))
            buy = Row(entry=0,magic=MAGIC,position_id=7,order=19,profit=0,commission=-1,swap=0,fee=0,volume=.1,time=700)
            sell = Row(entry=1,magic=MAGIC,position_id=7,order=20,profit=8,commission=-1,swap=-1,fee=0,volume=.1,time=800)
            broker = Row(positions_get=lambda:[],history_deals_get=lambda **_: [buy,sell])
            for mode in ('live','demo','demo'):
                observe(self.db,journal,broker,'candidate',mode,30,'demo',[sell])
            self.assertEqual(self.db.execute('SELECT mode,pnl FROM observed_positions').fetchall(),[('demo',5)])

    def test_review_sync_masks_login_and_keeps_demo_sessions_separate_from_live(self):
        self.candidate()
        session = demo_session(self.db,'candidate',98761234,'JustMarkets-Demo')
        end_demo_session(self.db,session)
        with self.db:
            self.db.executemany('INSERT INTO observed_positions VALUES(?,?,?,?,?,?,?)',[
                ('candidate','demo',98761234,'justmarkets-demo','1',86400,5),
                ('candidate','live',98761234,'justmarkets-demo','2',86400,500),
            ])
        submitted=[]
        sync_review(self.db,Row(rpc=lambda name,payload: submitted.append((name,payload))),'candidate')
        name,payload=submitted[0]
        self.assertEqual(name,'sync_improvement_review')
        evidence=payload['demo_log'][0]
        self.assertEqual((evidence['account'],evidence['positions'],evidence['net_pnl']),('••••1234',1,5))
        self.assertTrue(evidence['sessions'][0]['end'])
        self.assertNotIn('98761234',json.dumps(payload))

    def test_selects_only_on_tuning_and_does_not_reuse_holdout(self):
        path=self.root/'ticks.csv'
        first,cutoff,end = 1_700_000_000,1_700_400_000,1_700_500_000
        path.write_text('time,bid,ask\n'+''.join(f'{stamp},10,11\n' for stamp in (first,cutoff,end)))
        scored=[]
        def fake_replay(ticks,symbol,costs,*,evaluate_from,entry_style,**_):
            captured=list(ticks)
            if evaluate_from is None:
                self.assertTrue(all(tick[0]<cutoff for tick in captured))
            scored.append((entry_style,evaluate_from))
            net={'breakout':1,'distance':4,'retest':8}[entry_style]
            return {'performance':dict(trades=25,net_pnl=net,max_drawdown_pct=.08)}
        with patch('tempestbot.improve.replay',side_effect=fake_replay):
            result=evaluate(self.db,path,'XAUUSD',Costs(.01,0,0,0,0),initial_cutoff=cutoff)
            self.assertIsNone(evaluate(self.db,path,'XAUUSD',Costs(.01,0,0,0,0)))
            self.assertEqual([style for style, date in scored if date],['breakout','retest'])
            self.assertTrue(result['qualified'])
        path.write_text(path.read_text().replace(',10,11',',9,11'))
        with self.assertRaisesRegex(ValueError,'Append'):
            evaluate(self.db,path,'XAUUSD',Costs(.01,0,0,0,0))
