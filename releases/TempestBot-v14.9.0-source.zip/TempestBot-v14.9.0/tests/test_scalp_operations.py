from pathlib import Path
from queue import Queue
import tempfile
from types import SimpleNamespace
import unittest

from tempestbot.fast_market import entry_filter, parse_session
from tempestbot.live import ExecutionJournal
from tempestbot.scalp_replay import replay
from tempestbot.telemetry import Telemetry
from tempestbot.validation import Costs


class ScalpOperationsTests(unittest.TestCase):
    def test_clock_spread_and_cooldown_filters(self):
        settings = dict(sessions=[parse_session('22:00-02:00')], spread=.1, point=.01,
                        spread_cap=10, last_exit=None, cooldown=30)
        self.assertIsNone(entry_filter(3600, **settings))
        self.assertIn('UTC', entry_filter(3*3600, **settings))
        self.assertIn('Spread', entry_filter(3600, **{**settings,'spread':.11}))
        self.assertIn('20s', entry_filter(3600, **{**settings,'last_exit':3590}))

    def test_replay_executes_production_signal_from_aggregated_ticks(self):
        origin = 1_800_000_000
        ticks = ((origin+i*60+offset, 2000+i*.5+offset*.009, 2000+i*.5+offset*.009+.005)
                 for i in range(6100) for offset in (0, 50))
        report = replay(ticks, 'XAUUSD', Costs(.001,.1,0,0,0),spread_cap=6)
        self.assertGreater(report['performance']['trades'],0)
        self.assertTrue(all(t['holding_seconds'] >= 0 and t['spread_points'] < 6 for t in report['trades']))

    def test_journal_telemetry_has_reserved_and_filled_with_private_account_scope(self):
        with tempfile.TemporaryDirectory() as directory:
            journal = ExecutionJournal(Path(directory)/'orders.sqlite3')
            self.addCleanup(journal.db.close)
            journal.reserve('1:demo:xauusdm:1000',1,'XAUUSDm',{'volume':.01})
            journal.finish('1:demo:xauusdm:1000','FILLED',{'volume':.01})
            journal.reserve('2:demo:xauusdm:1000',2,'XAUUSDm',{'volume':.02})
            telemetry = Telemetry.__new__(Telemetry)
            telemetry.queue = Queue(maxsize=1)
            telemetry.last = float('-inf')
            broker = SimpleNamespace(account_info=lambda: SimpleNamespace(login=1,server='demo',currency='USD'),
                                     positions_get=lambda: [])
            telemetry.sample(broker,journal,1,'demo','demo','online',{})
            snapshot = telemetry.queue.get_nowait()
            self.assertEqual([event['status'] for event in snapshot['events']], ['FILLED','RESERVED'])
            self.assertEqual(snapshot['positions'],[])
