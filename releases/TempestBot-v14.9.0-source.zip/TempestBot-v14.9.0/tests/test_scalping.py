import unittest
from types import SimpleNamespace
from unittest.mock import patch

from tempestbot.live import ExecutionBlocked
from tempestbot.reversal import reversal_streak
from tempestbot.runner import main
from tempestbot.scalping import TIMEFRAMES, scalp_signal


class ScalpingTests(unittest.TestCase):
    now = 1_800_000_015

    def make_broker(self, *, bearish_frame=None, missing_frame=None):
        frames = {}
        for name, seconds in TIMEFRAMES:
            last = (self.now // seconds - 1) * seconds
            direction = -1 if name == bearish_frame else 1
            frames[name] = [
                dict(time=last + (i - 99) * seconds, open=1000+direction*i,
                     high=1000+direction*i+.9, low=1000+direction*i-.9,
                     close=1000+direction*i+direction*.5)
                for i in range(101)
            ]
            if name == missing_frame:
                frames[name].pop(98)
        def rates(symbol, timeframe, offset, size):
            self.assertEqual((offset, size), (1, 101))
            return frames[timeframe]
        return SimpleNamespace(copy_rates_from_pos=rates, **{'TIMEFRAME_'+name:name for name,_ in TIMEFRAMES})

    def test_alignment_and_open_candles_are_excluded(self):
        signal = scalp_signal(self.make_broker(), 'XAUUSD', now=self.now)
        self.assertEqual(signal['side'], 'buy')
        self.assertEqual(signal['candle_time'], 1_799_999_940)
        self.assertEqual(signal['context'], {'M5':'buy','M15':'buy','H1':'buy'})
        self.assertGreater(signal['atr'], 0)

    def test_higher_timeframe_disagreement_vetoes_trigger(self):
        signal = scalp_signal(self.make_broker(bearish_frame='H1'), 'XAUUSD', now=self.now)
        self.assertEqual(signal['trigger'], 'buy')
        self.assertIsNone(signal['side'])

    def test_recent_timeframe_gap_blocks_analysis(self):
        with self.assertRaisesRegex(ExecutionBlocked, 'M5 history'):
            scalp_signal(self.make_broker(missing_frame='M5'), 'XAUUSD', now=self.now)

    def test_reversal_streak_uses_minute_boundaries(self):
        first = reversal_streak(None, candle=60, side='sell', confidence=1, threshold=.7, candle_seconds=60)
        result = reversal_streak(first, candle=120, side='sell', confidence=1, threshold=.7, candle_seconds=60)
        self.assertEqual(result[2], 2)

    def test_defaults_preserve_existing_live_and_shared_commands(self):
        args = ['--login','123456','--server','JustMarkets-Demo','--symbol','XAUUSDm']
        for extra, strategy, poll in [([], 'scalp', 5), (['--mode','live'], 'm10', 30), (['--shared-feed'], 'm10', 30),
                                      (['--mode','live','--strategy','scalp'], 'scalp', 5)]:
            with self.subTest(extra=extra), patch('tempestbot.runner.run_worker') as run:
                main(args+extra)
                settings = run.call_args.args[0]
                self.assertEqual((settings.strategy, settings.poll), (strategy,poll))
