import tempfile
import time
import unittest
from pathlib import Path
from types import SimpleNamespace as NS
from tempestbot.live import ExecutionBlocked, ExecutionJournal, MAGIC
from tempestbot.management import ManagementConfig, manage_positions, propose
from test_live import FakeMT5

class ManagedFake(FakeMT5):
    TRADE_ACTION_SLTP=6
    def __init__(self):
        super().__init__()
        self.position=NS(ticket=77,magic=MAGIC,symbol='XAUUSDm',type=0,sl=95.,tp=115.,price_open=100.)
        self.tick=NS(bid=105.,ask=105.1,time=time.time())
        self.sent=[]
    def positions_get(self,*,symbol=None,ticket=None):
        if ticket is not None:
            return [self.position] if self.position.ticket==ticket else []
        return [self.position] if self.position.symbol==symbol else []
    def order_send(self,request):
        self.sent.append(request)
        self.position.sl=request['sl']
        self.position.tp=request['tp']
        return NS(retcode=self.TRADE_RETCODE_DONE)

class ManagementTests(unittest.TestCase):
    def setUp(self):
        self.t=tempfile.TemporaryDirectory();self.addCleanup(self.t.cleanup)
        self.j=ExecutionJournal(Path(self.t.name)/'journal.db');self.addCleanup(self.j.db.close)
        self.mt5=ManagedFake()
        self.kw=dict(login=123456,server='JustMarkets-Demo',approved_servers=['JustMarkets-Demo'],
                     symbol='XAUUSDm',direction='buy',confidence=.81,atr=2.,candle_time=1001,
                     journal=self.j,live_enabled=True)
    def test_trail_only_tightens(self):
        result=manage_positions(self.mt5,**self.kw)
        self.assertEqual(len(result),1)
        self.assertGreater(self.mt5.position.sl,95)
        self.assertEqual(self.mt5.position.tp,115)
        self.assertEqual(self.mt5.sent[0]['action'],self.mt5.TRADE_ACTION_SLTP)
    def test_reversal_tightens_both(self):
        args=dict(self.kw,direction='sell')
        result=manage_positions(self.mt5,**args)
        self.assertEqual(len(result),1)
        self.assertGreater(self.mt5.position.sl,95)
        self.assertLess(self.mt5.position.tp,115)
    def test_no_repeated_modification_same_candle(self):
        manage_positions(self.mt5,**self.kw)
        # Artificially move price higher, so another action would be proposed.
        self.mt5.tick.bid=107.;self.mt5.tick.ask=107.1
        with self.assertRaises(ExecutionBlocked):manage_positions(self.mt5,**self.kw)
        self.assertEqual(len(self.mt5.sent),1)
    def test_not_owned_is_ignored(self):
        self.mt5.position.magic=0
        self.assertEqual(manage_positions(self.mt5,**self.kw),[])
    def test_low_confidence_skips(self):
        self.assertEqual(manage_positions(self.mt5,**dict(self.kw,confidence=.60)),[])
    def test_disabled_blocks(self):
        with self.assertRaises(ExecutionBlocked):manage_positions(self.mt5,**dict(self.kw,live_enabled=False))
    def test_wrong_broker_blocks(self):
        self.mt5.acc.company='Another broker'
        with self.assertRaises(ExecutionBlocked):manage_positions(self.mt5,**self.kw)
    def test_stale_tick_blocks(self):
        self.mt5.tick.time=time.time()-900
        with self.assertRaises(ExecutionBlocked):manage_positions(self.mt5,**self.kw)
    def test_stop_cannot_widen(self):
        self.mt5.position.sl=103.9
        suggestion=propose(self.mt5.position,direction='buy',confidence=.8,atr=3,
                     bid=105,ask=105.1,point=.01,digits=2,stops_level=10)
        self.assertIsNone(suggestion)
    def test_near_stop_level(self):
        self.mt5.position.sl=100.;self.mt5.position.tp=105.2
        suggestion=propose(self.mt5.position,direction='sell',confidence=.9,atr=2,
                     bid=105,ask=105.1,point=.01,digits=2,stops_level=100)
        self.assertIsNone(suggestion)
    def test_uncertain_no_retry(self):
        def crash(req):raise RuntimeError('Connection lost')
        self.mt5.order_send=crash
        with self.assertRaises(ExecutionBlocked):manage_positions(self.mt5,**self.kw)
        with self.assertRaises(ExecutionBlocked):manage_positions(self.mt5,**self.kw)
        self.assertEqual(self.j.db.execute('SELECT status FROM modifications').fetchone()[0],'UNKNOWN')

if __name__=='__main__':unittest.main()
