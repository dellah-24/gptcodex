import math
import tempfile
import unittest
from pathlib import Path
from tempestbot.adaptive import LearningStore, features_at, labeled_dataset, evaluate_candidate, train_candidate, confirmation


def history(n=800):
    rows=[]
    for i in range(n):
        close=100+math.sin(i*.15)*4 + i*.005
        rows.append({'time':1700000000+600*i,'open':close-.1,'high':close+.8,
                     'low':close-.9,'close':close,'tick_volume':100+i%30})
    return rows

class AdaptiveTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.store=LearningStore(Path(self.tmp.name));self.addCleanup(self.store.close)
    def test_dedupe_ingest(self):
        data=history(80);self.store.ingest('XAUUSDm',data);self.store.ingest('XAUUSDm',data)
        self.assertEqual(len(self.store.market('XAUUSD')),80)
        with self.assertRaises(Exception):self.store.ingest('EURUSD',data)
    def test_invalid_bar_rejected(self):
        data=history(2);data[0]['high']=1
        with self.assertRaises(ValueError):self.store.ingest('BTCUSD',data)
    def test_future_not_in_features(self):
        data=history(100);a=features_at(data,50)
        data[75]['close']=999999
        self.assertEqual(a,features_at(data,50))
    def test_approval_explicit(self):
        self.store.ingest('BTCUSD',history(750))
        result=train_candidate(self.store,'BTCUSD')
        self.assertIsNone(self.store.approved('BTCUSD'))
        with self.assertRaises(ValueError):self.store.approve('BTCUSD',result['version'],'INVALID')
        self.assertEqual(result['oos_samples']>=160,True)
        if result['passed']:
            self.store.approve('BTCUSD',result['version'],f"APPROVE-BTCUSD-{result['version']}")
            self.assertEqual(self.store.approved('BTCUSD')[0],result['version'])
            response=confirmation(self.store,'BTCUSD',history(750),'buy')
            self.assertIn('allowed',response)
            self.store.rollback('BTCUSD','DISABLE-BTCUSD')
            self.assertIsNone(self.store.approved('BTCUSD'))
        else:
            with self.assertRaises(ValueError):self.store.approve('BTCUSD',result['version'],f"APPROVE-BTCUSD-{result['version']}")
    def test_monitoring_alert(self):
        for i in range(40):
            self.store.track_prediction('XAUUSD',i,'v1',1,.9)
        with self.store.db:
            self.store.db.execute('UPDATE predictions SET realized=-1')
        self.assertEqual(self.store.monitoring('XAUUSD')['status'],'ALERT')
    def test_prediction_settlement(self):
        data=history(100);self.store.ingest('XAUUSD',data)
        self.store.track_prediction('XAUUSD',data[60]['time'],'test',1,.8)
        self.assertEqual(self.store.settle_predictions('XAUUSD'),1)
        self.assertEqual(self.store.settle_predictions('XAUUSD'),0)

if __name__=='__main__':unittest.main()

class DealTests(unittest.TestCase):
    def test_deal_dedupe_and_filter(self):
        from types import SimpleNamespace as NS
        with tempfile.TemporaryDirectory() as root:
            s=LearningStore(root)
            deal=NS(entry=1,symbol='XAUUSDm',profit=13,commission=-2,swap=-1,fee=0,
                    volume=.1,ticket=901,time=1700000010)
            self.assertEqual(s.record_closed_deals(123,[deal,deal]),1)
            self.assertEqual(s.deal_summary('XAUUSD'),{'closed_deals':1,'net_realized_pnl':10.0,
                                                        'winning_deals':1,'losing_deals':0})
            s.close()
