import json
import os
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch
from tempestbot.adaptive import LearningStore
from tempestbot.background import due, single_pass, ProcessLock, training_env, read_json, SYMBOLS


class BackgroundTests(unittest.TestCase):
    def test_settings_and_minimum(self):
        self.assertEqual(SYMBOLS, ('XAUUSD','BTCUSD'))
        self.assertFalse(due(None, 2000, 599, 100000)[0])
        self.assertTrue(due(None, 2000, 600, 100000)[0])
        last={'attempted_at':100000,'latest_bar_time':2000}
        self.assertEqual(due(last, 2000+144*600, 1000, 100000+3600)[1], 'waiting_24_hours')
        self.assertEqual(due(last, 2000+50*600, 1000, 200000)[1], 'insufficient_new_bars')
        self.assertTrue(due(last, 2000+144*600, 1000, 200000)[0])

    def test_empty_status_and_no_training(self):
        with tempfile.TemporaryDirectory() as d:
            calls=[]
            result=single_pass(d, now=100000, trainer=lambda *a:calls.append(a))
            self.assertEqual(calls,[])
            self.assertEqual(result['deployment'],'manual_only')
            self.assertEqual(result['symbols']['BTCUSD']['reason'],'insufficient_closed_bars')
            self.assertEqual(read_json(Path(d)/'background_status.json')['service'],'running')

    def test_training_persists_cooldown_and_never_auto_approves(self):
        with tempfile.TemporaryDirectory() as d:
            store=LearningStore(d)
            rows=[]
            for i in range(600):
                rows.append({'time':1700000000+i*600,'open':100.,'high':101.,'low':99.,'close':100.,'tick_volume':50})
            store.ingest('XAUUSD', rows)
            store.close()
            calls=[]
            def trainer(symbol, root):
                calls.append(symbol)
                return {'ok':True,'message':'created challenger'}
            r=single_pass(d,now=200000,trainer=trainer)
            self.assertEqual(calls,['XAUUSD'])
            self.assertEqual(r['symbols']['XAUUSD']['reason'],'candidate_created')
            single_pass(d,now=200010,trainer=trainer)
            self.assertEqual(calls,['XAUUSD'])
            store=LearningStore(d)
            self.assertIsNone(store.approved('XAUUSD'))
            store.close()

    def test_lock_rejects_second_instance(self):
        with tempfile.TemporaryDirectory() as d:
            with ProcessLock(Path(d)/'lock'):
                with self.assertRaises(RuntimeError):
                    with ProcessLock(Path(d)/'lock'):pass

    def test_constrained_child_threads(self):
        e=training_env()
        self.assertEqual(e['OMP_NUM_THREADS'],'1')
        self.assertEqual(e['OPENBLAS_NUM_THREADS'],'1')


if __name__=='__main__':unittest.main()
