import tempfile
import time
import unittest
from pathlib import Path
from types import SimpleNamespace as NS
from tempestbot.live import ExecutionBlocked, ExecutionJournal, execute_order, base_symbol

class FakeMT5:
    TRADE_ACTION_DEAL=1; ORDER_TYPE_BUY=0; ORDER_TYPE_SELL=1
    ORDER_FILLING_IOC=1; ORDER_FILLING_FOK=0; ORDER_TIME_GTC=0
    TRADE_RETCODE_DONE=10009; SYMBOL_TRADE_MODE_FULL=4
    def __init__(self):
        self.calls=0
        self.acc=NS(login=123456, server='JustMarkets-Demo',company='JustMarkets Ltd.',equity=10000.,trade_allowed=True,trade_expert=True)
        self.tick=NS(bid=100.,ask=100.1,time=time.time())
        self.info=NS(name='XAUUSDm',visible=True,trade_mode=4,point=.01,digits=2,
                     trade_stops_level=10,volume_min=.01,volume_max=100.,volume_step=.01,filling_mode=2)
        self.positions=[]
        self.check=0
        self.send_retcode=self.TRADE_RETCODE_DONE
    def account_info(self):return self.acc
    def terminal_info(self):return NS(connected=True)
    def symbols_get(self):return [self.info]
    def symbol_select(self,*a):return True
    def symbol_info(self,*a):return self.info
    def symbol_info_tick(self,*a):return self.tick
    def orders_get(self):return []
    def positions_get(self):return self.positions
    def order_calc_profit(self,side,sym,lots,price,sl):return -abs(price-sl)*lots*100
    def order_check(self,req):return NS(retcode=self.check)
    def order_send(self,req):
        self.calls+=1
        return NS(retcode=self.send_retcode,order=1,deal=2)

class LiveTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.journal=ExecutionJournal(Path(self.tmp.name)/'orders.sqlite3')
        self.addCleanup(self.journal.db.close)
        self.m=FakeMT5()
        self.kw=dict(login=123456,server='JustMarkets-Demo',approved_servers=['JustMarkets-Demo'],
                     symbol='XAUUSDm',side='buy',sl=98.,tp=104.,candle_time=123,
                     journal=self.journal,live_enabled=True)
    def test_sends_once(self):
        receipt=execute_order(self.m,**self.kw)
        self.assertEqual(receipt['deal'],2)
        with self.assertRaises(ExecutionBlocked):execute_order(self.m,**self.kw)
        self.assertEqual(self.m.calls,1)
    def test_opposite_direction_same_candle_is_blocked(self):
        execute_order(self.m, **self.kw)
        with self.assertRaises(ExecutionBlocked):
            execute_order(self.m, **dict(self.kw, side='sell', sl=102., tp=96.))
        self.assertEqual(self.m.calls, 1)

    def test_uncertain_order_blocks_new_candles_after_restart(self):
        self.m.send_retcode = 10030
        with self.assertRaises(ExecutionBlocked):
            execute_order(self.m, **self.kw)
        reopened = ExecutionJournal(self.journal.file)
        self.addCleanup(reopened.db.close)
        with self.assertRaisesRegex(ExecutionBlocked, 'halted for reconciliation'):
            execute_order(self.m, **dict(self.kw, journal=reopened, candle_time=124))
        self.assertEqual(self.m.calls, 1)

    def test_off_by_default(self):
        kw=dict(self.kw,live_enabled=False)
        with self.assertRaises(ExecutionBlocked):execute_order(self.m,**kw)
        self.assertEqual(self.m.calls,0)
    def test_only_allowed_symbols(self):
        for name in ['EURUSD','XAUUSDx','BTCUSDzzz','XAUUSD.mevil']:
            with self.assertRaises(ExecutionBlocked):base_symbol(name)
    def test_wrong_broker(self):
        self.m.acc.company='Not That Broker'
        with self.assertRaises(ExecutionBlocked):execute_order(self.m,**self.kw)
    def test_stale_tick(self):
        self.m.tick.time=time.time()-300
        with self.assertRaises(ExecutionBlocked):execute_order(self.m,**self.kw)
    def test_position_limit(self):
        self.m.positions=[NS(symbol='BTCUSDm'),NS(symbol='EURUSD')]
        with self.assertRaises(ExecutionBlocked):execute_order(self.m,**self.kw)
    def test_bad_order_check(self):
        self.m.check=10030
        with self.assertRaises(ExecutionBlocked):execute_order(self.m,**self.kw)
        self.assertEqual(self.m.calls,0)
    def test_minimum_volume_over_risk(self):
        self.m.info.volume_min=5.
        with self.assertRaises(ExecutionBlocked):execute_order(self.m,**self.kw)
    def test_daily_loss(self):
        self.journal.day_start(123456,10000)
        self.m.acc.equity=9700
        with self.assertRaises(ExecutionBlocked):execute_order(self.m,**self.kw)
    def test_uncertain_result_no_retry(self):
        self.m.send_retcode=10030
        with self.assertRaises(ExecutionBlocked):execute_order(self.m,**self.kw)
        with self.assertRaises(ExecutionBlocked):execute_order(self.m,**self.kw)
        self.assertEqual(self.m.calls,1)

if __name__=='__main__':unittest.main()
