import tempfile
import time
import unittest
from pathlib import Path
from types import SimpleNamespace as NS

from tempestbot.live import MAGIC, ExecutionBlocked, ExecutionJournal
from tempestbot.reversal import close_on_reversal, reversal_streak
from test_live import FakeMT5


class ReversalTests(unittest.TestCase):
    def setUp(self):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.journal = ExecutionJournal(Path(directory.name) / 'orders.sqlite3')
        self.addCleanup(self.journal.db.close)
        self.mt = FakeMT5()
        self.mt.POSITION_TYPE_BUY = self.mt.DEAL_TYPE_BUY = 0
        self.mt.POSITION_TYPE_SELL = self.mt.DEAL_TYPE_SELL = 1
        self.mt.positions = [NS(ticket=73, symbol='XAUUSDm', magic=MAGIC, type=0, volume=.13)]
        self.mt.positions_get = lambda **kw: self.mt.positions
        self.mt.orders_get = lambda **kw: []
        self.mt.history_deals_get = lambda **kw: [NS(type=0, magic=MAGIC)]
        self.kwargs = dict(login=self.mt.acc.login, server=self.mt.acc.server, symbol='XAUUSDm',
                           candle=int(time.time() // 600) * 600 - 600, direction='sell',
                           journal=self.journal, expected_mode=None)

    def test_adjacent_decisions_only(self):
        def count(previous, candle, side='sell', score=.8):
            return reversal_streak(previous, candle=candle, side=side, confidence=score, threshold=.7)
        first = count(None, 600)
        self.assertEqual(count(first, 600), first)
        self.assertEqual(count(first, 1200)[2], 2)
        self.assertEqual(count(first, 1800)[2], 1)
        self.assertEqual(count(first, 1200, score=.68)[2], 0)
        self.assertEqual(count(first, 1200, side='buy')[2], 1)

    def test_closes_exact_ticket_and_volume(self):
        def send(request):
            self.assertEqual(request['position'], 73)
            self.assertEqual(request['volume'], .13)
            self.assertEqual(request['type'], self.mt.ORDER_TYPE_SELL)
            self.mt.positions = []
            return NS(retcode=10009, deal=2, order=1, volume=.13)
        self.mt.order_send = send
        self.assertTrue(close_on_reversal(self.mt, **self.kwargs))
        self.assertEqual(self.journal.history()[0]['status'], 'FILLED')

    def test_uncertain_or_partial_exit_halts_further_orders(self):
        self.mt.order_send = lambda request: NS(retcode=10010, deal=2, order=1, volume=.05)
        with self.assertRaises(ExecutionBlocked):
            close_on_reversal(self.mt, **self.kwargs)
        self.assertEqual(self.journal.history()[0]['status'], 'PARTIAL')
        with self.assertRaisesRegex(ExecutionBlocked, 'halted for reconciliation'):
            self.journal.require_reconciled(self.mt.acc.login)

    def test_full_receipt_is_insufficient_while_position_still_visible(self):
        with self.assertRaises(ExecutionBlocked):
            close_on_reversal(self.mt, **self.kwargs)
        self.assertEqual(self.journal.history()[0]['status'], 'RECONCILE')

    def test_dry_run_and_non_bot_trade(self):
        self.assertTrue(close_on_reversal(self.mt, **self.kwargs, dry_run=True))
        self.mt.positions[0].magic = 0
        self.assertFalse(close_on_reversal(self.mt, **self.kwargs))
        self.assertEqual(self.mt.calls, 0)

    def test_mixed_position_ownership_is_blocked(self):
        self.mt.history_deals_get = lambda **kw: [NS(type=0, magic=MAGIC), NS(type=0, magic=42)]
        with self.assertRaisesRegex(ExecutionBlocked, 'exclusive bot ownership'):
            close_on_reversal(self.mt, **self.kwargs)
        self.assertEqual(self.mt.calls, 0)
