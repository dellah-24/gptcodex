import unittest
from tempfile import TemporaryDirectory
from pathlib import Path
from tempestbot.core import (canonical_symbol,ensure_server,RiskConfig,risk_gate,position_size,
                             smc_ict_confirm,performance,backtest_bars)
from tempestbot.storage import Store

class CoreTests(unittest.TestCase):
    def test_symbols(self):
        self.assertEqual(canonical_symbol('xauusd.m'),'XAUUSD')
        self.assertEqual(canonical_symbol('BTCUSD'),'BTCUSD')
        for sym in ['EURUSD','XAGUSD','ETHUSD','XAUUSDEUR','../abc']:
            with self.assertRaises(ValueError): canonical_symbol(sym)
    def test_servers_and_limit(self):
        with TemporaryDirectory() as tmp:
            store=Store(Path(tmp)/'settings.json')
            with self.assertRaises(ValueError): store.add_server('OtherBroker-Demo')
            store.add_server('JustMarkets-EXAMPLE-ONLY')
            store.add_account('12345','JustMarkets-EXAMPLE-ONLY')
            store.add_account('12346','JustMarkets-EXAMPLE-ONLY')
            with self.assertRaises(ValueError): store.add_account('12347','JustMarkets-EXAMPLE-ONLY')
            with self.assertRaises(ValueError): store.remove_server('JustMarkets-EXAMPLE-ONLY')
    def test_risk_loss_limit(self):
        kwargs=dict(config=RiskConfig(),day_start_equity=10000,current_equity=9750,
                    positions=0,spread=1,stop_distance=10,reward_distance=20,
                    subscribed=True,enabled=True)
        ok,why=risk_gate(**kwargs)
        self.assertFalse(ok)
        self.assertIn('Daily loss',why)
        kwargs['current_equity']=9980
        self.assertTrue(risk_gate(**kwargs)[0])
        kwargs['enabled']=False
        self.assertFalse(risk_gate(**kwargs)[0])
    def test_min_lot_rejection(self):
        with self.assertRaises(ValueError):
            position_size(equity=100,risk_percent=0.5,stop_distance=100,
                          tick_size=1,tick_value=1,volume_min=0.1,volume_max=10,volume_step=0.1)
    def test_smc_fail_closed(self):
        bars=[{'open':10,'high':11,'low':9,'close':10} for _ in range(20)]
        self.assertFalse(smc_ict_confirm(bars,'buy')['confirmed'])
    def test_stats(self):
        stats=performance([{'net_pnl':100},{'net_pnl':-50}],1000)
        self.assertEqual(stats['profit_factor'],2)
        self.assertEqual(stats['ending_balance'],1050)
    def test_backtest_sltp_ambiguity(self):
        bars=[{'open':100,'high':100,'low':100,'close':100},
              {'open':100,'high':120,'low':80,'close':105}]
        out=backtest_bars(bars,[{'index':0,'side':'buy','sl':95,'tp':110,'volume':1,'cash_per_price_unit':1}])
        self.assertEqual(out['trades'][0]['net_pnl'],-5)
        self.assertTrue(out['trades'][0]['same_bar_ambiguous'])
if __name__=='__main__':unittest.main()
