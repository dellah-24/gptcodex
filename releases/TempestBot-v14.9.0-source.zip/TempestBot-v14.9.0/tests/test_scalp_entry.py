import unittest

from tempestbot.scalp_entry import EntryRules, Setup, entry_bracket, entry_decision, quote_guard


def signal(stamp, side=None, context='buy', low=100.1, high=101, close=100.2):
    return dict(candle_time=stamp, side=side, atr=1, breakout_level=100,
                context={'M5':context,'M15':context,'H1':context}, high=high, low=low, close=close)


class EntryRuleTests(unittest.TestCase):
    rules = EntryRules('retest')

    def test_waits_for_later_closed_candle_and_allows_confirmed_retest_without_breakout(self):
        pending, entered, _ = entry_decision(signal(60,'buy'),None,self.rules)
        self.assertIsNone(entered)
        self.assertIsNone(entry_decision(signal(60),pending,self.rules)[1])
        self.assertEqual(entry_decision(signal(120),pending,self.rules)[:2],(None,pending))

    def test_cancels_on_invalidation_disagreement_and_expiry(self):
        pending = Setup('buy',100,1,60)
        for sample, reason in [(signal(120,context='sell'),'direction changed'),
                               (signal(120,close=99.4),'level failed'),
                               (signal(300),'expired')]:
            active, entry, result = entry_decision(sample,pending,self.rules)
            self.assertEqual((active,entry),(None,None))
            self.assertIn(reason,result)

    def test_sell_retest_uses_high(self):
        pending = Setup('sell',100,1,60)
        self.assertEqual(entry_decision(signal(120,context='sell',high=100.12,close=99.8),pending,self.rules)[1],pending)

    def test_distance_and_costs_are_measured_against_executable_quote(self):
        setup = Setup('buy',100,1,60)
        stop,target = entry_bracket(setup,self.rules,100.1)
        self.assertIsNone(quote_guard(setup,self.rules,100.1,stop,target,.01)[0])
        self.assertIn('distance',quote_guard(setup,self.rules,100.6,stop,target,.01)[0])
        live_costs = EntryRules('retest',commission_bps=10,slippage_points=20)
        self.assertIn('after estimated',quote_guard(setup,live_costs,100.1,stop,target,.01)[0])
