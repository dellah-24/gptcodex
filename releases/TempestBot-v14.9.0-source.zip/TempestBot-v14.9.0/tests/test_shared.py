import json
import unittest
from datetime import datetime,timedelta,timezone
from tempestbot.shared import (SupabaseTransport,UserHub,CentralHub,closed_bar,consensus_bars,SharedError)

class FakeAPI:
    def __init__(self):self.calls=[];self.payload=[]
    def __call__(self,request):
        self.calls.append(request)
        if request.method=='GET':return 200,json.dumps(self.payload).encode()
        return 201,b'[]'

class SharedTests(unittest.TestCase):
    def setUp(self):
        self.api=FakeAPI();self.hub=UserHub(SupabaseTransport('https://example.supabase.co','public','jwt',self.api))
    def test_closed_bar(self):
        bar=dict(time=600,open=1,high=2,low=.5,close=1.4,tick_volume=12)
        self.assertEqual(closed_bar('XAUUSDm',bar,now=2400)['symbol'],'XAUUSD')
        with self.assertRaises(ValueError):closed_bar('EURUSD',bar,now=2400)
        with self.assertRaises(ValueError):closed_bar('XAUUSD',dict(bar,high=1),now=2400)
        with self.assertRaises(ValueError):closed_bar('XAUUSD',dict(bar,time=1200),now=1250)
    def test_user_contribution_has_no_user_override(self):
        row=dict(time=600,open=1,high=2,low=.5,close=1.4,tick_volume=12)
        self.assertEqual(self.hub.contribute('BTCUSDm',[row],now=2400),1)
        req=self.api.calls[-1]
        self.assertEqual(req.get_header('Authorization'),'Bearer jwt')
        self.assertNotIn('user_id',req.data.decode())
    def test_expired_signal_rejected(self):
        now=datetime.now(timezone.utc)
        self.api.payload=[{'symbol':'BTCUSD','timeframe':'M10','direction':'buy','candle_time':600,
            'expires_at':(now-timedelta(minutes=1)).isoformat()}]
        self.assertIsNone(self.hub.latest_signal('BTCUSD',now.timestamp()))
        self.api.payload[0]['expires_at']=(now+timedelta(minutes=1)).isoformat()
        self.assertEqual(self.hub.latest_signal('BTCUSD',now.timestamp())['direction'],'buy')
    def test_consensus_requires_unique_users_and_agreement(self):
        row={'symbol':'XAUUSD','bar_time':600,'open':100,'high':102,'low':99,'close':101,'tick_volume':20,'user_id':'a'}
        self.assertEqual(consensus_bars([row,row]),[])
        other=dict(row,user_id='b',close=101.02)
        result=consensus_bars([row,other])
        self.assertEqual(result[0]['contributors'],2)
        self.assertEqual(consensus_bars([row,dict(other,close=120)]),[])
    def test_central_only_publisher_and_dedup(self):
        publisher=CentralHub(SupabaseTransport('https://example.supabase.co','serverkey',requester=self.api))
        t=datetime.now(timezone.utc)+timedelta(minutes=1)
        publisher.publish_signal('BTCUSD',600,'flat',.9,'v1','s1',t.isoformat())
        self.assertIn(b'"direction": "flat"',self.api.calls[-1].data)
        self.assertNotIn('on_conflict',self.api.calls[-1].full_url)
    def test_bad_url_rejected(self):
        with self.assertRaises(ValueError):SupabaseTransport('http://insecure.local','key')

if __name__=='__main__':unittest.main()

class CentralChecks(unittest.TestCase):
    def test_no_approved_model_produces_flat_signal(self):
        from tempestbot.central_learning import calculate_shared_signal
        class Store:
            def market(self,s):return [dict(time=600*i,open=100.,high=101.,low=99.,close=100.,tick_volume=2.) for i in range(1,41)]
            def approved(self,s):return None
        result=calculate_shared_signal(Store(),'XAUUSD',[])
        self.assertEqual(result['direction'],'flat')
        self.assertEqual(result['model_version'],'none')
    def test_shared_train_due_requires_new_distinct_bars(self):
        from tempestbot.background import due
        last={'attempted_at':0.,'latest_bar_time':600*600}
        self.assertFalse(due(last,600*700,700,86401.,new_bar_count=100)[0])
        self.assertTrue(due(last,600*744,744,86401.,new_bar_count=144)[0])
    def test_manual_promotion_requires_exact_ack(self):
        from tempestbot.central_learning import promote_central
        with self.assertRaises(ValueError):promote_central('BTCUSD','test','/tmp/unused','wrong')
