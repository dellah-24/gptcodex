import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from tempestbot.paper import PaperLedger
from tempestbot.core import RiskConfig

class PaperTests(unittest.TestCase):
    def test_roundtrip_and_idempotency(self):
        with TemporaryDirectory() as tmp:
            p=PaperLedger(Path(tmp)/'paper.sqlite3')
            args=dict(request_id='unique-123',account='12345',symbol='XAUUSD',side='buy',qty=1,entry=2000,sl=1990,tp=2020,risk=vars(RiskConfig()))
            a=p.open(**args)
            self.assertFalse(a['duplicate'])
            self.assertTrue(p.open(**args)['duplicate'])
            self.assertEqual(len(p.snapshot()['trades']),1)
            self.assertEqual(p.close(a['id'],2020)['net_pnl'],20)
            self.assertEqual(p.snapshot()['metrics']['net_pnl'],20)
            with self.assertRaises(ValueError):p.close(a['id'],2020)
    def test_safety_gates(self):
        with TemporaryDirectory() as tmp:
            p=PaperLedger(Path(tmp)/'paper.sqlite3')
            data=dict(request_id='unique-abc',account='12345',symbol='BTCUSD',side='buy',qty=100,entry=2000,sl=1990,tp=2020,risk=vars(RiskConfig()))
            with self.assertRaisesRegex(ValueError,'risk per trade'):p.open(**data)
            data['qty']=1;data['symbol']='EURUSD'
            with self.assertRaises(ValueError):p.open(**data)
            data['symbol']='BTCUSD';data['tp']=2002
            with self.assertRaisesRegex(ValueError,'Reward-to-risk'):p.open(**data)
    def test_position_limit(self):
        with TemporaryDirectory() as tmp:
            p=PaperLedger(Path(tmp)/'paper.sqlite3')
            args=dict(account='12345',symbol='BTCUSD',side='buy',qty=1,entry=2000,sl=1990,tp=2020,risk=vars(RiskConfig(max_positions=1)))
            p.open(request_id='request-a',**args)
            with self.assertRaisesRegex(ValueError,'Position limit'):p.open(request_id='request-b',**args)

if __name__ == '__main__':unittest.main()
