"""Exercise the real legacy-model inference path without connecting to a broker."""
import importlib.util
import unittest
from types import SimpleNamespace
from unittest.mock import patch

from tempestbot.live import ExecutionBlocked
from tempestbot.runner import signals


@unittest.skipUnless(all(importlib.util.find_spec(name) for name in
                         ('numpy', 'pandas', 'ta', 'lightgbm', 'joblib')),
                     'worker model dependencies are required')
class ScannerTests(unittest.TestCase):
    def test_bundled_models_generate_signals_on_current_closed_bar(self):
        import numpy as np

        count = 600
        current = 1_800_000_000
        rng = np.random.default_rng(193)
        close = 2300 + rng.normal(0, 1, count).cumsum()
        opening = np.r_[close[0], close[:-1]]
        rows = np.rec.fromarrays(
            [current - count * 600 + np.arange(count) * 600,
             opening, np.maximum(opening, close) + rng.uniform(.1, 2, count),
             np.minimum(opening, close) - rng.uniform(.1, 2, count), close,
             rng.integers(100, 1500, count), rng.integers(10, 100, count)],
            names='time,open,high,low,close,tick_volume,spread',
        )

        def closed_rates(symbol, timeframe, offset, size):
            self.assertEqual((timeframe, offset, size), (10, 1, count))
            return rows

        broker = SimpleNamespace(
            TIMEFRAME_M10=10, copy_rates_from_pos=closed_rates,
            symbol_info_tick=lambda symbol: SimpleNamespace(bid=2300, ask=2300.1),
        )
        with patch('tempestbot.runner.time.time', return_value=current + 5):
            for symbol in ('XAUUSDm', 'BTCUSDm'):
                with self.subTest(symbol=symbol):
                    result = signals(broker, symbol, min_probability=.5)
                    self.assertEqual(result['candle_time'], current - 600)
                    self.assertAlmostEqual(result['prob_up'] + result['prob_down'], 1.0, places=3)
                    self.assertGreater(result['atr'], 0)
        with patch('tempestbot.runner.time.time', return_value=current + 600):
            with self.assertRaisesRegex(ExecutionBlocked, 'stale'):
                signals(broker, 'XAUUSDm')
