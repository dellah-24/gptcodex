import unittest
from tempfile import TemporaryDirectory
from pathlib import Path
from tempestbot.research import load_closed_bars, build_dataset
class ResearchTests(unittest.TestCase):
 def test_csv_unsorted_rejected(self):
  with TemporaryDirectory() as d:
   f=Path(d)/'bars.csv'
   f.write_text('time,open,high,low,close,tick_volume\n2026-01-02,1,2,0.5,1,20\n2026-01-01,1,2,0.5,1,20\n')
   with self.assertRaisesRegex(ValueError,'increasing'):load_closed_bars(f)
 def test_future_changes_dont_affect_prior_features(self):
  bars=[{'open':100+i*.1,'high':101+i*.1,'low':99+i*.1,'close':100+i*.1,'tick_volume':100} for i in range(280)]
  x,y,indices=build_dataset(bars)
  bars[-1]['close']=1
  x2,y2,indices2=build_dataset(bars)
  self.assertTrue((x==x2).all())  # final bar is never a feature row
  self.assertNotEqual(y[-1],y2[-1])
if __name__=='__main__':unittest.main()
