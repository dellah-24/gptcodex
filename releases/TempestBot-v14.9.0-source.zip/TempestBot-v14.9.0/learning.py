from tempestbot.adaptive import main
if __name__ == '__main__':main()
