# Admin learning review and live approval

Apply `supabase/007_improvement_review.sql` after migrations 001–006 and publish the updated `web/` using your existing deployment. The **Admin Overview** page then shows the scalping learning and live approvals panel. Only users in the existing Supabase admin role can see or approve learning reviews.

## Start and log demo training

On the Windows MT5 host, start a historically qualified candidate with the exact JustMarkets demo login, server and symbol.

```powershell
python -m worker.main --login 123456 --server JustMarkets-Demo --symbol XAUUSDm --strategy scalp --mode demo --enable-demo --improvement-profile <candidate-id>
```

The worker verifies it is connected to a demo account. The MT5 password is entered on the Windows host, or provided by the existing worker environment. The website does not collect the password. The worker logs demo session start and graceful shutdown and records net P&L for fully closed positions attributable to that profile. An interrupted session can show no stop recorded.

## Sync and review the evidence

On the trusted Windows host, in a separate shell, configure the Supabase URL, publishable key and a current administrator JWT. Run:

```powershell
python -m tempestbot.improve sync-review --interval 15
```

Provide a candidate ID to sync only one profile, or omit the interval for a one-time sync. The uploader shares the immutable evaluation report, masked demo login, broker server, session timestamps and per-account results. Broker passwords and raw demo trade records stay on the Windows host. An authorized administrator and the trusted host are responsible for the accuracy of uploaded evidence. Renew the JWT through your existing Auth setup.

On **Admin Overview**, refresh the review panel and open the candidate. Review its configured entry style and costs, historical data range, candidate and baseline holdout performance, and demo sessions. Approval requires a qualified historical holdout plus 20 completed demo positions over at least two UTC days with positive net P&L on a single demo account. The approval freezes the supporting demo summary and records which admin approved it.

## Enable the approved profile on the Windows worker

The admin approval authorizes the exact profile ID. It does not start the worker. The live worker must be started with that ID, the correct broker account and its existing explicit live authorization flags. Use a valid authenticated Supabase JWT on the live worker so it can check cloud approval at startup and before new entries. A verification failure prevents profile-managed entries. Prior local approvals cannot authorize a managed live profile in v14.9. Manually configured trading outside the improvement-profile workflow still follows its existing local activation rules.

Check the complete flow on demo before considering live activation.
