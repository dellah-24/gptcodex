"""CLI for a central trusted TempestBot learning/signals backend or a user device.

Server credentials NEVER go on users' machines. By default commands are read-only.
"""
import argparse
import json
import os
import sys
from datetime import datetime,timezone
from pathlib import Path
from tempestbot.shared import SupabaseTransport, UserHub, CentralHub, consensus_bars, SharedError


def client():
    return UserHub(SupabaseTransport(os.environ['SUPABASE_URL'],
        os.environ['SUPABASE_PUBLISHABLE_KEY'],os.environ['SUPABASE_USER_JWT']))


def server():
    return CentralHub(SupabaseTransport(os.environ['SUPABASE_URL'],os.environ['SUPABASE_SECRET_KEY']))


def main(argv=None):
    p=argparse.ArgumentParser(description='TempestBot shared data and signal transport (no order submission)')
    commands=p.add_subparsers(dest='command',required=True)
    read=commands.add_parser('signal',help='Read last nonexpired shared signal with signed-in user token')
    read.add_argument('--symbol',required=True)
    upload=commands.add_parser('contribute',help='Upload CLOSED M10 candles exported by MT5')
    upload.add_argument('--symbol',required=True);upload.add_argument('--file',type=Path,required=True)
    aggregate=commands.add_parser('aggregate',help='TRUSTED SERVER: verify multi-user candle consensus')
    aggregate.add_argument('--symbol',required=True);aggregate.add_argument('--since',type=int,required=True)
    publish=commands.add_parser('publish',help='TRUSTED SERVER: publish one immutable official signal')
    publish.add_argument('--symbol',required=True);publish.add_argument('--bar-time',type=int,required=True)
    publish.add_argument('--direction',choices=('buy','sell','flat'),required=True)
    publish.add_argument('--confidence',type=float,required=True)
    publish.add_argument('--model-version',required=True);publish.add_argument('--strategy-version',required=True)
    publish.add_argument('--expires-at',required=True,help='UTC ISO timestamp within next 15 minutes')
    training=commands.add_parser('train',help='TRUSTED SERVER: train shared challenger on validated canonical bars')
    training.add_argument('--symbol',required=True);training.add_argument('--data-dir',type=Path,default=Path.home()/'.tempestbot'/'central-learning')
    approve=commands.add_parser('approve',help='TRUSTED SERVER: manual-only model promotion')
    approve.add_argument('--symbol',required=True);approve.add_argument('--version',required=True)
    approve.add_argument('--ack',required=True);approve.add_argument('--data-dir',type=Path,default=Path.home()/'.tempestbot'/'central-learning')
    cycle=commands.add_parser('cycle',help='TRUSTED SERVER: one consensus, sync and shared-signal cycle')
    cycle.add_argument('--data-dir',type=Path,default=Path.home()/'.tempestbot'/'central-learning')
    args=p.parse_args(argv)
    try:
        if args.command=='signal':print(json.dumps(client().latest_signal(args.symbol),indent=2))
        elif args.command=='contribute':
            records=json.loads(args.file.read_text(encoding='utf8'))
            if not isinstance(records,list):raise ValueError('File must be an array of closed candle objects')
            print(json.dumps({'submitted':client().contribute(args.symbol,records)}))
        elif args.command=='aggregate':
            hub=server(); data=hub.contributions(args.symbol,args.since)
            candidate=consensus_bars(data)
            hub.publish_canonical(candidate)
            print(json.dumps({'received':len(data),'consensus_bars':len(candidate)}))
        elif args.command=='train':
            from tempestbot.central_learning import train_central
            print(json.dumps(train_central(args.symbol,args.data_dir),indent=2))
        elif args.command=='approve':
            from tempestbot.central_learning import promote_central
            print(json.dumps(promote_central(args.symbol,args.version,args.data_dir,args.ack),indent=2))
        elif args.command=='cycle':
            from tempestbot.central_service import cycle_once
            print(json.dumps(cycle_once(args.data_dir),indent=2))
        elif args.command=='publish':
            server().publish_signal(args.symbol,args.bar_time,args.direction,args.confidence,
                args.model_version,args.strategy_version,args.expires_at)
            print(json.dumps({'published':True,'symbol':args.symbol,'bar_time':args.bar_time}))
    except (ValueError,KeyError,SharedError,OSError) as exc:
        p.exit(2,f'Shared hub refused operation: {exc}\n')

if __name__=='__main__':main()
