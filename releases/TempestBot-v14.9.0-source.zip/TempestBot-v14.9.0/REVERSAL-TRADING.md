# Signal-driven exits and reversals

TempestBot v14.4 can close an existing bot position when analysis confirms an opposite signal. Enable exits with `--exit-on-reversal`. Add `--reverse-on-signal` to consider an opposite entry on the same candle once MT5 confirms the exit. Both options are off by default. Run the normal dry-run and JustMarkets demo acceptance steps before using either in live mode.

The default exit trigger is two consecutive completed M10 candles with the same opposite direction and a score of at least 0.70. Configure it with `--reversal-bars` and `--reversal-threshold`. The normal signal qualification still applies on every candle. Local mode uses the bundled classifier and structure confirmation. Shared mode uses the fresh official signal for the corresponding candle. The confirmation streak starts over on a worker restart.

The worker submits a close by MT5 position ticket and volume. It checks ownership from broker deal history and requires the symbol to have a single position and no pending orders. Mixed ownership or an uncertain or partial exit blocks immediate re-entry. A confirmed opposite entry gets fresh stop and target prices and must pass the normal entry checks, including adaptive vetoes if configured, account exposure and the daily-loss halt. Existing account and journal holds still apply to exits. A daily-loss or exposure halt prevents adding exposure while allowing a qualified exit when the other safeguards pass.

Save the existing journal when upgrading. Use the same `worker.reconcile` command for unresolved exits. Review live prices, deal volume, ticket closure, and the resulting position in MT5 during demo acceptance.

The v14.3 historical replay still measures the fixed-bracket strategy. It does not evaluate the new reversal policy. The defaults above are starting settings for demo validation, with no demonstrated performance improvement from broker data.
