> In v14.9, use the [admin review workflow](ADMIN-LEARNING-REVIEW.md) for live approval. The local approval CLI does not authorize a managed live profile.

# TempestBot v14.8 continuous improvement

The evaluator compares a bounded set of existing scalping entry styles and distances on bid/ask ticks. It chooses a candidate using older data, freezes the choice, and then evaluates the candidate and a named baseline on the next untouched period. The record includes configurations, costs, metrics, data hash, and window boundaries. A qualifying result must have at least 20 holdout trades, positive net P&L above the baseline, and drawdown no higher than the baseline or 0.1%, whichever is greater. These are screening rules, not a profitability guarantee.

## 1. Run the evaluator on fresh data

Use one append-only CSV per symbol with chronological `time,bid,ask` columns. Load enough historical ticks for at least 100 hours of warmup plus tuning trades. Choose an initial UTC cutoff strictly after data already used to choose or validate the rules. Later runs require a new holdout of at least 24 hours and reject changes to previously evaluated bytes. Data must be supplied by your broker export process. This release does not install a tick downloader or schedule a task on your PC.

```powershell
python -m tempestbot.improve evaluate XAUUSD-ticks.csv --symbol XAUUSD --baseline breakout --initial-cutoff 2026-11-01T00:00:00Z --point 0.01 --slippage-points 2 --commission-bps 1 --buy-swap-bps 0 --sell-swap-bps 0 --interval 60
```

Replace the date and example costs with verified values. Omit `--interval` for a single evaluation. When left running, the command checks the file on that interval and records evidence in the local improvement SQLite database. An unqualified result is retained for review but cannot be started as a profile.

## 2. Run a qualified candidate on demo

```powershell
python -m worker.main --login 123456 --server JustMarkets-Demo --symbol XAUUSDm --strategy scalp --mode demo --enable-demo --improvement-profile <candidate-id>
python -m tempestbot.improve status
```

Profile-managed execution is limited to one symbol and the replay's default risk and protection settings. Use a USD account and a contract with the evaluated point size. Custom reversal, management, session, spread, cooldown and entry overrides are outside this profile evaluator. Ordinary trading configurations remain available without a profile.

The worker records completed positions whose entry order is tied to the exact profile, verifies volumes and bot ownership against MT5 history, and accounts for entry and exit commissions, swaps, and fees. Partial exits stay outside the evidence until the entire position has closed. Keep the worker running so it can reconcile evidence from the rolling seven-day broker history. The status command reports demo and live outcomes separately by account and server.

## 3. Approve and explicitly select a live profile

Once the candidate has at least 20 completed demo positions over at least two UTC days with positive net P&L on one demo account, an operator can approve it. Review the stored report with `python -m tempestbot.improve show <candidate-id>`, inspect MT5 fills and confirm broker costs before approval.

```powershell
python -m tempestbot.improve approve <candidate-id> --demo-login 123456 --demo-server JustMarkets-Demo
```

The approval is local and pins the immutable candidate ID. Starting a live worker still needs the normal live authorization flags and an explicit `--improvement-profile <candidate-id>`. A running worker does not switch profiles. Stop and restart with a previous approved profile to roll back. Keep the improvement and execution databases together on the Windows host, and protect and back them up with your normal host controls.

The workflow learns which existing entry configuration to propose from successive market windows. Neither an individual win nor a live outcome changes the running strategy. Continued positive returns are unproven.
