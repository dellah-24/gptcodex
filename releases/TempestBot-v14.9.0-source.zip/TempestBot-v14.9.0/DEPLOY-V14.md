# TempestBot v14 deployment package

## Provenance
No independent **TempestBot v14 source archive** was provided. This package reorganizes the existing v0.8 project into the requested `web/`, `worker/`, `supabase/` directories, preserving the existing `tempestbot/` engine, legacy models, tests, and compatibility scripts. It should **not** be represented as verified v14 upstream code or approved for live-money trading.

## Environment and safety
- Browser web settings in `web/config.js` use ONLY the public Supabase URL and publishable key from the supplied credentials. They are not secrets.
- Uploaded Supabase service-role key, management access token, Cloudflare OAuth and refresh tokens are intentionally NOT bundled, copied, printed, or used. **Rotate/revoke all those disclosed privileged credentials before deployment**.
- Use `.env.example` to create your own local `.env` for the trusted worker; leave `TEMPESTBOT_LIVE_ENABLED=NO`. Never upload `.env` or `CREDENTIALS.txt` to Cloudflare or Git.
- The uploaded Cloudflare OAuth token was past its recorded expiry at the time of the request; log in again using `npx wrangler login` on your own machine. Do not paste an OAuth token into the web app.

## Supabase
1. Back up your Supabase project and use staging first.
2. In SQL Editor run `supabase/001_shared_learning.sql`, then `supabase/002_app_foundation.sql`, then `supabase/003_v14_hardening.sql`. Review existing objects and policy conflicts if migrations have already been applied.
3. Enable Auth email verification, configure Site URL `https://bot.tempesttechnologies.co.zw` and permitted redirect origins, protect signups, and review RLS policies and grants.
4. Enter **verified** JustMarkets server names using a trusted administrator/database connection, not a browser public key. Set up a central AI coordinator separately; Supabase itself does not run Python training jobs.
5. Test two independent users: users may read shared signals but may not access each other's account identifiers or contributions. Confirm a third MT5 account is rejected and non-admins cannot alter official signals or model approvals.

## Cloudflare Pages
1. Install Node.js, then run `npm install` and `npm run check`.
2. Publish **only** `web/` with `npx wrangler pages deploy web --project-name tempestbot`, after `npx wrangler login`. Use an account with ownership of the existing `tempestbot` Pages project.
3. Verify `https://tempestbot.pages.dev` and the custom domain `https://bot.tempesttechnologies.co.zw` (configured separately in Cloudflare Pages). Validate HTTPS, service-worker installation, CSP and Auth redirects in a browser.
4. Never deploy the repository root or `worker/`, `legacy/`, `supabase/`, `CREDENTIALS.txt`, or any `.env` as static assets.

## Local Windows execution
1. `py -m venv .venv`, activate it, and `pip install -r requirements-worker.txt`.
2. Configure local `.env` based on `.env.example` (never share it).
3. Run `python -m worker.main --help`, then configure a JustMarkets demo account and test dry-run before enabling demo mode. The existing runner is still broker-unverified.
4. Real-money orders are **not production-approved**: needs demo soak tests, broker-side reconciliation, local-agent auth integration, user entitlements enforced at execution, incident recovery and independent security audit.

## Verify source package
`python -m unittest discover -s tests -v`
`python -m unittest discover -s production_tests -v`
`node --check web/app.js`
`python -m worker.main --help`

## Deployment separation
PWA is hosted on Cloudflare. Shared data resides in Supabase. Python strategy/model coordination is hosted by a separate trusted machine. MT5 executions remain on **each user's own Windows PC**. Closing the PC stops new orders and dynamic SL/TP management.

## v14.1 multi-page update
The web interface is now separate static route directories instead of one HTML document. See `MULTIPAGE-DEPLOYMENT.md` and apply `supabase/004_multipage_platform.sql` after the prior migrations. Existing Cloudflare project and worker code are retained. Live-money validation remains pending.
