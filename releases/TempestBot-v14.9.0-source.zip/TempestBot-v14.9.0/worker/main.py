"""Local Windows MT5 worker launcher; default is dry-run, never silently enables live trading."""
import os
import sys
from pathlib import Path

def load_env(path):
    """Read simple KEY=VALUE entries, without printing secrets or overwriting host settings."""
    if not path.exists(): return
    for raw in path.read_text(encoding='utf-8').splitlines():
        raw=raw.strip()
        if not raw or raw.startswith('#') or '=' not in raw: continue
        key,value=raw.split('=',1)
        key=key.strip()
        if key.isidentifier(): os.environ.setdefault(key,value.strip().strip('"').strip("'"))

def main():
    root=Path(__file__).resolve().parent.parent
    load_env(root/'.env')
    from tempestbot.runner import main as run
    return run()

if __name__=='__main__':
    sys.exit(main() or 0)
