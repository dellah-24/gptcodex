"""Inspect and acknowledge unresolved broker outcomes from the local journal."""
import argparse
import sqlite3
from contextlib import closing
import json
from pathlib import Path

from tempestbot.live import ExecutionBlocked, ExecutionJournal, account_lease, UNRESOLVED



def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--login', required=True, type=int)
    parser.add_argument('--resolve', nargs=2, metavar=('TABLE', 'KEY'))
    parser.add_argument('--history', type=int, metavar='LIMIT', help='Show recent settled and unresolved attempts')
    parser.add_argument('--broker-deal', type=int, help='Verified MT5 entry deal for an acknowledged order')
    parser.add_argument('--note', help='Broker evidence and outcome verified in MT5 history')
    args = parser.parse_args()
    tables = ('orders', 'modifications')
    if args.resolve and (args.resolve[0] not in tables or not (args.note or '').strip()):
        parser.error('Use orders or modifications and include a reconciliation note')
    if args.broker_deal is not None and (args.broker_deal <= 0 or not args.resolve or args.resolve[0] != 'orders'):
        parser.error('--broker-deal requires an order acknowledgement and a positive broker deal ID')
    if args.history is not None and (args.history <= 0 or args.resolve):
        parser.error('--history requires a positive limit and cannot be combined with --resolve')
    path = Path.home() / '.tempestbot' / 'execution.sqlite3'
    if not path.exists():
        parser.exit(2, 'Execution journal does not exist.\n')
    journal = ExecutionJournal(path)
    try:
        with closing(journal.db):
            if args.resolve:
                table, key = args.resolve
                with account_lease(journal, args.login), journal.db:
                    result = journal.db.execute(
                        f"""UPDATE {table}
                            SET status='ACKNOWLEDGED',
                                data=json_object('previous',json(data),'operator_note',?,
                                                 'operator_deal',?,'acknowledged_at',CURRENT_TIMESTAMP)
                            WHERE account=? AND key=? AND status IN (?,?,?,?,?)""",
                        (args.note.strip(), args.broker_deal, args.login, key, *UNRESOLVED),
                    )
                    if result.rowcount != 1:
                        raise ExecutionBlocked('No unresolved record matched that account and key')
                print('Broker outcome acknowledged. The original attempt remains recorded.')
            else:
                for table in tables:
                    sql = f'SELECT key,symbol,status,timestamp,data FROM {table} WHERE account=?'
                    if args.history:
                        rows = journal.db.execute(sql + ' ORDER BY timestamp DESC, rowid DESC LIMIT ?',
                                                  (args.login, args.history))
                    else:
                        rows = journal.db.execute(sql + ' AND status IN (?,?,?,?,?)',
                                                  (args.login, *UNRESOLVED))
                    for key, symbol, status, timestamp, data in rows:
                        print(json.dumps(dict(table=table, key=key, symbol=symbol, status=status,
                                              timestamp=timestamp, evidence=json.loads(data))))
    except (ExecutionBlocked, sqlite3.Error) as exc:
        parser.exit(2, f'{exc}\n')


if __name__ == '__main__':
    main()
