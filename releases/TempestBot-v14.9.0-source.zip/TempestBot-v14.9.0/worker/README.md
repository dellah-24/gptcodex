# Local MT5 worker

Run only on a Windows computer with a compatible MetaTrader 5 terminal and the terminal connected to JustMarkets. From repository root: `python -m worker.main --help`. The worker defaults to dry-run and requires explicit authorization for demo/live orders; see `python -m worker.main --help`.

`worker/main.py` loads optional local `.env` variables without logging them. Never copy `.env`, broker passwords, service-role tokens, or user JWTs into `web/`, GitHub, or a ZIP. The website is a read-only cloud dashboard and does **not** remotely control MT5.

The shared feed requires a separately acquired user session JWT. The old worker is not a fully integrated browser-to-agent authentication handoff. Test against a demo account before considering any live-money use.
