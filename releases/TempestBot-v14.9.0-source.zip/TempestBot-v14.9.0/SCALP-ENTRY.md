# TempestBot v14.7 scalping entries

The scalp strategy uses an M1 structure breakout and M5/M15/H1 EMA alignment. The local M10 model separately uses a simplified SMC/ICT-style break-of-structure plus three-candle fair value gap confirmation. The scalp rules use structure but do not apply the M10 FVG filter or claim to implement the full ICT methodology.

The worker accepts `--scalp-entry breakout`, `distance`, or `retest`.

- **Breakout** uses the first aligned M1 breakout and quote-anchored brackets.
- **Distance** evaluates the same breakout with brackets anchored at the breakout level. The executable quote must be on the breakout side and no more than `--max-entry-distance-atr` (default 0.5) from that level.
- **Retest** anchors at the same level and waits up to `--retest-bars` (default 3) for a later completed M1 candle to touch within 0.15 breakout ATR and close back on the breakout side. The setup is cancelled by expiry, missing intervening data, loss of higher-timeframe alignment, or a close through the level beyond tolerance. A worker restart discards pending setups.

New entries require a net reward-to-risk estimate of at least 1.5. The bot prices buys at the ask and sells at the bid and deducts modeled commission and adverse slippage on both fills. Set `--entry-commission-bps` and `--entry-slippage-points` using broker data. Both estimates default to zero, and the pair is separate from spread observed in prices. Actual costs can differ from the estimate. The execution worker rechecks the rounded broker quote and stop/target before sending an order.

The worker's original reversal decision can still close an open trade while a setup is waiting. Re-entry, including after a reversal, requires an eligible entry and permission under the existing reversal rules. Dry-run and demo scalping default to retest. Live scalping stays on breakout unless the entry style is explicitly set.

Use the existing bid/ask tick replay with `--entry-style compare` to evaluate all three styles on the same file. It applies the same estimated-cost filter to each style and includes modeled fill costs in reported P&L. Run separately for XAUUSD and BTCUSD, using each broker symbol's point size and costs. Reserve a separate period for final evaluation and check the actual fills and stops in MT5 demo.

```powershell
python -m tempestbot.scalp_replay XAUUSD-ticks.csv --symbol XAUUSD --entry-style compare --point 0.01 --slippage-points 2 --commission-bps 1 --buy-swap-bps 0 --sell-swap-bps 0 --out entry-comparison.json
```

The numbers in the example are placeholders. No real broker dataset was used to validate performance for this release.
