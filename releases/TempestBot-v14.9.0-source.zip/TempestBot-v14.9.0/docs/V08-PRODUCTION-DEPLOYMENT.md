# TempestBot v0.8 — hosted PWA foundation / production rollout

## Read this before deploying

This build is **not production-approved for live-money trading**. Its cloud PWA is a read-only shared-signal dashboard and an authenticated, user-scoped metadata editor. It has no MT5 execution authority. The original Python local execution worker remains separate, Windows-dependent, and **not broker-tested**. Do not publicly expose `python run.py` (it is explicitly bound to 127.0.0.1); do not run the MT5 worker in live mode until the remaining controls are verified.

## What is built

- `cloud/` — self-contained installable HTTPS PWA with Supabase email/password signup/login, token refresh (session-scoped storage), shared XAUUSD/BTCUSD signal feed (30-second polling), model registry display, account metadata, admin read-only membership, and subscription status.
- `supabase/002_app_foundation.sql` — RLS-protected metadata for user broker accounts (maximum two, concurrent insertion guarded), approved JustMarkets servers, entitlements, and administrator identities.
- `cloud/sw.js` — caches only static HTML/CSS/JS/assets; never caches Supabase auth, dynamic API data, or `config.js`. Offline shell does **not** mean offline trading.
- `cloud/_headers` — static-host example security headers for platforms that support `_headers` files (Cloudflare Pages / Netlify syntax varies slightly).
- Original local UI, shared learning and MT5 worker remain available unchanged.

## Deploy static app and Supabase

1. Create your own Supabase project. In SQL Editor run `supabase/001_shared_learning.sql`, followed by `supabase/002_app_foundation.sql`. Back up first; apply to staging and review policies with Supabase security advisor.
2. In **Supabase Auth** configure a verified email provider, approved website URL and redirect allowlist, rate limiting, MFA policy and recovery mechanisms. Do not disable email verification for production use.
3. From Supabase project settings, take only the **public** project URL and **publishable/anon** key. Copy `cloud/config.example.js` to `cloud/config.js` and fill in values. A `service_role`/secret key must **never** be present in this file, a browser bundle, client install, or git history.
4. In a trusted backend/database admin session insert exact confirmed JustMarkets MT5 server names into `approved_broker_servers`. Do not let end users insert names. Set `tempest_admins` memberships and `user_entitlements` only from trusted admin/payment services. In SQL Editor:
   ```sql
   insert into public.approved_broker_servers(name) values ('REPLACE_WITH_VERIFIED_JUSTMARKETS_SERVER');
   ```
   The example is a **placeholder**, not a confirmed MT5 server name.
5. Deploy **only `cloud/`** to an HTTPS static host. Do **not** deploy the project root with `.sqlite3`, `legacy`, `.env`, credentials or Python modules exposed publicly.
6. Set a strict Content Security Policy and HTTPS headers on your hosting provider. `cloud/_headers` is a template; verify effective response headers with a browser/network inspector.
7. Test on a mobile and desktop browser: create an account, confirm email, sign in, view shared signals, register two account metadata records, confirm third rejected, and sign out. Confirm user A cannot read user B's rows with independent JWTs. Confirm unauthorized users cannot modify server, model registry or entitlements. Confirm stale signal states fail closed in the local execution worker.
8. The currently coded central coordinator is a separate **trusted service**; a hosted static website and Supabase tables do not run Python model training. Configure and monitor the coordinator separately, keeping secret keys exclusively on trusted hardware. Configure backups, retention limits, request quotas, alerts and periodic key rotation.

## Security limits that remain

- The cloud app is **not an MT5 remote-control surface** and has no buy/sell button. A malicious or compromised web browser must never be able to submit MT5 orders through a localhost server without an explicit, authenticated and auditable local protocol.
- Adding an MT5 login **identifier** to Supabase does not connect its account or store its password. The local MT5 worker must perform independent broker authentication and account verification.
- Subscription display is read-only. No trusted payment webhook and no server-side entitlement enforcement for the execution worker exist yet. **Do not charge customers or claim subscribed status enables trades.**
- Account IDs and trade outcomes are personal data. Obtain user consent, create a retention/deletion policy, prevent uploads of credentials and raw PII, and check relevant regulatory requirements.
- User-uploaded candles require anti-poisoning controls and a trusted independent market feed. The existing canonical aggregator is not a substitute for independent price verification.
- Central model training and approvals require out-of-sample validation, signed model artifacts, rollback, human review and change audit before any live rollout.
- Local MT5 worker needs audited crash recovery, duplicate order reconciliation, slippage and spread controls under market stress, watchdog monitoring, broker demo soak tests, and an externally tested kill switch.
- With no remote execution host, **trading stops when the user's own PC or local agent stops**. The PWA does not continue trading in the background.

## Smoke tests

Run from project root:

```bash
python3 -m unittest discover -s tests -v
python3 -m unittest discover -s production_tests -v
node --check cloud/app.js
cd cloud && python3 -m http.server 8080
```

Open `http://localhost:8080/` to inspect locally; for installation and real authentication use an HTTPS deployment. Running local `http.server` is for preview only, not a production server.

## Release gate

**Not passed:** Supabase staging integration, end-to-end RLS tests with real JWTs, production identity provisioning, signed billing webhook, end-to-end account/session linkage to MT5 worker, multi-user load tests, trusted data validation, independent model review, Windows/JustMarkets demo execution and broker reconciliation, privacy/security assessment, monitoring and disaster recovery. Keep live trading disabled until those gates are explicitly signed off.
