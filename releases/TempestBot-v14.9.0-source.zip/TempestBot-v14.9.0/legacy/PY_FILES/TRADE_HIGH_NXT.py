"""The original loop is archived; direct trade execution bypassed TempestBot's risk gates."""
raise SystemExit('Unsafe legacy MT5 loop disabled. Run the guarded TempestBot worker.')
