"""TempestBot safety gate: old multi-pair unguarded launcher is disabled."""
raise SystemExit('The legacy trading entrypoint is disabled. Use `python worker.py --help` from the TempestBot folder.')
