import re
import unittest
from pathlib import Path
root=Path(__file__).resolve().parents[1]
web=root/'web'
PAGES=['overview','signals','trades','history','accounts','learning','strategy','subscription','settings','admin','admin/brokers','admin/users']

class MultipageTests(unittest.TestCase):
    def test_public_home_and_login_pages(self):
        for route in ['index.html','login/index.html','404.html']:
            self.assertTrue((web/route).is_file())
    def test_real_html_routes_are_separate_files(self):
        content=[]
        for path in PAGES:
            html=(web/path/'index.html').read_text()
            self.assertIn('data-auth="required"',html,path)
            self.assertIn('src="/app.js"',html,path)
            self.assertIn('href="/overview/"',html,path)
            content.append(html)
        self.assertEqual(len(set(content)),len(PAGES))
    def test_admin_pages_are_marked_and_hidden_for_nonadmins(self):
        for path in ['admin','admin/brokers','admin/users']:
            html=(web/path/'index.html').read_text()
            self.assertIn('data-admin="yes"',html)
            self.assertIn('id="admin-view" hidden',html)
        self.assertIn('checkAdminGate', (web/'app.js').read_text())
    def test_account_password_not_collected_in_browser(self):
        html=(web/'accounts/index.html').read_text()
        self.assertNotIn('type="password"',html)
        self.assertIn('name="server"',html)
        self.assertIn('name="login"',html)
    def test_auth_client_no_privileged_keys(self):
        contents='\n'.join(p.read_text() for p in web.rglob('*.js'))
        for forbidden in ['SUPABASE_SERVICE_ROLE_KEY','CLOUDFLARE_OAUTH_TOKEN','sb_secret_', 'order_send(']:
            self.assertNotIn(forbidden,contents)
    def test_new_database_security(self):
        sql=(root/'supabase/004_multipage_platform.sql').read_text()
        for term in ['enable row level security','public.tempest_is_admin','user_risk_preferences',
                     'admin_user_overview','admin_overview','security definer', 'grant execute']:
            self.assertIn(term,sql)
        self.assertNotRegex(sql,r'grant\s+update\s+on\s+public\.user_entitlements\s+to\s+authenticated')
    def test_service_worker_avoids_html_and_api_caching(self):
        js=(web/'sw.js').read_text()
        self.assertIn("url.origin !== location.origin",js)
        self.assertIn("url.pathname.endsWith('/config.js')",js)
        self.assertIn("!ASSETS.includes(url.pathname)",js)
        self.assertNotIn('cache.addAll([\'/overview/',js)
    def test_page_urls_are_not_one_page_toggle(self):
        html=(web/'overview/index.html').read_text()
        self.assertIn('href="/history/"',html)
        self.assertIn('href="/admin/"',html)
        self.assertNotIn('data-page="signals"',html)
    def test_trade_page_does_not_claim_broker_connection(self):
        html=(web/'trades/index.html').read_text()
        self.assertIn('reported by your Windows workers',html)
        self.assertIn('id="telemetry-data"',html)
        self.assertNotIn('$10,000',html)
    def test_cloud_config_still_public_only(self):
        cfg=(web/'config.js').read_text()
        self.assertIn('supabase.co',cfg)
        self.assertNotIn('SERVICE_ROLE',cfg)

if __name__=='__main__': unittest.main()
