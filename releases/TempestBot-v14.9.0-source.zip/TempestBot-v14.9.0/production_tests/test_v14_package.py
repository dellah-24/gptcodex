import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
class PackageTests(unittest.TestCase):
 def test_expected_layout(self):
  for folder in ('web','worker','supabase','tempestbot','legacy'): self.assertTrue((ROOT/folder).is_dir())
 def test_web_public_config(self):
  text=(ROOT/'web/config.js').read_text();self.assertIn('supabase.co',text);self.assertNotIn('sb_secret_',text)
 def test_no_credentials_packaged(self):
  self.assertFalse((ROOT/'CREDENTIALS.txt').exists());self.assertFalse((ROOT/'.env').exists())
 def test_secure_defaults(self):
  self.assertIn('TEMPESTBOT_LIVE_ENABLED=NO',(ROOT/'.env.example').read_text())
if __name__=='__main__':unittest.main()
