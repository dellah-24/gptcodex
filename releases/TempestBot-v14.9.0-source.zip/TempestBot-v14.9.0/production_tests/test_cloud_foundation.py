import json
import re
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

class ProductionFoundationTests(unittest.TestCase):
    def test_manifest_and_assets(self):
        root=ROOT/'web'
        manifest=json.loads((root/'manifest.webmanifest').read_text())
        self.assertEqual(manifest['display'],'standalone')
        for filename in ('index.html','app.js','styles.css','manifest.webmanifest','sw.js','config.example.js','icon.svg'):
            self.assertTrue((root/filename).is_file(),filename)
    def test_client_never_contains_service_secret(self):
        text='\n'.join((ROOT/'web'/name).read_text() for name in ('index.html','app.js','config.js'))
        self.assertNotRegex(text, r'(?i)(?:eyJ[a-zA-Z0-9_-]{100,}|sb_secret_[a-zA-Z0-9_-]{16,})')
        self.assertNotIn('SUPABASE_SERVICE_ROLE_KEY',text)
        self.assertNotIn('order_send',text)
    def test_sql_enforces_rls_two_accounts(self):
        sql=(ROOT/'supabase/002_app_foundation.sql').read_text()
        for term in ('enable row level security','pg_advisory_xact_lock','Maximum two broker accounts','auth.uid()','grant select','enforce_two_accounts'):
            self.assertIn(term,sql)
        self.assertNotRegex(sql,r'grant\s+(?:insert|update)\s+on\s+public\.user_entitlements\s+to\s+authenticated')
    def test_worker_remains_loopback(self):
        app=(ROOT/'tempestbot/app.py').read_text()
        self.assertIn("('127.0.0.1',0)",app)
    def test_service_worker_does_not_cache_api(self):
        sw=(ROOT/'web/sw.js').read_text()
        self.assertIn("url.origin !== location.origin",sw)
        self.assertIn("config.js",sw)
        self.assertNotIn('supabase.co',sw)
    def test_signal_expiry_is_displayed(self):
        code=(ROOT/'web/app.js').read_text()
        self.assertIn('Date.parse(s.expires_at)>Date.now()',code)
        self.assertIn('!isFresh(signal)',code)
        self.assertIn('ensureAuth',(ROOT/'web/js/client.js').read_text())

if __name__=='__main__': unittest.main()
