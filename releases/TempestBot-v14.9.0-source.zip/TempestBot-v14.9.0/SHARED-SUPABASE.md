# TempestBot v0.6 — Shared Supabase learning & signal foundation

**Status: integrated development prototype, NOT production-ready.** No real Supabase credentials have been provided, no remote migration executed, no real multi-user load test, and no JustMarkets demo order validated. This version adds real Supabase REST interaction paths, not a hosted deployment. It includes the v0.5 legacy trading engine, guarded MT5 execution, models and local dashboard.

## System model

- **Each trader's Windows worker** can optionally submit *completed M10 OHLCV bars* as authenticated user contributions. The Supabase RLS policy makes each user's raw contributions private to that user. The central server can read all contributions.
- **One trusted central backend** resolves price observations into canonical bars, trains shared **challenger** models on the canonical dataset, and is the only actor allowed to approve model versions and publish signals.
- **One shared signal per symbol/candle** is stored in `shared_signals` with a unique constraint. Every authenticated client queries the same published record, using its own Supabase Auth access token (JWT). This implementation polls; it is *not* Realtime push, tick-synchronous distribution, or guaranteed simultaneous order execution.
- **Each trading account** independently checks its own position, account identity, risk limit, spread, stop rules and fill viability through existing `execute_order`. Users can see the same BUY/SELL/FLAT signal and still take different/no trades due to risk limits, broker symbol mapping, clock skew, latency, connection status and account state.
- **Local training disabled in shared mode** when `TEMPESTBOT_SHARED_MODE=1` on dashboard startup. Retraining is a central service responsibility. User raw data should not include MT5 credentials. Trade outcomes may be uploaded separately with explicit user consent and signed normalized R-multiples; automatic deal-upload wiring is deliberately not enabled because cross-account P/L and consent require more work.

## Setup (Supabase project)

1. Create a Supabase project and run `supabase/001_shared_learning.sql` via Supabase SQL Editor. Review security policies, backfill constraints, retention and privacy settings. Requires Supabase Auth user signup/sign-in infrastructure; this version has **no login UI** and accepts a previously obtained valid Supabase Auth JWT via a process environment variable. No OAuth/username/password flow has been added.
2. Create a **trusted, private backend host** for central commands. `SUPABASE_SECRET_KEY` is for that backend ONLY. Never ship it in `.env`, website assets, GitHub, user ZIP, or desktop builds. Supabase secret keys bypass RLS.
3. Clients need `SUPABASE_URL`, `SUPABASE_PUBLISHABLE_KEY` and **their own signed-in user's** `SUPABASE_USER_JWT`. Never copy someone else's JWT. Keep tokens out of logs and public screenshots. Token refresh must be implemented for unattended running (currently not implemented).
4. On the backend, install `scikit-learn`, `numpy`, `joblib`, `pandas` and other worker requirements compatible with your OS and Python version. Do not install MetaTrader5 on the central server for these commands; this service doesn't send orders.

## Client user commands

PowerShell example (values shown are placeholders, not actual credentials):

```powershell
$env:SUPABASE_URL='https://YOUR-PROJECT.supabase.co'
$env:SUPABASE_PUBLISHABLE_KEY='YOUR-PUBLISHABLE-KEY'
$env:SUPABASE_USER_JWT='YOUR-AUTH-USER-ACCESS-TOKEN'
$env:TEMPESTBOT_SHARED_MODE='1'
python run.py
python shared_hub.py signal --symbol XAUUSD
```

To participate, use a **Windows** JustMarkets MT5 demo account and actual broker symbol names:

```powershell
python worker.py --login 12345678 --server YOUR_ACTUAL_JUSTMARKETS_DEMO_SERVER --symbol XAUUSDm --symbol BTCUSDm --mode dry-run --contribute-shared --shared-feed
```

The flags are explicit opt-in. `--shared-feed` fails closed if Supabase is unavailable; it does not fall back to locally generated trades. `--contribute-shared` submits only completed OHLCV bars. The `worker.py` MT5 worker still must be started separately from the dashboard. It does not auto-submit live orders without all original explicit opt-in flags.

A historical JSON candle export with objects `{ "time": 1760000000, "open": 4000, "high": 4010, "low": 3990, "close": 4005, "tick_volume": 100 }` can be uploaded as:

```bash
python shared_hub.py contribute --symbol XAUUSD --file my_closed_m10_bars.json
```

Timestamps must be UTC M10 boundaries, closed, within the last year; upserts are idempotent by user + symbol + bar time. The example timestamp is illustrative and may be rejected if not aligned.

## Central backend operation

Set `SUPABASE_URL` and `SUPABASE_SECRET_KEY` **only on the backend**. Run the **central daemon** under a proper OS supervisor on a private server. It loops once per minute, starts low-priority isolated training jobs when 24 hours and at least 144 new closed M10 candles have elapsed, and never automatically promotes their output:

```bash
python -m tempestbot.central_daemon --poll 60
```

For one manual test cycle without leaving a daemon running:

```bash
python -m tempestbot.central_daemon --once
```

The cycle:
1. Gets user-contributed bars for each instrument (up to 1,000 at a time).
2. Publishes **consensus bars** only if two distinct user IDs closely agree on OHLC; this is a prototype integrity heuristic, **not fraud-resistant verification**. It cannot protect against colluding users, intentionally corrupted feeds, price variation across account types, or one account masquerading as many accounts.
3. Syncs canonical bars to central isolated learning storage.
4. For each *recent* complete M10 candle, reads central APPROVED model metadata, verifies its local artifact SHA256, combines adaptive direction/confidence with heuristic SMC BOS+FVG, and publishes exactly one immutable central BUY, SELL or FLAT decision. No approved model => FLAT.

The central daemon enforces a 24-hour time gate plus at least 144 new distinct canonical candles since the previous training attempt, running challenger jobs in separate low-priority processes with one numerical thread. It persists attempt times to prevent restart storms. Candidates remain **CANDIDATE** and never auto-promote. For a manual operator override (NOT governed by daemon schedule):

```bash
python shared_hub.py train --symbol XAUUSD
python shared_hub.py train --symbol BTCUSD
```

Review the model's out-of-sample evaluation and source artifact before explicit promotion:

```bash
python shared_hub.py approve --symbol XAUUSD --version EXACT_VERSION --ack APPROVE-XAUUSD-EXACT_VERSION
```

The shared database approval is performed by a backend-only RPC, not by customer accounts. The backend checks the local artifact hash and passing metrics before approving. If the local registry update fails after the DB promotion, the publisher returns FLAT until repaired. No candidate is ever automatically promoted. The model still uses simple proxy accuracy tests rather than rigorous spread/slippage-aware strategy return validation.

To publish a test shared signal manually from the trusted server (requires a fresh, realistic bar time and expiry):

```bash
python shared_hub.py publish --symbol XAUUSD --bar-time 1760000400 --direction flat --confidence 0 --model-version none --strategy-version smc-ict-v1 --expires-at 2026-11-15T10:30:00+00:00
```

This command is for manual dry-run testing; replace all example values with actual recent values. A unique `(symbol,timeframe,candle_time)` database key prevents accidental replacement of a published signal.

## Critical deployment blockers

- Implement Supabase Auth user login + token refresh and **server-side subscription validation** before a real multi-tenant launch. Do not trust browser-local subscription toggles.
- Multi-host central leader election (a single-host file lock is present), durable distributed job scheduling, historical backfill/pagination, observability, retry+dead-letter queue, quotas/rate limiting, DB backups, privacy consent/retention and independent authoritative market-feed verification.
- Secure model artifact distribution/reproducibility and end-to-end shared strategy evaluation. Audit/pause/rollback mechanism and fail-closed handling of central model deterioration.
- Realistic live signal freshness and price-slippage policies, clock sync, JustMarkets demo execution on real account(s), reconnection behavior and order reconciliation. **No promise of identical fills or profits.**
- Real Supabase migration smoke tests, RLS abuse tests, concurrent submission tests and multi-region load tests have **not** been run. The included tests use offline fake HTTP responses.

## Tests

```bash
python -m unittest discover -s tests -v
```
