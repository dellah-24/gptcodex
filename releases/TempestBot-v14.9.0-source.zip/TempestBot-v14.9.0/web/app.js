'use strict';
import { startImprovementReviews } from './js/improvement-review.js';
import { startTelemetry } from './js/telemetry.js';
import { isConfigured, currentUser, verifyAuth, signIn, signUp, signOut, query, mutate, rpc } from './js/client.js';

const root=document.body;
const page=root.dataset.page || 'landing';
const $=(selector)=>document.querySelector(selector);
const make=(tag,text='',className='')=>{const e=document.createElement(tag);if(className)e.className=className;e.textContent=String(text);return e;};
const isAdminPage=root.dataset.admin==='yes';
let accounts=[],servers=[],signals=[],history=[];
const safe=(value)=>value===undefined||value===null?'—':String(value);
const time=(value)=>{if(!value)return '—';const d=new Date(value);return Number.isFinite(d.valueOf())?d.toLocaleString():'—';};
const candleTime=(seconds)=>{const d=new Date(Number(seconds)*1000);return Number.isFinite(d.valueOf())?d.toLocaleString():'—';};
function put(id,text){const e=document.getElementById(id);if(e)e.textContent=safe(text);}
function add(where,...items){where.append(...items);return where;}
function showMessage(text,error=false){const toast=$('#toast');if(toast){toast.textContent=text;toast.classList.toggle('error',error);toast.hidden=false;setTimeout(()=>toast.hidden=true,5000);}else{const f=$('#auth-feedback');if(f)f.textContent=text;}}
function empty(text,detail=''){const e=make('div','','empty-state');e.append(make('div','◇','empty-symbol'),make('strong',text),make('p',detail));return e;}
function noData(host,title,desc){if(host)host.replaceChildren(empty(title,desc));}
function pill(label,tone='flat'){return make('span',label,'badge '+tone);}
function row(title,info,tag){const e=make('div','','list-line');const left=make('div','','left');left.append(make('strong',title),make('small',info));e.append(left,tag);return e;}
function stateTag(signal){return !isFresh(signal) ? pill('EXPIRED','expired') : pill((signal.direction||'flat').toUpperCase(),signal.direction||'flat');}
function isFresh(s){return Number.isFinite(Date.parse(s.expires_at)) && Date.parse(s.expires_at)>Date.now();}
function latestSignals(rows){return ['XAUUSD','BTCUSD'].map(symbol=>rows.find(r=>r.symbol===symbol)).filter(Boolean);}
function renderSignalRow(s){return row(`${s.symbol} · ${safe(s.direction).toUpperCase()}`,`M10 · ${candleTime(s.candle_time)} · ${Math.round(Number(s.confidence||0)*100)}% model score`,stateTag(s));}
function signalCard(s){const panel=make('article','','panel');const head=make('div','','panel-header');head.append(make('h2',s.symbol),stateTag(s));const confidence=make('div',`${(Number(s.confidence||0)*100).toFixed(1)}%`,'big-number');panel.append(head,confidence,make('p',`Model ${safe(s.model_version)} · Strategy ${safe(s.strategy_version)}`,'muted'),make('p',`Candle: ${candleTime(s.candle_time)} | Expiry: ${time(s.expires_at)}`,'fine-print'));return panel;}
async function fetchSignals(){return query('shared_signals','select=symbol,timeframe,candle_time,direction,model_version,strategy_version,confidence,expires_at&order=candle_time.desc&limit=50');}
async function fetchAccounts(){return query('user_broker_accounts','select=login,server,label,created_at&order=created_at.asc');}
async function fetchServers(){return query('approved_broker_servers','select=name,enabled&enabled=eq.true&order=name.asc');}
function errorState(title,err){showMessage(`${title}: ${err.message}`,true);put('sync-chip','Cloud sync unavailable');const global=$('#global-notice');if(global){global.textContent='Cloud connection unavailable; do not act on cached signals. '+err.message;global.classList.add('error');}}
const workerStates={
  online:['Online','buy'],paused:['Paused','pending'],disconnected:['MT5 disconnected','sell'],
  reconciliation:['Reconciliation needed','sell'],daily_halt:['Daily-loss halt','sell'],
  exposure_halt:['Exposure halt','pending'],stopped:['Stopped','expired'],
};
let workers=null;
let workerFeedError=false;

function renderWorkers(){
  const host=$('#worker-list');
  if(!host)return;
  const alert=$('#worker-alert');
  const notices=[];
  const cards=(workers||[]).map(worker=>{
    const sampled=Date.parse(worker.sampled_at);
    const stale=!Number.isFinite(sampled) || sampled<=Date.now()-120000;
    const [state,tone]=stale ? ['Offline','expired'] : (workerStates[worker.state] || ['Status unknown','pending']);
    if(stale || worker.state!=='online')notices.push(worker.label+' · '+state);
    const card=make('article','','worker-card');
    const top=make('div','','worker-card-top');
    top.append(make('h3',worker.label),pill(state,tone));
    const mode=worker.mode==='live'?'Live':worker.mode==='demo'?'Demo':'Dry run';
    card.append(top,make('p',mode+' · Last reported '+time(worker.sampled_at),'muted'));
    return card;
  });
  if(cards.length){
    host.replaceChildren(...cards);
    put('worker-summary',`${cards.length-notices.length}/${cards.length} online`);
  }else{
    put('worker-summary',workerFeedError?'Unavailable':'No workers');
    noData(host,workerFeedError?'Worker status unavailable':'No workers reporting',
      workerFeedError?'Refresh after reconnecting to cloud monitoring.':'Start the Windows worker with a monitoring label to see its status here.');
  }
  const message=workerFeedError?'Cloud worker monitoring is unavailable.':notices.join('  •  ');
  if(alert.textContent!==message)alert.textContent=message;
  alert.hidden=!message;
}

async function loadOverview(){
  const [signalResult,accountResult,workerResult]=await Promise.allSettled([
    fetchSignals(),fetchAccounts(),
    query('worker_heartbeats','select=label,mode,state,sampled_at&order=sampled_at.desc&limit=10'),
  ]);
  workerFeedError=workerResult.status!=='fulfilled';
  workers=workerFeedError?null:workerResult.value;
  renderWorkers();
  put('ready-auth','Authenticated');
  put('ready-accounts',accountResult.status==='fulfilled'?`${accountResult.value.length} / 2`:'Unavailable');
  if(signalResult.status!=='fulfilled')throw signalResult.reason;
  signals=signalResult.value;
  const latest=latestSignals(signals);
  put('status-ai',latest.some(isFresh)?'Receiving signals':latest.length?'Signals expired':'No publications');
  const host=$('#recent-signals');
  host.replaceChildren();
  if(latest.length)latest.forEach(signal=>host.append(signalCard(signal)));
  else noData(host,'No published signals','Shared signals will appear when the publisher sends them.');
}

async function loadSignals(){
  signals=await fetchSignals();const latest=latestSignals(signals);const cards=$('#latest-signal-cards');cards.replaceChildren();
  if(latest.length)latest.forEach(s=>cards.append(signalCard(s)));else noData(cards,'No current decisions','No official signals are recorded yet.');
  const past=$('#signal-history');past.replaceChildren();
  if(signals.length)signals.slice(0,25).forEach(s=>past.append(renderSignalRow(s)));else noData(past,'Empty publication history','Signals will appear here after the central coordinator publishes them.');
}
function renderAccounts(){const host=$('#account-list');host.replaceChildren();put('account-count',`${accounts.length} / 2 registered`);
 if(!accounts.length)noData(host,'No accounts registered','Register up to two JustMarkets account identifiers.');
 for(const a of accounts){const n=safe(a.login),label=`${a.label} · ${'•'.repeat(Math.max(0,n.length-4))}${n.slice(-4)}`;
  const del=make('button','Remove','btn secondary');del.type='button';del.addEventListener('click',async()=>{
    if(!confirm('Remove this account metadata? Local MT5 login is unaffected.'))return;
    del.disabled=true;try{await mutate('user_broker_accounts','DELETE',null,'login=eq.'+encodeURIComponent(n));accounts=await fetchAccounts();renderAccounts();showMessage('Account metadata removed');}catch(e){showMessage(e.message,true);del.disabled=false;}
  });host.append(row(label,a.server,del));
 }
 const select=$('#server-select');select.replaceChildren(new Option('Choose approved JustMarkets server',''));
 for(const s of servers)select.append(new Option(s.name,s.name));
 $('#account-submit').disabled=accounts.length>=2 || !servers.length;
}
async function loadAccounts(){[accounts,servers]=await Promise.all([fetchAccounts(),fetchServers()]);renderAccounts();}
async function addAccount(ev){ev.preventDefault();if(accounts.length>=2){showMessage('Maximum two accounts',true);return;}
 const d=Object.fromEntries(new FormData(ev.currentTarget).entries());d.login=safe(d.login).trim();
 if(!/^\d{4,15}$/.test(d.login)||!servers.find(x=>x.name===d.server)||!d.label.trim()){showMessage('Enter a valid login, verified server, and label',true);return;}
 const btn=$('#account-submit');btn.disabled=true;
 try{await mutate('user_broker_accounts','POST',[{login:d.login,server:d.server,label:d.label.trim()}]);ev.currentTarget.reset();accounts=await fetchAccounts();renderAccounts();showMessage('Account metadata saved. MT5 connection still required locally.');}catch(e){showMessage('Save failed: '+e.message,true);}finally{btn.disabled=accounts.length>=2;}
}
async function loadLearning(){const models=await query('shared_model_registry','select=symbol,version,status,created_at,approved_at&order=created_at.desc&limit=40');const host=$('#model-registry');host.replaceChildren();
 if(!models.length)noData(host,'No registered models','The central trainer must publish validated model metadata.');
 models.forEach(m=>host.append(row(`${m.symbol} · ${m.version}`,`${m.status} · Registered ${time(m.created_at)}`,pill(m.status,m.status==='APPROVED'?'buy':m.status==='CANDIDATE'?'pending':'flat'))));
}
async function loadHistory(){history=await query('trade_outcomes','select=symbol,net_r_multiple,closed_at,local_deal_id&order=closed_at.desc&limit=200');const table=$('#outcome-rows');table.replaceChildren();
 if(!history.length){const tr=make('tr');const td=make('td','No reported deals yet.');td.colSpan=4;tr.append(td);table.append(tr);}
 history.forEach(d=>{const tr=make('tr');const r=Number(d.net_r_multiple);tr.append(make('td',d.symbol),make('td',time(d.closed_at)),make('td',Number.isFinite(r)?r.toFixed(2)+' R':'—',r>0?'success-text':r<0?'danger-text':''),make('td',safe(d.local_deal_id)));table.append(tr);});
 put('history-total',history.length);if(history.length){const sum=history.reduce((s,x)=>s+Number(x.net_r_multiple||0),0);put('history-wins',Math.round(100*history.filter(x=>Number(x.net_r_multiple)>0).length/history.length)+'%');put('history-avg',(sum/history.length).toFixed(2)+' R');}else{put('history-wins','—');put('history-avg','—');}
}
function csvHistory(){if(!history.length){showMessage('No trade history to export',true);return;}
 const csv=['symbol,net_r_multiple,closed_at,local_deal_id',...history.map(r=>[r.symbol,r.net_r_multiple,r.closed_at,r.local_deal_id].map(x=>'"'+safe(x).replaceAll('"','""')+'"').join(','))].join('\n');
 const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download='tempestbot-trade-outcomes.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
async function loadSubscription(){const data=await query('user_entitlements','select=plan,active_until&limit=1');const entitlement=data[0];if(!entitlement){put('sub-plan','No paid entitlement');put('sub-expires','Not active');return;}
 const active=entitlement.plan==='PRO'&&entitlement.active_until&&Date.parse(entitlement.active_until)>Date.now();put('sub-plan',active?'PRO · Active':entitlement.plan==='PRO'?'PRO · Expired':'FREE');put('sub-expires',time(entitlement.active_until));
}
async function loadRisk(){const data=await query('user_risk_preferences','select=risk_per_trade,daily_loss_limit,max_positions,manage_positions&limit=1');if(data.length){const d=data[0];const f=$('#risk-form');for(const name of ['risk_per_trade','daily_loss_limit','max_positions'])f.elements[name].value=d[name];f.elements.manage_positions.checked=!!d.manage_positions;}}
async function saveRisk(ev){ev.preventDefault();const f=ev.currentTarget,d=Object.fromEntries(new FormData(f).entries());const risk=Number(d.risk_per_trade),loss=Number(d.daily_loss_limit),positions=Number(d.max_positions);
 if(!Number.isFinite(risk)||risk<0.1||risk>2||!Number.isFinite(loss)||loss<0.5||loss>5||![1,2].includes(positions)){showMessage('Risk preferences outside allowed limits',true);return;}
 const user=currentUser();if(!user){showMessage('Sign in again',true);return;}
 try{await mutate('user_risk_preferences','POST',{user_id:user.id,risk_per_trade:risk,daily_loss_limit:loss,max_positions:positions,manage_positions:f.elements.manage_positions.checked},'on_conflict=user_id','resolution=merge-duplicates,return=minimal');showMessage('Saved in Supabase. Local MT5 worker is NOT automatically updated.');}catch(e){showMessage('Could not save: '+e.message,true);}
}
async function isAdmin(){const rows=await query('tempest_admins','select=user_id&limit=1');return !!rows.length;}
async function checkAdminGate(){try{if(!await isAdmin()){put('admin-gate','Access denied: an administrator must grant this role from a trusted database session.');return false;}
  $('#admin-gate').hidden=true;$('#admin-view').hidden=false;return true;
 }catch(e){put('admin-gate','Could not verify administrative access: '+e.message);return false;}}
async function loadAdmin(){if(!await checkAdminGate())return;
 startImprovementReviews();
 try{const [overview,servers]=await Promise.all([rpc('admin_overview'),query('approved_broker_servers','select=name,enabled&order=name.asc')]);const row=Array.isArray(overview)?overview[0]:overview;put('admin-users-total',row?.total_users ?? '—');put('admin-accounts-total',row?.total_accounts ?? '—');put('admin-servers-total',servers.filter(s=>s.enabled).length);}catch(e){showMessage('Admin overview unavailable: '+e.message,true);}
}
async function loadBrokers(){if(!await checkAdminGate())return;
 servers=await query('approved_broker_servers','select=name,enabled&order=name.asc');renderAdminServers();
}
function renderAdminServers(){const host=$('#admin-server-list');host.replaceChildren();if(!servers.length)noData(host,'No verified servers','Enter an exact JustMarkets MT5 server name after independent verification.');
 for(const s of servers){const button=make('button',s.enabled?'Disable':'Enable','btn '+(s.enabled?'secondary':'primary'));button.type='button';button.addEventListener('click',async()=>{
   if(!confirm(`${s.enabled?'Disable':'Enable'} ${s.name}?`))return;button.disabled=true;try{await mutate('approved_broker_servers','PATCH',{enabled:!s.enabled},'name=eq.'+encodeURIComponent(s.name));await loadBrokers();showMessage('Broker server updated');}catch(e){showMessage(e.message,true);button.disabled=false;}
  });host.append(row(s.name,s.enabled?'Enabled':'Disabled',button));}
}
async function addServer(ev){ev.preventDefault();const f=ev.currentTarget;const name=String(new FormData(f).get('name')||'').trim();if(!/^JustMarkets.{0,89}$/i.test(name)||name.length<5){showMessage('Enter a verified JustMarkets server name',true);return;}
 try{await mutate('approved_broker_servers','POST',[{name,enabled:true}]);f.reset();await loadBrokers();showMessage('Approved server added');}catch(e){showMessage(e.message,true);}
}
async function loadUsers(){if(!await checkAdminGate())return;const data=await rpc('admin_user_overview');const tbody=$('#admin-user-rows');tbody.replaceChildren();if(!data.length){const td=make('td','No registered users');td.colSpan=5;tbody.append(add(make('tr'),td));return;}
 for(const u of data){const tr=make('tr');tr.append(make('td',safe(u.email_masked)),make('td',time(u.registered_at)),make('td',safe(u.broker_accounts)),make('td',safe(u.plan)),make('td',time(u.active_until)));tbody.append(tr);}
}
const navigation = $('#workspace-navigation');
const menuButton = $('.mobile-nav-toggle');
if (navigation && menuButton) {
  const setMenuOpen = (open) => {
    navigation.classList.toggle('is-open', open);
    menuButton.setAttribute('aria-expanded', String(open));
    if (open) navigation.querySelector('a')?.focus();
    else menuButton.focus();
  };
  menuButton.addEventListener('click', () => setMenuOpen(menuButton.getAttribute('aria-expanded') !== 'true'));
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && menuButton.offsetWidth && menuButton.getAttribute('aria-expanded') === 'true') {
      setMenuOpen(false);
    }
  });
}

async function startPrivatePage(){
 const ok=await verifyAuth();if(!ok){const redirect=encodeURIComponent(location.pathname);location.replace('/login/?next='+redirect);return;}
 const user=currentUser();put('header-email',user?.email||'Signed in');put('settings-email',user?.email||'—');put('settings-id',user?.id||'—');put('settings-sync','Connected');put('sync-chip','Cloud connected');
 try{const isAdministrator=await isAdmin();$('#admin-nav').hidden=!isAdministrator;$('#admin-nav-title').hidden=!isAdministrator;}catch{ /* role may not yet exist during migration setup */ }
 const main=$('#main-content');main.hidden=false;
 startTelemetry(page);$('#boot-status').hidden=true;
 const loaders={overview:loadOverview,signals:loadSignals,accounts:loadAccounts,learning:loadLearning,history:loadHistory,subscription:loadSubscription,strategy:loadRisk,admin:loadAdmin,brokers:loadBrokers,users:loadUsers};
 const load=loaders[page];
 const refresh=$('[data-action="refresh"]');
 const notice=$('#global-notice');
 const initialNotice=notice?.textContent;
 let loading=false;
 async function sync(manual=false){
   if(!load || loading)return;
   loading=true;
   if(refresh)refresh.disabled=true;
   try{
     await load();
     put('sync-chip','Synced '+new Date().toLocaleTimeString());
     if(notice){notice.textContent=initialNotice;notice.classList.remove('error');}
     if(manual)showMessage('Latest records loaded');
   }catch(error){
     if(page==='signals'){
       noData($('#latest-signal-cards'),'Signals unavailable','Reconnect and refresh to load current signals.');
       $('#signal-history')?.replaceChildren();
     }
     if(page==='overview'){
       put('status-ai','Unavailable');
       noData($('#recent-signals'),'Signals unavailable','Reconnect and refresh to load current signals.');
     }
     errorState('Sync failed',error);
   }finally{
     loading=false;
     if(refresh)refresh.disabled=false;
   }
 }
 refresh?.addEventListener('click',()=>sync(true));
 await sync();
 if(page==='accounts')$('#account-form').addEventListener('submit',addAccount);
 if(page==='history')$('[data-action="csv"]').addEventListener('click',csvHistory);
 if(page==='strategy')$('#risk-form').addEventListener('submit',saveRisk);
 if(page==='brokers')$('#server-form').addEventListener('submit',addServer);
 document.querySelectorAll('[data-action="signout"],#avatar-signout').forEach(el=>el?.addEventListener('click',async()=>{await signOut();location.assign('/login/');}));
 if(page==='overview'){
   // Reevaluate aging locally even when the next cloud request is delayed.
   setInterval(()=>{if(!document.hidden && workers?.length)renderWorkers();},15000);
   window.addEventListener('offline',()=>{
     workerFeedError=true;
     workers=null;
     renderWorkers();
   });
 }
 if(['overview','signals'].includes(page)){
   setInterval(()=>{if(!document.hidden)sync();},30000);
   document.addEventListener('visibilitychange',()=>{if(!document.hidden)sync();});
   window.addEventListener('online',()=>sync());
 }

}
function startLogin(){
 if(!isConfigured()){put('auth-feedback','Supabase public configuration is missing. Configure web/config.js before using login.');return;}
 let signup=new URLSearchParams(location.search).get('signup')==='1';
 const toggle=$('#signup-toggle');const submit=$('#login-submit');const f=$('#login-form');
 const mode=()=>{put('login-title',signup?'Create account':'Welcome back');put('login-subtitle',signup?'Join TempestBot using email and password.':'Sign in with your TempestBot account.');put('login-submit',signup?'Create account':'Sign in');toggle.textContent=signup?'Already have an account? Sign in':'Create an account instead';};mode();
 toggle.addEventListener('click',()=>{signup=!signup;mode();});
 f.addEventListener('submit',async ev=>{ev.preventDefault();const d=Object.fromEntries(new FormData(f).entries());if(!d.email||String(d.password||'').length<8){put('auth-feedback','Enter a valid email and at least eight password characters.');return;}
 submit.disabled=true;put('auth-feedback','Authenticating…');try{const result=signup?await signUp(d.email,d.password):await signIn(d.email,d.password);f.elements.password.value='';
 if(signup&&!result.access_token){put('auth-feedback','Account created. Check your email confirmation, then sign in.');return;}
 const next=new URLSearchParams(location.search).get('next')||'/overview/';location.replace(next.startsWith('/')&&!next.startsWith('//')&&!next.includes('\\')?next:'/overview/');
 }catch(e){put('auth-feedback','Authentication failed: '+e.message);}finally{submit.disabled=false;}});
}
if(page==='login')startLogin();else if(root.dataset.auth==='required')startPrivatePage();
if('serviceWorker' in navigator)navigator.serviceWorker.register('/sw.js').catch(()=>{});
