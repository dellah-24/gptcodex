import { query, currentUser } from './client.js';

const statusNames = {
  RESERVED: 'Prepared for submission', FILLED: 'Filled', PARTIAL: 'Partially filled', PARTIAL_SETTLED: 'Partial fill settled',
  SUBMITTED: 'Submitted', RECONCILE: 'Needs reconciliation', UNKNOWN: 'Needs reconciliation',
  UNKNOWN_PENDING: 'Submission awaiting confirmation', REJECTED: 'Rejected',
  BLOCKED: 'Blocked', ACKNOWLEDGED: 'Reviewed',
};
const stateNames = {daily_halt:'Daily-loss halt',exposure_halt:'Exposure halt',reconciliation:'Needs reconciliation'};
const fresh = item => Date.now() - Date.parse(item.sampled_at) < 120000 && Number.isFinite(Date.parse(item.sampled_at));
const stamp = value => new Date(value).toLocaleString();
const readable = value => value === null || value === undefined ? '—' : String(value);
const direction = value => value ? value.toUpperCase() : '—';

function make(tag, value, className) {
  const element = document.createElement(tag);
  if (value != null) element.textContent = value;
  if (className) element.className = className;
  return element;
}

function metrics(values) {
  const list = make('dl', null, 'telemetry-metrics');
  for (const [name,value] of values) {
    const cell = make('div');
    cell.append(make('dt',name),make('dd',readable(value)));
    list.append(cell);
  }
  return list;
}

function card(title, state, tone) {
  const article = make('article', null, 'telemetry-card');
  const header = make('div', null, 'worker-card-top');
  header.append(make('h3',title), make('span',state,'badge '+tone));
  article.append(header);
  return article;
}

function renderSnapshot(host, item, page) {
  const data = item.snapshot;
  const recent = fresh(item);
  const group = make('section',null,'telemetry-group');
  group.append(make('h3', item.label),make('p', `${data.mode.toUpperCase()} · ${recent ? 'Updated' : 'Stale snapshot from'} ${stamp(item.sampled_at)}`, 'muted'));
  const grid = make('div',null,'telemetry-grid');
  if (page === 'signals') {
    for (const decision of data.decisions) {
      const recentCandle = Date.now() / 1000 < decision.candle + 180;
      const shown = recent && recentCandle ? direction(decision.side) : 'STALE';
      const tile = card(decision.symbol, shown, recent && recentCandle ? decision.side || 'flat' : 'expired');
      const remaining = Math.max(0, Math.ceil((decision.cooldown_until || 0)-Date.now()/1000));
      const reason = decision.cooldown_until ? (remaining ? `Exit cooldown · ${remaining}s remaining` : 'Cooldown ended. Waiting for a new M1 signal.') : decision.reason;
      tile.append(metrics([['M1 trigger',direction(decision.trigger)], ...['M5','M15','H1'].map(frame => [frame,direction(decision.context[frame])])]),
        make('p',reason),make('small',stamp(decision.candle*1000),'muted'));
      grid.append(tile);
    }
    if (!grid.childElementCount) grid.append(make('p','No scalping decisions reported.','muted'));
  } else {
    if (!recent || data.positions === null) grid.append(make('p','Current broker positions are unavailable.','muted'));
    else if (!data.positions.length) grid.append(make('p','No open TempestBot positions.','muted'));
    else for (const position of data.positions) {
      const tile = card(position.symbol, direction(position.side), position.side);
      const minutes = Math.max(0,Math.floor((Date.now()/1000-position.opened_at)/60));
      tile.append(metrics([['Entry',position.entry],['Stop',position.sl || null],['Target',position.tp || null],
        ['Holding',minutes+' min'],['Volume',position.volume],['Unrealized P&L',position.pnl.toFixed(2)+' '+data.currency]]));
      grid.append(tile);
    }
  }
  group.append(grid);
  if (page === 'trades') {
    group.append(make('h3','Execution timeline','timeline-title'));
    for (const event of data.events) {
      const line = make('div',null,'timeline-line');
      line.append(make('strong',event.symbol+' · '+event.action),make('span',statusNames[event.status]||event.status),
        make('small',stamp(event.at)+(event.volume == null ? '' : ' · '+event.volume+' lots'),'muted'));
      group.append(line);
    }
    if (!data.events.length) group.append(make('p','No execution attempts reported.','muted'));
  }
  host.append(group);
}

export function startTelemetry(page) {
  const user = currentUser();
  if (!user || !['overview','signals','trades'].includes(page)) return;
  const host = document.getElementById('telemetry-data');
  const alerts = document.getElementById('personal-alerts');
  const key = 'tempest-alerts-'+user.id;
  let enabled = false;
  try { enabled = localStorage.getItem(key)==='yes'; } catch {}
  let loading = false;
  let last = [];
  const renderAlerts = () => {
    if (!alerts) return;
    const groups = new Map();
    for (const item of last.filter(fresh)) {
      const data=item.snapshot;
      if (stateNames[data.state]) {
        const name=stateNames[data.state];
        groups.set(name,(groups.get(name)||0)+1);
      }
      const processed=new Set();
      for (const event of data.events) {
        if(processed.has(event.order_ref))continue;
        processed.add(event.order_ref);
        if (Date.now()-Date.parse(event.at) > 900000) continue;
        const name = ['FILLED','PARTIAL','PARTIAL_SETTLED'].includes(event.status) ? 'Recent fills' :
          ['UNKNOWN','UNKNOWN_PENDING','RECONCILE'].includes(event.status) ? 'Orders to reconcile' : null;
        if (name) groups.set(name,(groups.get(name)||0)+1);
      }
    }
    const summary=enabled?[...groups].map(([name,count])=>name+(count>1?' ('+count+')':'')).join(' · '):'';
    if(alerts.textContent!==summary)alerts.textContent=summary;
    alerts.hidden=!summary;
  };
  const button=document.getElementById('toggle-personal-alerts');
  if(button){
    const paint=()=>{button.setAttribute('aria-pressed',String(enabled));button.textContent='Trading alerts '+(enabled?'on':'off');};
    button.addEventListener('click',()=>{
      enabled=!enabled;
      try {localStorage.setItem(key,enabled?'yes':'no');} catch {}
      paint();
      renderAlerts();
    });
    paint();
  }
  const refresh=async()=>{
    if(loading||document.hidden)return;
    loading=true;
    try {
      last=await query('worker_telemetry','select=label,sampled_at,snapshot&order=sampled_at.desc&limit=10');
      if(host){
        host.replaceChildren();
        for(const item of last)renderSnapshot(host,item,page);
        if(!last.length)host.append(make('p','No workers have shared telemetry yet.','muted'));
      }
      renderAlerts();
    }catch{
      last=[];
      if(host)host.replaceChildren(make('p','Worker telemetry is unavailable.','muted'));
      renderAlerts();
    }finally{loading=false;}
  };
  refresh();
  setInterval(refresh,10000);
  window.addEventListener('online',refresh);
  document.addEventListener('visibilitychange',refresh);
}
