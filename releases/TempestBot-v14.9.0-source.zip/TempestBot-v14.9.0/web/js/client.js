// Browser-only Supabase Auth and RLS Data API client. No broker passwords or service keys.
const config = window.TEMPEST_CONFIG || {};
const sessionKey = 'tempestbot_browser_session';
const configured = /^https:\/\/[a-z0-9-]+\.supabase\.co\/?$/i.test(config.supabaseUrl || '') &&
  /^sb_publishable_|^eyJ/.test(config.publishableKey || '') && !config.publishableKey.includes('REPLACE');
let session = null;
let refreshing = null;
try { session = JSON.parse(sessionStorage.getItem(sessionKey) || 'null'); } catch { session = null; }

export function isConfigured() { return configured; }
export function currentUser() { return session?.user || null; }
function storeSession(data) {
  session = { ...data, expires_at: data.expires_at || Math.floor(Date.now()/1000) + (data.expires_in || 3600) };
  sessionStorage.setItem(sessionKey, JSON.stringify(session));
}
function clearSession() { session = null; sessionStorage.removeItem(sessionKey); }

async function api(path, { method='GET', body=null, auth=false, headers={} }={}) {
  if(!configured) throw Error('Public Supabase configuration missing');
  const reqHeaders = { apikey:config.publishableKey, ...headers };
  if(body !== null) reqHeaders['Content-Type'] = 'application/json';
  if(auth) {
    if(!session?.access_token) throw Error('Sign in required');
    reqHeaders.Authorization = 'Bearer ' + session.access_token;
  }
  const res = await fetch(config.supabaseUrl.replace(/\/$/, '') + path, {
    method, signal:AbortSignal.timeout(15000), headers:reqHeaders, body:body===null?undefined:JSON.stringify(body), cache:'no-store', credentials:'omit'
  });
  let content;
  try { content = await res.json(); } catch { content = null; }
  if(!res.ok) throw Error(content?.error_description || content?.message || content?.msg || content?.error || `HTTP ${res.status}`);
  return content;
}
async function refreshToken() {
  if(refreshing) return refreshing;
  refreshing = (async()=>{
    if(!session?.refresh_token) return false;
    try {
      const result=await api('/auth/v1/token?grant_type=refresh_token', {method:'POST',body:{refresh_token:session.refresh_token}});
      if(!result.access_token) throw Error('Session refresh denied');
      storeSession(result); return true;
    } catch { clearSession(); return false; }
  })();
  try { return await refreshing; } finally { refreshing=null; }
}
export async function ensureAuth() {
  if(!configured) return false;
  if(session?.access_token && Date.now() + 60000 < (session.expires_at||0)*1000) return true;
  return refreshToken();
}
export async function verifyAuth() {
  if(!await ensureAuth()) return false;
  try {
    const user=await api('/auth/v1/user',{auth:true});
    if(!user?.id) throw Error('User not authenticated');
    session.user=user;sessionStorage.setItem(sessionKey,JSON.stringify(session));return true;
  } catch { clearSession();return false; }
}
export async function signIn(email,password) {
  const data = await api('/auth/v1/token?grant_type=password',{method:'POST',body:{email,password}});
  if(!data?.access_token) throw Error('Sign-in response did not contain a session');
  storeSession(data);return data;
}
export async function signUp(email,password) {
  const data=await api('/auth/v1/signup',{method:'POST',body:{email,password}});
  if(data?.access_token) storeSession(data);
  return data;
}
export async function signOut() {
  if(session?.access_token) {
    try { await api('/auth/v1/logout',{method:'POST',auth:true}); } catch { /* Clear locally even if offline */ }
  }
  clearSession();
}
export async function query(table,queryString='') {
  if(!await ensureAuth()) throw Error('Session expired; sign in again');
  return api('/rest/v1/'+encodeURIComponent(table)+(queryString?'?'+queryString:''),{auth:true});
}
export async function mutate(table,method,body,queryString='',prefer='return=minimal') {
  if(!await ensureAuth()) throw Error('Session expired; sign in again');
  return api('/rest/v1/'+encodeURIComponent(table)+(queryString?'?'+queryString:''),{method,body,auth:true,headers:{Prefer:prefer}});
}
export async function rpc(name,args={}) {
  if(!await ensureAuth()) throw Error('Session expired; sign in again');
  return api('/rest/v1/rpc/'+encodeURIComponent(name),{method:'POST',body:args,auth:true});
}
