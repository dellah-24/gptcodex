import { query, rpc } from './client.js';

function element(tag, text, className) {
  const node = document.createElement(tag);
  if (text !== undefined) node.textContent = text;
  if (className) node.className = className;
  return node;
}

function money(value) {
  return typeof value === 'number' ? new Intl.NumberFormat(undefined, {style:'currency',currency:'USD'}).format(value) : '—';
}

function displayDate(value) {
  if (!value) return '—';
  const date = new Date(typeof value === 'number' ? value * 1000 : value.replace(' ', 'T') + (value.includes('T') ? '' : 'Z'));
  return Number.isFinite(date.getTime()) ? date.toLocaleString() : '—';
}

function pair(label, value) {
  const cell = element('div');
  cell.append(element('dt',label),element('dd',String(value ?? '—')));
  return cell;
}

export function startImprovementReviews() {
  const panel = document.getElementById('improvement-admin');
  const host = document.getElementById('improvement-reviews');
  const feedback = document.getElementById('improvement-feedback');
  const refresh = document.getElementById('refresh-improvement');
  if (!panel || !panel.hidden) return;
  panel.hidden = false;

  async function load() {
    refresh.disabled = true;
    try {
      const rows = await query('improvement_reviews','select=profile,report,demo,synced_at,approved_at,approved_demo&order=synced_at.desc&limit=30');
      host.replaceChildren();
      for (const row of rows) {
        const report = row.report;
        const candidate = report.candidate;
        const score = report.candidate_holdout;
        const gate = row.demo.some(d => d.mode==='demo' && d.positions>=20 && d.days>=2 && d.net_pnl>0);
        const state = row.approved_at ? 'Approved for live' : !report.qualified ? 'Historical screen incomplete' : gate ? 'Ready for review' : 'Demo evidence pending';
        const card = element('article',undefined,'telemetry-card improvement-card');
        const head = element('div',undefined,'worker-card-top');
        head.append(element('h3',report.symbol+' · '+(candidate?.entry_style || 'Evaluation')),element('span',state,
          'badge '+(row.approved_at?'buy':'pending')));
        card.append(head,element('p','Evidence synced '+displayDate(row.synced_at),'muted'));
        const details = element('dl',undefined,'telemetry-metrics');
        details.append(pair('Holdout trades',score?.trades),pair('Holdout net P&L',money(score?.net_pnl)),
          pair('Baseline net P&L',money(report.baseline_holdout?.net_pnl)),pair('Holdout drawdown',score ? score.max_drawdown_pct+'%' : '—'),
          pair('Evaluation start',displayDate(report.cutoff)),pair('Evaluation end',displayDate(report.end_tick)),
          pair('Retest candles',candidate?.retest_bars),pair('Max entry distance',candidate ? candidate.max_entry_distance_atr+' ATR' : '—'),
          pair('Commission per fill',report.costs?.commission_bps),pair('Slippage points per fill',report.costs?.slippage_points));
        card.append(details);
        const demo = element('details');
        demo.append(element('summary','Demo training log'));
        if (!row.demo.length) demo.append(element('p','No demo sessions have been synced.','muted'));
        for (const account of row.demo) {
          const group = element('div',undefined,'improvement-session');
          group.append(element('strong',account.account+' · '+account.server),
            element('p',account.positions+' closed positions · '+account.days+' UTC days · '+money(account.net_pnl)));
          for (const session of account.sessions) group.append(element('p',
            displayDate(session.start)+' to '+(session.end?displayDate(session.end):'No stop recorded'),'muted'));
          demo.append(group);
        }
        card.append(demo);
        const identifier = element('details');
        identifier.append(element('summary','Profile ID and evidence'),element('code',row.profile));
        const evidence = element('pre', JSON.stringify(report,null,2));
        identifier.append(evidence);
        card.append(identifier);
        const button = element('button','Approve profile for live','btn primary');
        button.type = 'button';
        button.disabled = !report.qualified || !gate || Boolean(row.approved_at);
        button.addEventListener('click',async ()=>{
          if (!window.confirm('Approve these exact settings for live use? This does not start the MT5 worker.')) return;
          button.disabled = true;
          try {
            await rpc('approve_improvement_profile',{candidate_id:row.profile});
            feedback.textContent = 'Profile approved. The Windows worker can explicitly select it for live mode.';
            await load();
          } catch (error) {
            feedback.textContent = error.message;
            button.disabled = false;
          }
        });
        if (!row.approved_at) card.append(button);
        else {
          const approved = row.approved_demo;
          card.append(element('p','Approved '+displayDate(row.approved_at),'muted'));
          if (approved) card.append(element('p','Demo evidence at approval · '+approved.account+' · '+
            approved.positions+' positions · '+money(approved.net_pnl),'muted'));
        }
        host.append(card);
      }
      if (!rows.length) host.append(element('p','No evaluations have been synced yet.','muted'));
    } catch (error) {
      feedback.textContent = 'Review evidence unavailable: '+error.message;
    } finally {
      refresh.disabled = false;
    }
  }
  refresh.addEventListener('click',load);
  load();
}
