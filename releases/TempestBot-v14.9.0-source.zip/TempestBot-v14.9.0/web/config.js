// Public Supabase browser configuration only. Never add secret or service-role keys.
window.TEMPEST_CONFIG = {
  "supabaseUrl": "https://dupmdeetnkdcfxgkpymv.supabase.co",
  "publishableKey": "sb_publishable_KdK_WwnvqXQqb-adPuyxRA_jUUXokSY"
};
