// Offline-safe static visual assets only. Never cache HTML, JS, user data, or API calls.
const CACHE='tempest-v14-multipage-assets-3';
const ASSETS=['/styles.css','/icon.svg','/icon-192.png','/icon-512.png','/manifest.webmanifest'];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(ASSETS)).then(()=>self.skipWaiting())));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('tempest-') && k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{
  if(event.request.method!=='GET')return;
  const url=new URL(event.request.url);
  if(url.origin !== location.origin || url.pathname.endsWith('/config.js'))return;
  if(!ASSETS.includes(url.pathname))return; // Network-only for navigations, data and executable JS
  event.respondWith(fetch(event.request,{cache:'no-store'}).catch(()=>caches.match(event.request)));
});
