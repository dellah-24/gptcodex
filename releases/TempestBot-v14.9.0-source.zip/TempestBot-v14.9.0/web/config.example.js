// Only public Supabase URL and publishable key belong in browser code.
window.TEMPEST_CONFIG = {supabaseUrl:"https://YOUR_PROJECT.supabase.co",publishableKey:"sb_publishable_REPLACE_ME"};
